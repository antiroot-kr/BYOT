#!/usr/bin/python
# -*- coding: utf-8 -*-

import BaseHTTPServer
import urlparse
import SocketServer
import threading
import cgi
import MySQLdb as mdb
import sys
from xml.dom.minidom import parseString
import re
import random
import os
from daemon import Daemon
try:
    from xml.etree import cElementTree as ElementTree
except ImportError, e:
    from xml.etree import ElementTree

class CellPattern:
    message = ""
    def __init__(self):
        print "---------------------"
        sys.stdout.flush()

    def __del__(self):
        sys.stdout.flush()

    def LookupCellPattern(self, name):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM cell_pattern WHERE name = '" + name + "'")
            con.commit()

            rows = cur.fetchall()
            message = "[WARNING] No such a cell_pattern from a user called '" + name + "'"
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "name: %s" % row["name"]
                print "pattern: %s" % row["pattern"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + row["name"] \
                    + "_" + row["pattern"]
                break

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def CreateCellPattern(self, device_id, time, name, pattern):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM cell_pattern WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) != 0:
                #message = "[WARNING] already cell_pattern exists for the user"
                cur.execute("DELETE FROM cell_pattern WHERE name = '" + name + "'")
                con.commit()
                #return message

            cur.execute("INSERT INTO cell_pattern \
                (device_id, time, name, pattern) values('" \
                + device_id + "', " + time + ", '" \
                + name + "', '" + pattern + "')")
            con.commit()

            cur.execute("SELECT * FROM cell_pattern WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "name: %s" % row["name"]
                print "pattern: %s" % row["pattern"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + row["name"] \
                    + "_" + row["pattern"]
                break

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def UpdateCellPattern(self, device_id, time, name, pattern):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM cell_pattern WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) == 0:
                message = "[WARNING] No such a cell_pattern from a user called '" + name + "'"
                return message

            query = "UPDATE cell_pattern SET ";
            set_items = 0;
            if len(time) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1

                query += " time = " + str(time)

            if len(pattern) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " pattern = '" + pattern + "'"

            query += " WHERE name = '" + name + "' AND device_id = '" + device_id + "'"
            cur.execute(query)
            con.commit()

            cur.execute("SELECT * FROM cell_pattern WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "name: %s" % row["name"]
                print "pattern: %s" % row["pattern"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + row["name"] \
                    + "_" + row["pattern"]
                break

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def DeleteCellPattern(self, device_id, name):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM cell_pattern WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) == 0:
                message = "[WARNING] No such a cell_pattern from a user called '" + name + "'"
                return message

            #cur.execute("DELETE FROM cell_pattern WHERE name = '" + name + "'")
            #con.commit()
            message = "The cell_pattern of a user '" + name + "' has been successfully deleted."

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

class CellPatternHTTPHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse.urlparse(self.path)
        ##message = 'DEBUG INFO\n' + '\n'.join(['CLIENT:', 'client_addr=%s (%s)' 
        ##    % (self.client_address, self.address_string()), 
        ##    'command=%s' % self.command, 'path=%s' % self.path,
        ##    'real_path=%s' % parsed_path.path,
        ##    'query=%s' % parsed_path.query, 'request_ver=%s' % self.request_version,
        ##    '',
        ##    'SERVER:', 'server_ver=%s' % self.server_version, 'sys_ver=%s' % self.sys_version,
        ##    'protocol_ver=%s' % self.protocol_version, ''])
        ##print message
        sys.stdout.flush()
        reg = re.compile('(\w+)[=]([\w\s\-_.,]+)?')
        dict_query = dict(reg.findall(parsed_path.query))

        cp = CellPattern()

        message = ""
        no_sufficient_info = False;
        if 'query' in dict_query.keys():
            query = dict_query['query']
        else:
            query = ""
        if query == 'lookup_cell_pattern':
            if 'name' in dict_query.keys():
                print "name: %s" % dict_query['name']
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'name' field on your query\n"
            if no_sufficient_info == False:
                message = cp.LookupCellPattern(dict_query['name'])
        elif query == 'create_cell_pattern':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'time' in dict_query.keys():
                time = dict_query['time']
                print "time: %d" % int(time)
            else:
                message += "[ERROR] No 'time' field on your query\n"
                no_sufficient_info = True;
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'pattern' field on your query\n"
            if 'pattern' in dict_query.keys():
                pattern = dict_query['pattern']
                print "pattern: %s" % pattern
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'name' field on your query\n"
            if no_sufficient_info == False:
                message = cp.CreateCellPattern(device_id, time, name, pattern)
        elif query == 'update_cell_pattern':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                message += "[ERROR] No 'name' field on your query\n"
                no_sufficient_info = True;
            if 'time' in dict_query.keys():
                time = dict_query['time']
                print "time: %d" % int(time)
            else:
                time = ""
            if 'pattern' in dict_query.keys():
                pattern = dict_query['pattern']
                print "pattern: %s" % pattern
            else:
                pattern = ""
            if no_sufficient_info == False:
                message = cp.UpdateCellPattern(device_id, time, name, pattern)
        elif query == 'delete_cell_pattern':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                message += "[ERROR] No 'name' field on your query\n"
                no_sufficient_info = True;
            if no_sufficient_info == False:
                message = cp.DeleteCellPattern(device_id, name)
        else:
            message = "[ERROR] I don't understand (may be WRONG query)"

        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(message)
        return


class ThreadedHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
    """ Handle request in a separate thread"""

class CellPatternDaemon(Daemon):
    def run(self):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT VERSION()")

            ver = cur.fetchone()
            print "MySQL database version: %s " % ver

            #cur.execute("DROP TABLE IF EXISTS cell_pattern")
            cur.execute("CREATE TABLE IF NOT EXISTS cell_pattern (id int primary key auto_increment, \
                device_id varchar(36), \
                time int, \
                name varchar(12), \
                pattern varchar(512))")

            #for i in range(0, 1000):
            #    cur.execute("INSERT INTO cell_pattern (time, name, pattern) values (" \
            #        + str(random.randrange(1, 65536)) + ", '" + "antiroot" + str(i) + "', '" \
            #        + "pattern" + str(random.randrange(1,65536)) + "')")
            con.commit()
    
        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            sys.exit(1)

        finally:
            if con:
                con.close()

        server = ThreadedHTTPServer(('pepperjack.stanford.edu', 8001), CellPatternHTTPHandler)
        print 'Starting Cell Pattern HTTP Server, with 8001 port'
        sys.stdout.flush()
        server.serve_forever()


if __name__ == '__main__':
    d = os.path.dirname("./log")
    if not os.path.exists("./log"):
        os.system("mkdir ./log")

    d = os.path.dirname("./pid")
    if not os.path.exists("./pid"):
        os.system("mkdir ./pid")

    outfilepath = os.path.abspath("./log/cell_pattern.out")
    errfilepath = os.path.abspath("./log/cell_pattern.err")
    pidfilepath = os.path.abspath("./pid/cell_pattern.pid")

    daemon = CellPatternDaemon(pidfilepath, \
            "/dev/null", outfilepath, errfilepath)

    if len(sys.argv) == 2:
        if "start" == sys.argv[1]:
            daemon.start()
        elif "stop" == sys.argv[1]:
            daemon.stop()
        elif "restart" == sys.argv[1]:
            daemon.restart()
        else:
            print "Error: unknown command"
            sys.stdout.flush()
            sys.exit(1)
        sys.exit(0)
    else:
        print "Usage: %s start|stop|restart" % sys.argv[0]
        sys.stdout.flush()
        sys.exit(2)


