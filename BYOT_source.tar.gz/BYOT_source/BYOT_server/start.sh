#/bin/bash

python user_profile.py start
python cell_pattern.py start
python traj_pattern.py start
python batt_history.py start
python availability.py start
