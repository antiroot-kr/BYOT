#!/usr/bin/python
# -*- coding: utf-8 -*-

import BaseHTTPServer
import urlparse
import SocketServer
import threading
import cgi
import MySQLdb as mdb
import sys
from xml.dom.minidom import parseString
import re
import random
import os
from daemon import Daemon
try:
    from xml.etree import cElementTree as ElementTree
except ImportError, e:
    from xml.etree import ElementTree

class AvailabilityHTTPHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse.urlparse(self.path)
        #message = 'DEBUG INFO\n' + '\n'.join(['CLIENT:', 'client_addr=%s (%s)' 
        #    % (self.client_address, self.address_string()), 
        #    'command=%s' % self.command, 'path=%s' % self.path,
        #    'real_path=%s' % parsed_path.path,
        #    'query=%s' % parsed_path.query, 'request_ver=%s' % self.request_version,
        #    '',
        #    'SERVER:', 'server_ver=%s' % self.server_version, 'sys_ver=%s' % self.sys_version,
        #    'protocol_ver=%s' % self.protocol_version, ''])
        #print message
        sys.stdout.flush()
        reg = re.compile('(\w+)[=]([\w\s\-_.,]+)?')
        dict_query = dict(reg.findall(parsed_path.query))

        message = "BYOT"
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(message)
        return

class ThreadedHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
    """ Handle request in a separate thread"""

class AvailabilityDaemon(Daemon):
    def run(self):
        server = ThreadedHTTPServer(('pepperjack.stanford.edu', 8004), AvailabilityHTTPHandler)
        print 'Starting Availability HTTP Server, with 8004 port'
        sys.stdout.flush()
        server.serve_forever()


if __name__ == '__main__':
    d = os.path.dirname("./log")
    if not os.path.exists("./log"):
        os.system("mkdir ./log")

    d = os.path.dirname("./pid")
    if not os.path.exists("./pid"):
        os.system("mkdir ./pid")

    outfilepath = os.path.abspath("./log/availability.out")
    errfilepath = os.path.abspath("./log/availability.err")
    pidfilepath = os.path.abspath("./pid/availability.pid")

    daemon = AvailabilityDaemon(pidfilepath, \
            "/dev/null", outfilepath, errfilepath)

    if len(sys.argv) == 2:
        if "start" == sys.argv[1]:
            daemon.start()
        elif "stop" == sys.argv[1]:
            daemon.stop()
        elif "restart" == sys.argv[1]:
            daemon.restart()
        else:
            print "Error: unknown command"
            sys.stdout.flush()
            sys.exit(1)
        sys.exit(0)
    else:
        print "Usage: %s start|stop|restart" % sys.argv[0]
        sys.stdout.flush()
        sys.exit(2)



