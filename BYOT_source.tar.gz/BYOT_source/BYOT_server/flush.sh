#/bin/bash

rm -rf log
rm -rf pid
