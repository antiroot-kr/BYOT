#!/usr/bin/python
# -*- coding: utf-8 -*-

import BaseHTTPServer
import urlparse
import SocketServer
import threading
import cgi
import MySQLdb as mdb
import sys
from xml.dom.minidom import parseString
import re
import random
import os
from daemon import Daemon
try:
    from xml.etree import cElementTree as ElementTree
except ImportError, e:
    from xml.etree import ElementTree

class UserProfile:
    message = ""
    def __init__(self):
        print "---------------------"
        sys.stdout.flush()

    def __del__(self):
        sys.stdout.flush()

    def LogIn(self, device_id, name, last_login):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor()
            cur.execute("SELECT COUNT(*) from user where name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()

            count = cur.fetchone()[0]
            if count == 0:
                message = "[WARNING] Log-in failed (different device?)"
            elif count == 1:
                message = "[SUCCESS] Log-in succeeded"
                query = "UPDATE user SET last_login = " + str(last_login)
                query += " WHERE name = '" + name + "'"
                cur.execute(query)
                con.commit()
            else:
                message = "[ERROR] Server error (multiple accounts)"
            print message
            sys.stdout.flush()
           
        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def CountUsers(self):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor()
            cur.execute("SELECT COUNT(*) from user, cell_pattern WHERE user.name = cell_pattern.name")
            con.commit()

            count = cur.fetchone()[0]
            print "count: %d" % count
            sys.stdout.flush()
            message = str(count)

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def LookupUser(self, name):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * from user WHERE name = '" + name + "'")
            con.commit()

            rows = cur.fetchall()
            message = "[WARNING] No such a user called '" + name + "'"
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "last_login: %d" % row["last_login"]
                print "name: %s" % row["name"]
                print "total_point: %d" % row["total_point"]
                print "attack_point: %d" % row["attack_point"]
                print "defense_point: %d" % row["defense_point"]
                print "usability_point: %d" % row["usability_point"]
                print "n_trial_self: %d" % row["n_trial_self"]
                print "n_trial_other: %d" % row["n_trial_other"]
                print "n_ts_self: %d" % row["n_ts_self"]
                print "n_tf_self: %d" % row["n_tf_self"]
                print "n_fs_self: %d" % row["n_fs_self"]
                print "n_ff_self: %d" % row["n_ff_self"]
                print "n_ts_other: %d" % row["n_ts_other"]
                print "n_tf_other: %d" % row["n_tf_other"]
                print "n_fs_other: %d" % row["n_fs_other"]
                print "n_ff_other: %d" % row["n_ff_other"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + str(row["last_login"]) \
                    + "_" + row["name"] \
                    + "_" + str(row["total_point"]) \
                    + "_" + str(row["attack_point"]) \
                    + "_" + str(row["defense_point"]) \
                    + "_" + str(row["usability_point"]) \
                    + "_" + str(row["n_trial_self"]) \
                    + "_" + str(row["n_trial_other"]) \
                    + "_" + str(row["n_ts_self"]) \
                    + "_" + str(row["n_tf_self"]) \
                    + "_" + str(row["n_fs_self"]) \
                    + "_" + str(row["n_ff_self"]) \
                    + "_" + str(row["n_ts_other"]) \
                    + "_" + str(row["n_tf_other"]) \
                    + "_" + str(row["n_fs_other"]) \
                    + "_" + str(row["n_ff_other"])
                break

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def LookupUserRank(self, name):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT user.* from user, cell_pattern WHERE user.name = cell_pattern.name ORDER BY total_point DESC")
            con.commit()
            rows = cur.fetchall()
            message = ""
            rank = 0
            for row in rows:
                rank += 1
                if row["name"] != name:
                    continue
                break

            if rank == len(rows):
                rank = 0
            print "rank: %d" % rank
            sys.stdout.flush()
            message = str(rank)

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        
        return message

    def LookupUsersByRank(self, offset, count):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT user.* from user, cell_pattern WHERE user.name = cell_pattern.name ORDER BY total_point DESC LIMIT " \
                + count + " OFFSET " + offset)
            con.commit()

            rows = cur.fetchall()
            message = "";
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "last_login: %d" % row["last_login"]
                print "name: %s" % row["name"]
                print "total_point: %d" % row["total_point"]
                print "attack_point: %d" % row["attack_point"]
                print "defense_point: %d" % row["defense_point"]
                print "usability_point: %d" % row["usability_point"]
                print "n_trial_self: %d" % row["n_trial_self"]
                print "n_trial_other: %d" % row["n_trial_other"]
                print "n_ts_self: %d" % row["n_ts_self"]
                print "n_tf_self: %d" % row["n_tf_self"]
                print "n_fs_self: %d" % row["n_fs_self"]
                print "n_ff_self: %d" % row["n_ff_self"]
                print "n_ts_other: %d" % row["n_ts_other"]
                print "n_tf_other: %d" % row["n_tf_other"]
                print "n_fs_other: %d" % row["n_fs_other"]
                print "n_ff_other: %d" % row["n_ff_other"]
                sys.stdout.flush()
                #print row
                message += str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + str(row["last_login"]) \
                    + "_" + row["name"] \
                    + "_" + str(row["total_point"]) \
                    + "_" + str(row["attack_point"]) \
                    + "_" + str(row["defense_point"]) \
                    + "_" + str(row["usability_point"]) \
                    + "_" + str(row["n_trial_self"]) \
                    + "_" + str(row["n_trial_other"]) \
                    + "_" + str(row["n_ts_self"]) \
                    + "_" + str(row["n_tf_self"]) \
                    + "_" + str(row["n_fs_self"]) \
                    + "_" + str(row["n_ff_self"]) \
                    + "_" + str(row["n_ts_other"]) \
                    + "_" + str(row["n_tf_other"]) \
                    + "_" + str(row["n_fs_other"]) \
                    + "_" + str(row["n_ff_other"]) + " "

            if len(message) == 0:
                message = "[WARNING] No such users in rank " \
                    + str(int(offset) + 1) + "~" + str(int(offset) + int(count))

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        
        return message

    def LookupUsersByScore(self, low_score, high_score):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * from user WHERE total_point BETWEEN " \
                + str(low_score) + " AND " \
                + str(high_score) + " ORDER BY total_point DESC")
            con.commit()

            rows = cur.fetchall()
            message = "";
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "last_login: %d" % row["last_login"]
                print "name: %s" % row["name"]
                print "total_point: %d" % row["total_point"]
                print "attack_point: %d" % row["attack_point"]
                print "defense_point: %d" % row["defense_point"]
                print "usability_point: %d" % row["usability_point"]
                print "n_trial_self: %d" % row["n_trial_self"]
                print "n_trial_other: %d" % row["n_trial_other"]
                print "n_ts_self: %d" % row["n_ts_self"]
                print "n_tf_self: %d" % row["n_tf_self"]
                print "n_fs_self: %d" % row["n_fs_self"]
                print "n_ff_self: %d" % row["n_ff_self"]
                print "n_ts_other: %d" % row["n_ts_other"]
                print "n_tf_other: %d" % row["n_tf_other"]
                print "n_fs_other: %d" % row["n_fs_other"]
                print "n_ff_other: %d" % row["n_ff_other"]
                sys.stdout.flush()
                #print row
                message += str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + str(row["last_login"]) \
                    + "_" + row["name"] \
                    + "_" + str(row["total_point"]) \
                    + "_" + str(row["attack_point"]) \
                    + "_" + str(row["defense_point"]) \
                    + "_" + str(row["usability_point"]) \
                    + "_" + str(row["n_trial_self"]) \
                    + "_" + str(row["n_trial_other"]) \
                    + "_" + str(row["n_ts_self"]) \
                    + "_" + str(row["n_tf_self"]) \
                    + "_" + str(row["n_fs_self"]) \
                    + "_" + str(row["n_ff_self"]) \
                    + "_" + str(row["n_ts_other"]) \
                    + "_" + str(row["n_tf_other"]) \
                    + "_" + str(row["n_fs_other"]) \
                    + "_" + str(row["n_ff_other"]) + " "

            if len(message) == 0:
                message = "[WARNING] No such users in " + str(low_score) \
                    + " and " + str(high_score)

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        
        return message

    def CreateUser(self, device_id, time, last_login, name, \
                total_point, attack_point, defense_point, \
                usability_point, n_trial_self, n_trial_other, n_ts_self, n_tf_self, \
                n_fs_self, n_ff_self, n_ts_other, n_tf_other, n_fs_other, n_ff_other):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * from user WHERE name = '" + name + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) != 0:
                message = "[WARNING] already existing user"
                return message

            cur.execute("INSERT INTO user (device_id, time, last_login, name, \
                total_point, attack_point, \
                defense_point, usability_point, n_trial_self, n_trial_other, \
                n_ts_self, n_tf_self, n_fs_self, n_ff_self, \
                n_ts_other, n_tf_other, n_fs_other, n_ff_other) \
                values('" + device_id \
                + "', " + time \
                + ", " + last_login \
                + ", '" + name \
                + "', " + total_point \
                + ", " + attack_point \
                + ", " + defense_point \
                + ", " + usability_point \
                + ", " + n_trial_self \
                + ", " + n_trial_other \
                + ", " + n_ts_self \
                + ", " + n_tf_self \
                + ", " + n_fs_self \
                + ", " + n_ff_self \
                + ", " + n_ts_other \
                + ", " + n_tf_other \
                + ", " + n_fs_other \
                + ", " + n_ff_other + ")")
            con.commit()

            cur.execute("SELECT * FROM user WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "last_login: %d" % row["last_login"]
                print "name: %s" % row["name"]
                print "total_point: %d" % row["total_point"]
                print "attack_point: %d" % row["attack_point"]
                print "defense_point: %d" % row["defense_point"]
                print "usability_point: %d" % row["usability_point"]
                print "n_trial_self: %d" % row["n_trial_self"]
                print "n_trial_other: %d" % row["n_trial_other"]
                print "n_ts_self: %d" % row["n_ts_self"]
                print "n_tf_self: %d" % row["n_tf_self"]
                print "n_fs_self: %d" % row["n_fs_self"]
                print "n_ff_self: %d" % row["n_ff_self"]
                print "n_ts_other: %d" % row["n_ts_other"]
                print "n_tf_other: %d" % row["n_tf_other"]
                print "n_fs_other: %d" % row["n_fs_other"]
                print "n_ff_other: %d" % row["n_ff_other"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + str(row["last_login"]) \
                    + "_" + row["name"] \
                    + "_" + str(row["total_point"]) \
                    + "_" + str(row["attack_point"]) \
                    + "_" + str(row["defense_point"]) \
                    + "_" + str(row["usability_point"]) \
                    + "_" + str(row["n_trial_self"]) \
                    + "_" + str(row["n_trial_other"]) \
                    + "_" + str(row["n_ts_self"]) \
                    + "_" + str(row["n_tf_self"]) \
                    + "_" + str(row["n_fs_self"]) \
                    + "_" + str(row["n_ff_self"]) \
                    + "_" + str(row["n_ts_other"]) \
                    + "_" + str(row["n_tf_other"]) \
                    + "_" + str(row["n_fs_other"]) \
                    + "_" + str(row["n_ff_other"])
                break

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message


    def UpdateUser(self, device_id, time, last_login, name, total_point, attack_point, defense_point, \
                usability_point, n_trial_self, n_trial_other, n_ts_self, n_tf_self, \
                n_fs_self, n_ff_self, n_ts_other, n_tf_other, n_fs_other, n_ff_other):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            query = "UPDATE user SET ";
            set_items = 0;
            if len(time) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " time = " + str(time)

            if len(last_login) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " last_login = " + str(last_login)

            if len(total_point) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " total_point = " + str(total_point)

            if len(attack_point) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " attack_point = " + str(attack_point)

            if len(defense_point) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " defense_point = " + str(defense_point)

            if len(usability_point) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " usability_point = " + str(usability_point)

            if len(n_trial_self) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_trial_self = " + str(n_trial_self)

            if len(n_trial_other) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_trial_other = " + str(n_trial_other)

            if len(n_ts_self) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_ts_self = " + str(n_ts_self)

            if len(n_tf_self) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_tf_self = " + str(n_tf_self)

            if len(n_fs_self) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_fs_self = " + str(n_fs_self)

            if len(n_ff_self) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_ff_self = " + str(n_ff_self)

            if len(n_ts_other) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_ts_other = " + str(n_ts_other)

            if len(n_tf_other) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_tf_other = " + str(n_tf_other)

            if len(n_fs_other) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_fs_other = " + str(n_fs_other)

            if len(n_ff_other) > 0:
                if set_items != 0:
                    query += ","
                set_items += 1
                query += " n_ff_other = " + str(n_ff_other)

            query += " WHERE name = '" + name + "' AND device_id = '" + device_id + "'"
            cur.execute(query)
            con.commit()

            cur.execute("SELECT * FROM user WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            message = "[WARNING] No such a user called '" + name + "'"
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "last_login: %d" % row["last_login"]
                print "name: %s" % row["name"]
                print "total_point: %d" % row["total_point"]
                print "attack_point: %d" % row["attack_point"]
                print "defense_point: %d" % row["defense_point"]
                print "usability_point: %d" % row["usability_point"]
                print "n_trial_self: %d" % row["n_trial_self"]
                print "n_trial_other: %d" % row["n_trial_other"]
                print "n_ts_self: %d" % row["n_ts_self"]
                print "n_tf_self: %d" % row["n_tf_self"]
                print "n_fs_self: %d" % row["n_fs_self"]
                print "n_ff_self: %d" % row["n_ff_self"]
                print "n_ts_other: %d" % row["n_ts_other"]
                print "n_tf_other: %d" % row["n_tf_other"]
                print "n_fs_other: %d" % row["n_fs_other"]
                print "n_ff_other: %d" % row["n_ff_other"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + str(row["last_login"]) \
                    + "_" + row["name"] \
                    + "_" + str(row["total_point"]) \
                    + "_" + str(row["attack_point"]) \
                    + "_" + str(row["defense_point"]) \
                    + "_" + str(row["usability_point"]) \
                    + "_" + str(row["n_trial_self"]) \
                    + "_" + str(row["n_trial_other"]) \
                    + "_" + str(row["n_ts_self"]) \
                    + "_" + str(row["n_tf_self"]) \
                    + "_" + str(row["n_fs_self"]) \
                    + "_" + str(row["n_ff_self"]) \
                    + "_" + str(row["n_ts_other"]) \
                    + "_" + str(row["n_tf_other"]) \
                    + "_" + str(row["n_fs_other"]) \
                    + "_" + str(row["n_ff_other"])
                break

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def DeleteUser(self, device_id, name):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM user WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) == 0:
                message = "[WARNING] No such a user called '" + name + "'"
                return message

            cur.execute("DELETE FROM user WHERE name = '" + name \
                    + "' AND device_id = '" + device_id + "'")
            con.commit()
            message = "The user '" + name + "' has been successfully deleted."

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + int(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

class UserProfileHTTPHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse.urlparse(self.path)
        ##message = 'DEBUG INFO\n' + '\n'.join(['CLIENT:', 'client_addr=%s (%s)' 
        ##    % (self.client_address, self.address_string()), 
        ##    'command=%s' % self.command, 'path=%s' % self.path,
        ##    'real_path=%s' % parsed_path.path,
        ##    'query=%s' % parsed_path.query, 'request_ver=%s' % self.request_version,
        ##    '',
        ##    'SERVER:', 'server_ver=%s' % self.server_version, 'sys_ver=%s' % self.sys_version,
        ##    'protocol_ver=%s' % self.protocol_version, ''])
        ##print message
        sys.stdout.flush()
        reg = re.compile('(\w+)[=]([\w\s\-_.,]+)?')
        dict_query = dict(reg.findall(parsed_path.query))

        up = UserProfile()

        message = ""
        no_sufficient_info = False;
        if 'query' in dict_query.keys():
            query = dict_query['query']
        else:
            query = ""
        if query == 'log_in':
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'name' field on your query\n"
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'last_login' in dict_query.keys():
                last_login = dict_query['last_login']
                print "last_login: %d" % int(last_login)
            else:
                message += "[ERROR] No 'last_login' field on your query\n"
                no_sufficient_info = True;
            if no_sufficient_info == False:
                message = up.LogIn(device_id, name, last_login)
        elif query == 'count_users':
            message = up.CountUsers()
        elif query == 'lookup_user':
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'name' field on your query\n"
            if no_sufficient_info == False:
                message = up.LookupUser(name)
        elif query == 'lookup_user_rank':
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'name' field on your query\n"
            if no_sufficient_info == False:
                message = up.LookupUserRank(name)
        elif query == 'lookup_users_by_rank':
            if 'offset' in dict_query.keys():
                offset = dict_query['offset']
                print "offset: %s" % offset
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'offset' field on your query\n"
            if 'count' in dict_query.keys():
                count = dict_query['count']
                print "count: %s" % count
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'count' field on your query\n"
            if no_sufficient_info == False:
                message = up.LookupUsersByRank(offset, count)
        elif query == 'lookup_users_by_score':
            if 'low_score' in dict_query.keys():
                low_score= int(dict_query['low_score'])
                print "Score From: %d" % low_score
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'low_score' field on your query\n"
            if 'high_score' in dict_query.keys():
                high_score= int(dict_query['high_score'])
                print "Score To: %d" % high_score
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'high_score' field on your query\n"
            if no_sufficient_info == False:
                message = up.LookupUsersByScore(low_score, high_score)
        elif query == 'create_user':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                message += "[ERROR] No 'name' field on your query\n"
                no_sufficient_info = True;
            if 'time' in dict_query.keys():
                time = dict_query['time']
                print "time: %d" % int(time)
            else:
                message += "[ERROR] No 'time' field on your query\n"
                no_sufficient_info = True;
            if 'last_login' in dict_query.keys():
                last_login = dict_query['last_login']
                print "last_login: %d" % int(last_login)
            else:
                message += "[ERROR] No 'last_login' field on your query\n"
                no_sufficient_info = True;
            if 'total_point' in dict_query.keys():
                total_point = dict_query['total_point']
                print "total_point: %d" % int(total_point)
            else:
                message += "[ERROR] No 'total_point' field on your query\n"
                no_sufficient_info = True;
            if 'attack_point' in dict_query.keys():
                attack_point = dict_query['attack_point']
                print "attack_point: %d" % int(attack_point)
            else:
                message += "[ERROR] No 'attack_point' field on your query\n"
                no_sufficient_info = True;
            if 'defense_point' in dict_query.keys():
                defense_point = dict_query['defense_point']
                print "defense_point: %d" % int(defense_point)
            else:
                message += "[ERROR] No 'defense_point' field on your query\n"
                no_sufficient_info = True;
            if 'usability_point' in dict_query.keys():
                usability_point = dict_query['usability_point']
                print "usability_point: %d" % int(usability_point)
            else:
                message += "[ERROR] No 'usability_point' field on your query\n"
                no_sufficient_info = True;
            if 'n_trial_self' in dict_query.keys():
                n_trial_self = dict_query['n_trial_self']
                print "n_trial_self: %d" % int(n_trial_self)
            else:
                message += "[ERROR] No 'n_trial_self' field on your query\n"
                no_sufficient_info = True;
            if 'n_trial_other' in dict_query.keys():
                n_trial_other = dict_query['n_trial_other']
                print "n_trial_other: %d" % int(n_trial_other)
            else:
                message += "[ERROR] No 'n_trial_other' field on your query\n"
                no_sufficient_info = True;
            if 'n_ts_self' in dict_query.keys():
                n_ts_self = dict_query['n_ts_self']
                print "n_ts_self: %d" % int(n_ts_self)
            else:
                message += "[ERROR] No 'n_ts_self' field on your query\n"
                no_sufficient_info = True;
            if 'n_tf_self' in dict_query.keys():
                n_tf_self = dict_query['n_tf_self']
                print "n_tf_self: %d" % int(n_tf_self)
            else:
                message += "[ERROR] No 'n_tf_self' field on your query\n"
                no_sufficient_info = True;
            if 'n_fs_self' in dict_query.keys():
                n_fs_self = dict_query['n_fs_self']
                print "n_fs_self: %d" % int(n_fs_self)
            else:
                message += "[ERROR] No 'n_fs_self' field on your query\n"
                no_sufficient_info = True;
            if 'n_ff_self' in dict_query.keys():
                n_ff_self = dict_query['n_ff_self']
                print "n_ff_self: %d" % int(n_ff_self)
            else:
                message += "[ERROR] No 'n_ff_self' field on your query\n"
                no_sufficient_info = True;
            if 'n_ts_other' in dict_query.keys():
                n_ts_other = dict_query['n_ts_other']
                print "n_ts_other: %d" % int(n_ts_other)
            else:
                message += "[ERROR] No 'n_ts_other' field on your query\n"
                no_sufficient_info = True;
            if 'n_tf_other' in dict_query.keys():
                n_tf_other = dict_query['n_tf_other']
                print "n_tf_other: %d" % int(n_tf_other)
            else:
                message += "[ERROR] No 'n_tf_other' field on your query\n"
                no_sufficient_info = True;
            if 'n_fs_other' in dict_query.keys():
                n_fs_other = dict_query['n_fs_other']
                print "n_fs_other: %d" % int(n_fs_other)
            else:
                message += "[ERROR] No 'n_fs_other' field on your query\n"
                no_sufficient_info = True;
            if 'n_ff_other' in dict_query.keys():
                n_ff_other = dict_query['n_ff_other']
                print "n_ff_other: %d" % int(n_ff_other)
            else:
                message += "[ERROR] No 'n_ff_other' field on your query\n"
                no_sufficient_info = True;
            if no_sufficient_info == False:
                message = up.CreateUser(device_id, time, last_login, \
                    name, total_point, \
                    attack_point, defense_point, \
                    usability_point, n_trial_self, n_trial_other, \
                    n_ts_self, n_tf_self, \
                    n_fs_self, n_ff_self, \
                    n_ts_other, n_tf_other, \
                    n_fs_other, n_ff_other)
        elif query == 'update_user':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                message += "[ERROR] No 'name' field on your query\n"
                no_sufficient_info = True;
            if 'time' in dict_query.keys():
                time = dict_query['time']
                print "time: %d" % int(time)
            else:
                time = ""
            if 'last_login' in dict_query.keys():
                last_login = dict_query['last_login']
                print "last_login: %d" % int(last_login)
            else:
                last_login = ""
            if 'total_point' in dict_query.keys():
                total_point = dict_query['total_point']
                print "total_point: %d" % int(total_point)
            else:
                total_point = ""
            if 'attack_point' in dict_query.keys():
                attack_point = dict_query['attack_point']
                print "attack_point: %d" % int(attack_point)
            else:
                attack_point = ""
            if 'defense_point' in dict_query.keys():
                defense_point = dict_query['defense_point']
                print "defense_point: %d" % int(defense_point)
            else:
                defense_point = ""
            if 'usability_point' in dict_query.keys():
                usability_point = dict_query['usability_point']
                print "usability_point: %d" % int(usability_point)
            else:
                usability_point = ""
            if 'n_trial_self' in dict_query.keys():
                n_trial_self = dict_query['n_trial_self']
                print "n_trial_self: %d" % int(n_trial_self)
            else:
                n_trial_self = ""
            if 'n_trial_other' in dict_query.keys():
                n_trial_other = dict_query['n_trial_other']
                print "n_trial_other: %d" % int(n_trial_other)
            else:
                n_trial_other = ""
            if 'n_ts_self' in dict_query.keys():
                n_ts_self = dict_query['n_ts_self']
                print "n_ts_self: %d" % int(n_ts_self)
            else:
                n_ts_self = ""
            if 'n_tf_self' in dict_query.keys():
                n_tf_self = dict_query['n_tf_self']
                print "n_tf_self: %d" % int(n_tf_self)
            else:
                n_tf_self = ""
            if 'n_fs_self' in dict_query.keys():
                n_fs_self = dict_query['n_fs_self']
                print "n_fs_self: %d" % int(n_fs_self)
            else:
                n_fs_self = ""
            if 'n_ff_self' in dict_query.keys():
                n_ff_self = dict_query['n_ff_self']
                print "n_ff_self: %d" % int(n_ff_self)
            else:
                n_ff_self = ""
            if 'n_ts_other' in dict_query.keys():
                n_ts_other = dict_query['n_ts_other']
                print "n_ts_other: %d" % int(n_ts_other)
            else:
                n_ts_other = ""
            if 'n_tf_other' in dict_query.keys():
                n_tf_other = dict_query['n_tf_other']
                print "n_tf_other: %d" % int(n_tf_other)
            else:
                n_tf_other = ""
            if 'n_fs_other' in dict_query.keys():
                n_fs_other = dict_query['n_fs_other']
                print "n_fs_other: %d" % int(n_fs_other)
            else:
                n_fs_other = ""
            if 'n_ff_other' in dict_query.keys():
                n_ff_other = dict_query['n_ff_other']
                print "n_ff_other: %d" % int(n_ff_other)
            else:
                n_ff_other = ""
            if no_sufficient_info == False:
                message = up.UpdateUser(device_id, time, last_login, \
                    name, total_point, \
                    attack_point, defense_point, \
                    usability_point, n_trial_self, n_trial_other, \
                    n_ts_self, n_tf_self, \
                    n_fs_self, n_ff_self, \
                    n_ts_other, n_tf_other, \
                    n_fs_other, n_ff_other)
        elif query == 'delete_user':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                message += "[ERROR] No 'name' field on your query\n"
                no_sufficient_info = True;
            if no_sufficient_info == False:
                message = up.DeleteUser(device_id, name)
        else:
            message = "[ERROR] I don't understand (may be WRONG query)"

        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(message)
        return


class ThreadedHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
    """ Handle request in a separate thread"""

class UserProfileDaemon(Daemon):
    def run(self):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT VERSION()")

            ver = cur.fetchone()
            print "MySQL database version: %s " % ver

            #cur.execute("DROP TABLE IF EXISTS user")
            cur.execute("CREATE TABLE IF NOT EXISTS user (id int primary key auto_increment, \
                device_id varchar(36), \
                time int, \
                last_login int, \
                name varchar(12), \
                total_point int, \
                attack_point int, \
                defense_point int, \
                usability_point int, \
                n_trial_self int, \
                n_trial_other int, \
                n_ts_self int, \
                n_tf_self int, \
                n_fs_self int, \
                n_ff_self int, \
                n_ts_other int, \
                n_tf_other int, \
                n_fs_other int, \
                n_ff_other int)")

            #for i in range(0, 1000):
            #    cur.execute("INSERT INTO user (time, last_login, name, total_point, attack_point, \
            #        defense_point, usability_point, n_trial_self, n_trial_other, \
            #        n_ts_self, n_tf_self, n_fs_self, n_ff_self, \
            #        n_ts_other, n_tf_other, n_fs_other, n_ff_other) \
            #        values(" + str(random.randrange(1,65536)) \
            #        + ", " + str(random.randrange(1,65536)) \
            #        + ", '" + "antiroot" + str(i) \
            #        + "', " + str(random.randrange(1,65536)) \
            #        + ", 400, 300, 400, 50, 30, 10, 15, 20, 25, 8, 7, 6, 5)")
            con.commit()
    
        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            sys.exit(1)

        finally:
            if con:
                con.close()

        server = ThreadedHTTPServer(('pepperjack.stanford.edu', 8000), UserProfileHTTPHandler)
        print 'Starting User Profile HTTP Server, with 8000 port'
        sys.stdout.flush()
        server.serve_forever()


if __name__ == '__main__':
    d = os.path.dirname("./log")
    if not os.path.exists("./log"):
        os.system("mkdir ./log")

    d = os.path.dirname("./pid")
    if not os.path.exists("./pid"):
        os.system("mkdir ./pid")

    outfilepath = os.path.abspath("./log/user_profile.out")
    errfilepath = os.path.abspath("./log/user_profile.err")
    pidfilepath = os.path.abspath("./pid/user_profile.pid")

    daemon = UserProfileDaemon(pidfilepath, \
            "/dev/null", outfilepath, errfilepath)

    if len(sys.argv) == 2:
        if "start" == sys.argv[1]:
            daemon.start()
        elif "stop" == sys.argv[1]:
            daemon.stop()
        elif "restart" == sys.argv[1]:
            daemon.restart()
        else:
            print "Error: unknown command"
            sys.stdout.flush()
            sys.exit(1)
        sys.exit(0)
    else:
        print "Usage: %s start|stop|restart" % sys.argv[0]
        sys.stdout.flush()
        sys.exit(2)



