#!/usr/bin/python
# -*- coding: utf-8 -*-

import BaseHTTPServer
import urlparse
import SocketServer
import threading
import cgi
import MySQLdb as mdb
import sys
from xml.dom.minidom import parseString
import re
import random
import os
from daemon import Daemon
try:
    from xml.etree import cElementTree as ElementTree
except ImportError, e:
    from xml.etree import ElementTree

class BattHistory:
    message = ""
    def __init__(self):
        print "---------------------"
        sys.stdout.flush()

    def __del__(self):
        sys.stdout.flush()

    def LookupBattHistory(self, name):
        message = ""
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM batt_history WHERE pname = '" \
                + name + "' OR oname ='" + name + "' ORDER BY time desc")
            con.commit()

            rows = cur.fetchall()
            message = ""
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "pname: %s" % row["pname"]
                print "oname: %s" % row["oname"]
                print "ppoint: %d" % row["ppoint"]
                print "opoint: %d" % row["opoint"]
                print "rpoint: %d" % row["rpoint"]
                print "manifest: %d" % row["manifest"]
                sys.stdout.flush()
                #print row
                message += str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + row["pname"] \
                    + "_" + row["oname"] \
                    + "_" + str(row["ppoint"]) \
                    + "_" + str(row["opoint"]) \
                    + "_" + str(row["rpoint"]) \
                    + "_" + str(row["manifest"]) + " "

            if len(message) == 0:
                message = "[WARNING] No such a batt_history from a user called '" + name + "'"

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + str(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def CreateBattHistory(self, device_id, time, pname, oname, \
        ppoint, opoint, rpoint, manifest):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("LOCK TABLES user WRITE, batt_history WRITE")
            con.commit()
            cur.execute("SELECT * FROM batt_history WHERE pname = '" + pname \
                + "' AND oname = '" + oname \
                + "' AND ppoint = " + ppoint \
                + " AND opoint = " + opoint \
                + " AND rpoint = " + rpoint \
                + " AND manifest = " + manifest \
                + " AND time > " + str(int(time) - 10) \
                + " AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) != 0:
                message = "[WARNING] The same batt_history record is inserted recently, so I ignore this request."
                return message

            cur.execute("INSERT INTO batt_history (device_id, time, \
                pname, oname, ppoint, opoint, rpoint, manifest) values('" \
                + device_id + "', " + time + ", '" + pname + "', '" + oname + "', " \
                + ppoint + ", " + opoint + ", " + rpoint + ", " \
                + manifest + ")")
            con.commit()

            cur.execute("SELECT * FROM batt_history WHERE pname = '" + pname \
                + "' AND oname = '" + oname \
                + "' AND ppoint = " + ppoint \
                + " AND opoint = " + opoint \
                + " AND rpoint = " + rpoint \
                + " AND manifest = " + manifest \
                + " AND time = " + time \
                + " AND device_id = '" + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            for row in rows:
                print "id: %d" % row["id"]
                print "time: %d" % row["time"]
                print "pname: %s" % row["pname"]
                print "oname: %s" % row["oname"]
                print "ppoint: %d" % row["ppoint"]
                print "opoint: %d" % row["opoint"]
                print "rpoint: %d" % row["rpoint"]
                print "manifest: %d" % row["manifest"]
                sys.stdout.flush()
                #print row
                message = str(row["id"]) \
                    + "_" + str(row["time"]) \
                    + "_" + row["pname"] \
                    + "_" + row["oname"] \
                    + "_" + str(row["ppoint"]) \
                    + "_" + str(row["opoint"]) \
                    + "_" + str(row["rpoint"]) \
                    + "_" + str(row["manifest"]) 
                break

            if int(manifest) == 1: #WON
                #UPDATE pname & oname's profile
                n_trial_self = 0
                n_trial_other = 0
                n_fs_self = 0
                n_fs_other = 0
                total_point_self = 0
                total_point_other = 0
                attack_point = 0
                defense_point = 0
                cur.execute("SELECT * FROM user WHERE name = '" + pname + "'")
                con.commit()
                rows = cur.fetchall()
                for row in rows:
                    n_trial_self = row["n_trial_self"]
                    n_fs_self = row["n_fs_self"]
                    total_point_self = row["total_point"]
                    attack_point = row["attack_point"]
                    break;
                cur.execute("SELECT * FROM user WHERE name = '" + oname + "'")
                con.commit()
                rows = cur.fetchall()
                for row in rows:
                    n_trial_other = row["n_trial_other"]
                    n_fs_other = row["n_fs_other"]
                    total_point_other = row["total_point"]
                    defense_point = row["defense_point"]
                    break;
                cur.execute("UPDATE user SET " \
                        + "total_point = " + ppoint \
                        + ", attack_point = " + str(attack_point + int(rpoint)) \
                        + ", n_trial_self = " + str(n_trial_self + 1) \
                        + ", n_fs_self = " + str(n_fs_self + 1) \
                        + " WHERE name = '" + pname + "'")
                con.commit()
                cur.execute("UPDATE user SET " \
                        + "total_point = " + opoint \
                        + ", defense_point = " + str(defense_point - int(rpoint)) \
                        + ", n_trial_other = " + str(n_trial_other + 1) \
                        + ", n_fs_other = " + str(n_fs_other + 1) \
                        + " WHERE name = '" + oname + "'")
                con.commit()
                print "test won"
                sys.stdout.flush()

            elif int(manifest) == 2: #LOST
                #UPDATE pname & oname's profile
                n_trial_self = 0
                n_trial_other = 0
                n_tf_self = 0
                n_tf_other = 0
                total_point_self = 0
                total_point_other = 0
                attack_point = 0
                defense_point = 0
                cur.execute("SELECT * FROM user WHERE name = '" + pname + "'")
                con.commit()
                rows = cur.fetchall()
                for row in rows:
                    n_trial_self = row["n_trial_self"]
                    n_tf_self = row["n_tf_self"]
                    total_point_self = row["total_point"]
                    attack_point = row["attack_point"]
                    break;
                cur.execute("SELECT * FROM user WHERE name = '" + oname + "'")
                con.commit()
                rows = cur.fetchall()
                for row in rows:
                    n_trial_other = row["n_trial_other"]
                    n_tf_other = row["n_tf_other"]
                    total_point_other = row["total_point"]
                    defense_point = row["defense_point"]
                    break;
                cur.execute("UPDATE user SET " \
                        + "total_point = " + ppoint \
                        + ", attack_point = " + str(attack_point + int(rpoint)) \
                        + ", n_trial_self = " + str(n_trial_self + 1) \
                        + ", n_tf_self = " + str(n_tf_self + 1) \
                        + " WHERE name = '" + pname + "'")
                con.commit()
                cur.execute("UPDATE user SET " \
                        + "total_point = " + opoint \
                        + ", defense_point = " + str(defense_point - int(rpoint)) \
                        + ", n_trial_other = " + str(n_trial_other + 1) \
                        + ", n_tf_other = " + str(n_tf_other + 1) \
                        + " WHERE name = '" + oname + "'")
                con.commit()
                print "test lost"
                sys.stdout.flush()

            elif int(manifest) == 4: #SUCCESS
                #UPDATE pname's profile
                n_trial_self = 0
                n_ts_self = 0
                usability_point = 0
                cur.execute("SELECT * FROM user WHERE name = '" + pname + "'")
                con.commit()
                rows = cur.fetchall()
                for row in rows:
                    n_trial_self = row["n_trial_self"]
                    n_ts_self = row["n_ts_self"]
                    usability_point = row["usability_point"]
                    break;
                cur.execute("UPDATE user SET " \
                        + "total_point = " + ppoint \
                        + ", usability_point = " + str(usability_point + int(rpoint)) \
                        + ", n_trial_self = " + str(n_trial_self + 1) \
                        + ", n_ts_self = " + str(n_ts_self + 1) \
                        + " WHERE name = '" + pname + "'")
                con.commit()
                
            elif int(manifest) == 5: #FAIL
                #UPDATE pname's profile
                n_trial_self = 0
                n_ff_self = 0
                usability_point = 0
                cur.execute("SELECT * FROM user WHERE name = '" + pname + "'")
                con.commit()
                rows = cur.fetchall()
                for row in rows:
                    n_trial_self = row["n_trial_self"]
                    n_ff_self = row["n_ff_self"]
                    usability_point = row["usability_point"]
                    break;
                cur.execute("UPDATE user SET " \
                        + "total_point = " + ppoint \
                        + ", usability_point = " + str(usability_point + int(rpoint)) \
                        + ", n_trial_self = " + str(n_trial_self + 1) \
                        + ", n_ff_self = " + str(n_ff_self + 1) \
                        + " WHERE name = '" + pname + "'")
                con.commit()

            cur.execute("UNLOCK TABLES")
            con.commit()

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            cur.execute("UNLOCK TABLES")
            con.commit()
            message = "[ERROR] " + str(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

    def DeleteBattHistory(self, device_id, name):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT * FROM batt_history WHERE (pname = '" \
                + name + "' OR oname ='" + name + "') AND device_id = '" \
                + device_id + "'")
            con.commit()
            rows = cur.fetchall()
            if len(rows) == 0:
                message = "[WARNING] No such a batt_history from a user called '" + name + "'"
                return message

            cur.execute("DELETE FROM batt_history WHERE (pname = '" \
                + name + "' OR oname ='" + name + "') AND device_id = '" \
                + device_id + "'")
            con.commit()
            message = "The batt_history of a user '" + name + "' has been successfully deleted."

        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            message = "[ERROR] " + str(e.args[0]) + ": " + str(e.args[1])
            return message

        finally:
            if con:
                con.close()
        return message

class BattHistoryHTTPHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse.urlparse(self.path)
        ##message = 'DEBUG INFO\n' + '\n'.join(['CLIENT:', 'client_addr=%s (%s)' 
        ##    % (self.client_address, self.address_string()), 
        ##    'command=%s' % self.command, 'path=%s' % self.path,
        ##    'real_path=%s' % parsed_path.path,
        ##    'query=%s' % parsed_path.query, 'request_ver=%s' % self.request_version,
        ##    '',
        ##    'SERVER:', 'server_ver=%s' % self.server_version, 'sys_ver=%s' % self.sys_version,
        ##    'protocol_ver=%s' % self.protocol_version, ''])
        ##print message
        reg = re.compile('(\w+)[=]([\w\s\-\(\)_,]+)?')
        dict_query = dict(reg.findall(parsed_path.query))

        cp = BattHistory()

        message = ""
        no_sufficient_info = False;
        if 'query' in dict_query.keys():
            query = dict_query['query']
        else:
            query = ""
        if query == 'lookup_batt_history':
            if 'name' in dict_query.keys():
                print "name: %s" % dict_query['name']
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'name' field on your query\n"
            if no_sufficient_info == False:
                message = cp.LookupBattHistory(dict_query['name'])
        elif query == 'create_batt_history':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'time' in dict_query.keys():
                time = dict_query['time']
                print "time: %d" % int(time)
            else:
                message += "[ERROR] No 'time' field on your query\n"
                no_sufficient_info = True;
            if 'pname' in dict_query.keys():
                pname = dict_query['pname']
                print "pname: %s" % pname
            else:
                message += "[ERROR] No 'pname' field on your query\n"
                no_sufficient_info = True;
            if 'oname' in dict_query.keys():
                oname = dict_query['oname']
                print "oname: %s" % oname
            else:
                oname = ""
            #    message += "[ERROR] No 'oname' field on your query\n"
            #    no_sufficient_info = True;
            if 'ppoint' in dict_query.keys():
                ppoint = dict_query['ppoint']
                print "ppoint: %d" % int(ppoint)
            else:
                message += "[ERROR] No 'ppoint' field on your query\n"
                no_sufficient_info = True;
            if 'opoint' in dict_query.keys():
                opoint = dict_query['opoint']
                print "opoint: %d" % int(opoint)
            else:
                opoint = "0"
            #    message += "[ERROR] No 'opoint' field on your query\n"
            #    no_sufficient_info = True;
            if 'rpoint' in dict_query.keys():
                rpoint = dict_query['rpoint']
                print "rpoint: %d" % int(rpoint)
            else:
                message += "[ERROR] No 'rpoint' field on your query\n"
                no_sufficient_info = True;
            if 'manifest' in dict_query.keys():
                manifest = dict_query['manifest']
                print "manifest: %d" % int(manifest)
            else:
                message += "[ERROR] No 'manifest' field on your query\n"
                no_sufficient_info = True;
            if no_sufficient_info == False:
                message = cp.CreateBattHistory(device_id, \
                    time, pname, oname, ppoint, opoint, rpoint, manifest)
        elif query == 'delete_batt_history':
            if 'device_id' in dict_query.keys():
                device_id = dict_query['device_id']
                print "device_id: %s" % device_id
            else:
                no_sufficient_info = True;
                message += "[ERROR] No 'device_id' field on your query\n"
            if 'name' in dict_query.keys():
                name = dict_query['name']
                print "name: %s" % name
            else:
                message += "[ERROR] No 'name' field on your query\n"
                no_sufficient_info = True;
            if no_sufficient_info == False:
                message = cp.DeleteBattHistory(device_id, name)
        else:
            message = "[ERROR] I don't understand (may be WRONG query)"

        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(message)
        return


class ThreadedHTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
    """ Handle request in a separate thread"""

class BattHistoryDaemon(Daemon):
    def run(self):
        try:
            con = mdb.connect('localhost', 'shyi', '', 'byot')
            cur = con.cursor(mdb.cursors.DictCursor)
            cur.execute("SELECT VERSION()")

            ver = cur.fetchone()
            print "MySQL database version: %s " % ver

            #cur.execute("DROP TABLE IF EXISTS batt_history")
            cur.execute("CREATE TABLE IF NOT EXISTS batt_history (id int primary key auto_increment, \
                device_id varchar(36), \
                time int, \
                pname varchar(12), \
                oname varchar(12), \
                ppoint int, \
                opoint int, \
                rpoint int, \
                manifest int)")

            #for i in range(0, 1000):
            #    cur.execute("INSERT INTO batt_history " \
            #        + "(time, pname, oname, ppoint, opoint, rpoint, manifest) values (" \
            #        + str(random.randrange(1, 65536)) + ", '" + "antiroot" \
            #        + str(i) + "', 'opponent" + str(i%100) + "', " \
            #        + str(random.randrange(900, 1200)) + ", " + str(random.randrange(800,1500)) + ", " \
            #        + str(random.randrange(10,50)) + ", " + str(random.randrange(1,2)) + ")")
            con.commit()
    
        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            sys.stdout.flush()
            sys.exit(1)

        finally:
            if con:
                con.close()

        server = ThreadedHTTPServer(('pepperjack.stanford.edu', 8003), BattHistoryHTTPHandler)
        print 'Starting Batt History HTTP Server, with 8003 port'
        sys.stdout.flush()
        server.serve_forever()


if __name__ == '__main__':
    d = os.path.dirname("./log")
    if not os.path.exists("./log"):
        os.system("mkdir ./log")

    d = os.path.dirname("./pid")
    if not os.path.exists("./pid"):
        os.system("mkdir ./pid")

    outfilepath = os.path.abspath("./log/batt_history.out")
    errfilepath = os.path.abspath("./log/batt_history.err")
    pidfilepath = os.path.abspath("./pid/batt_history.pid")

    daemon = BattHistoryDaemon(pidfilepath, \
            "/dev/null", outfilepath, errfilepath)

    if len(sys.argv) == 2:
        if "start" == sys.argv[1]:
            daemon.start()
        elif "stop" == sys.argv[1]:
            daemon.stop()
        elif "restart" == sys.argv[1]:
            daemon.restart()
        else:
            print "Error: unknown command"
            sys.stdout.flush()
            sys.exit(1)
        sys.exit(0)
    else:
        print "Usage: %s start|stop|restart" % sys.argv[0]
        sys.stdout.flush()
        sys.exit(2)



