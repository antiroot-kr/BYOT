#/bin/bash

mysql -D byot -e 'delete from user'
mysql -D byot -e 'delete from cell_pattern'
mysql -D byot -e 'delete from traj_pattern'
mysql -D byot -e 'delete from batt_history'

