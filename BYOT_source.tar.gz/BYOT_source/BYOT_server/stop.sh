#/bin/bash

python user_profile.py stop
python cell_pattern.py stop
python traj_pattern.py stop
python batt_history.py stop
python availability.py stop
