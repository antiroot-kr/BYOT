/** Automatically generated file. DO NOT MODIFY */
package group.pals.android.lib.ui.lockpattern;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}