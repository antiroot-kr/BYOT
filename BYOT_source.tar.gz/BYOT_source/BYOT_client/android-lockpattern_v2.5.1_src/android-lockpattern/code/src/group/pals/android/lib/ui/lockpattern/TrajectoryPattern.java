package group.pals.android.lib.ui.lockpattern;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import android.util.Log;

public class TrajectoryPattern {
	private boolean selected;
	private final int thresTime = 110;
	private final int thresDist = 36;
	private final int thresPres = 25;
	private final int thresSize = 50;
	private final int normalizer = 8192;

	public class TrajectoryPoint {
		private int time;
		private int x;
		private int y;
		private int pressure;
		private int size;
		private boolean selected;
		
		public TrajectoryPoint(){
			this.selected = true;
		}
		
		public TrajectoryPoint(final int time, final int x, final int y, final int pressure, final int size){
			this.time = time;
			this.x = x;
			this.y = y;
			this.pressure = pressure;
			this.size = size;
			this.selected = true;
		}
		
		public void setValues(int time, int x, int y, int pressure, int size){
			this.time = time;
			this.x = x;
			this.y = y;
			this.pressure = pressure;
			this.size = size;
		}
		
		public int getTime(){
			return this.time;
		}
		
		public int getX(){
			return this.x;
		}
		
		public int getY(){
			return this.y;
		}
		
		public int getPressure(){
			return this.pressure;
		}
		
		public int getSize(){
			return this.size;
		}
		
	    public void markSelect(boolean select) {
	    	this.selected = select;
	    }
	    
	    public boolean isSelected() {
	    	return this.selected;
	    }
	}
	
	List<TrajectoryPoint> mGPList;

	public TrajectoryPattern(){
		this.mGPList = new ArrayList<TrajectoryPoint>();
		this.selected = true;
	}
	
	public boolean add(TrajectoryPoint gp){
		return this.mGPList.add(gp);
	}
	
	public boolean addValues(int time, int x, int y, int pressure, int size){
		TrajectoryPoint gp = new TrajectoryPoint();
		gp.setValues(time, x, y, pressure, size);
		return this.mGPList.add(gp);
	}
	
	public void clear(){
		this.mGPList.clear();
	}
	
	public TrajectoryPoint get(int location){
		return this.mGPList.get(location);
	}
	
	public int getTime(int location){
		return this.mGPList.get(location).getTime();
	}
	
	public int getX(int location){
		return this.mGPList.get(location).getX();
	}
	
	public int getY(int location){
		return this.mGPList.get(location).getY();
	}
	
	public int getPressure(int location){
		return this.mGPList.get(location).getPressure();
	}
	
	public int getSize(int location){
		return this.mGPList.get(location).getSize();
	}
	
	public TrajectoryPoint remove(int location){
		return this.mGPList.remove(location);
	}
	
	public int size(){
		return this.mGPList.size();
	}
	
	public Iterator<TrajectoryPoint> iterator(){
		return this.mGPList.iterator();
	}
	
    public String toString() {
    	String str = "";
    	str += (selected? "1":"0") + ",";
    	for (int i=0; i<mGPList.size(); ++i) {
    		int t = mGPList.get(i).getTime();
    		int x = mGPList.get(i).getX();
    		int y = mGPList.get(i).getY();
    		int p = mGPList.get(i).getPressure();
    		int s = mGPList.get(i).getSize();
    		boolean e = mGPList.get(i).isSelected();
    		str += t + "," + x + "," + y + "," + p + "," + s + "," + (e? "1":"0") + ",";
    	}
    	return str;
    }
    
    public int setPattern(String tsString) {
    	if (tsString == null) {
    		return 1;
    	}
    	StringTokenizer tsToken = new StringTokenizer(tsString, ",");
    	TrajectoryPoint tp;
    	int i = 0;
    	int t = 0, x = 0, y = 0, p = 0, s = 0, e = 0;
    	if (tsToken.hasMoreElements()) {
    		int temp = Integer.parseInt((String) tsToken.nextElement());
    		markSelect((temp==1)? true:false);
    	}
    	while (tsToken.hasMoreElements()) {
    		int temp = Integer.parseInt((String) tsToken.nextElement());
    		switch (i % 6) {
    		case 0:
        		t = temp;
    			break;
    		case 1:
    			x = temp;
    			break;
    		case 2:
    			y = temp;
    			break;
    		case 3:
    			p = temp;
    			break;
    		case 4:
    			s = temp;
    			break;
    		case 5:
    			e = temp;
    			tp = new TrajectoryPoint();
    			tp.setValues(t, x, y, p, s);
    			tp.markSelect((e==1)? true:false);
    			mGPList.add(tp);
    			break;
    		}
    		++i;
    	}
    	return 0;
    }
    
    public int copyFrom(TrajectoryPattern tp) {
		mGPList.clear();
		selected = tp.isSelected();
    	for (int i=0; i<tp.size(); ++i) {
    		mGPList.add(tp.get(i));
    	}
    	return 0;
    }
    
    public int quantize(int gridWidth, int gridHeight) {
    	List<TrajectoryPoint> gpList = new ArrayList<TrajectoryPoint>();
    	TrajectoryPoint tp;
    	TrajectoryPoint tp1, tp2;
    	int direction = 1;
    	
    	if (mGPList.size() > 0) {
    		tp1 = mGPList.get(0);
    		//int t0 = tp1.getTime();
        	for (int i=1; i<mGPList.size(); ++i) {
        		tp2 = mGPList.get(i);
        		int t2 = tp2.getTime();// - t0;
        		int x2 = tp2.getX();
        		int y2 = tp2.getY();
        		int p2 = tp2.getPressure();
        		int s2 = tp2.getSize();
        		boolean e2 = tp2.isSelected();

        		int t1 = tp1.getTime();// - t0;
	    		int x1 = tp1.getX();
	    		int y1 = tp1.getY();
	    		int p1 = tp1.getPressure();
	    		int s1 = tp1.getSize();
	    		boolean e1 = tp1.isSelected();

				// add new GridSignal point
    			int gx = (int)(x1 / gridWidth) * gridWidth;
    			int gy = (int)(y1 / gridHeight) * gridHeight;
    			if (gpList.size() == 0
    					|| gpList.get(gpList.size()-1).getX() != gx
    					|| gpList.get(gpList.size()-1).getY() != gy) {
        			tp = new TrajectoryPoint();
        			tp.setValues(t1, gx, gy, p1, s1);
        			if (t1 < 0) {
        				t1 = 0;
        			}
        			tp.markSelect(e1);
        			gpList.add(tp);
    			}
    			
	    		// perform for loop for the line
	    		if (Math.abs(x1-x2) > Math.abs(y1-y2)) {
	    			if (x1-x2 > 0)
	    				direction = -1;
	    			else
	    				direction = 1;
	    			int x3 = gx + gridWidth * direction;
	    			while (x3 * direction < x2 * direction) {
	    				int y3 = (int)(((float)(y2-y1) / (float)(x2-x1)) * (float)(x3-x1)) + y1;
	    				int t3 = t1 + (t2-t1) * (x3-x1) / (x2-x1);
	    				int p3 = p1 + (p2-p1) * (x3-x1) / (x2-x1);
	    				int s3 = s1 + (s2-s1) * (x3-x1) / (x2-x1);
	    				
	    				// add new GridSignal point
	        			gx = (int)(x3 / gridWidth) * gridWidth;
	        			gy = (int)(y3 / gridHeight) * gridHeight;
	        			if (gpList.size() == 0
	        					|| gpList.get(gpList.size()-1).getX() != gx
	        					|| gpList.get(gpList.size()-1).getY() != gy) {
		        			tp = new TrajectoryPoint();
		        			tp.setValues(t3, gx, gy, p3, s3);
		        			if (t3 < 0) {
		        				t3 = 0;
		        			}
		        			if (e1 == false || e2 == false) {
		        				tp.markSelect(false);
		        			} else {
		        				tp.markSelect(true);
		        			}
		        			gpList.add(tp);
	        			}
	        			
	    				x3 += gridWidth * direction;
	    			}
	    		} else {
	    			if (y1-y2 > 0)
	    				direction = -1;
	    			else
	    				direction = 1;
	    			int y3 = gy + gridHeight * direction;
	    			while (y3 * direction < y2 * direction) {
	    				int x3 = (int)(((float)(x2-x1) / (float)(y2-y1)) * (float)(y3-y1)) + x1;
	    				int t3 = t1 + (t2-t1) * (y3-y1) / (y2-y1);
	    				int p3 = p1 + (p2-p1) * (y3-y1) / (y2-y1);
	    				int s3 = s1 + (s2-s1) * (y3-y1) / (y2-y1);
	    				
	    				// add new GridSignal point
	        			gx = (int)(x3 / gridWidth) * gridWidth;
	        			gy = (int)(y3 / gridHeight) * gridHeight;
	        			if (gpList.size() == 0
	        					|| gpList.get(gpList.size()-1).getX() != gx
	        					|| gpList.get(gpList.size()-1).getY() != gy) {
		        			tp = new TrajectoryPoint();
		        			tp.setValues(t3, gx, gy, p3, s3);
		        			if (t3 < 0) {
		        				t3 = 0;
		        			}
		        			if (e1 == false || e2 == false) {
		        				tp.markSelect(false);
		        			} else {
		        				tp.markSelect(true);
		        			}
		        			gpList.add(tp);
	        			}
	    				y3 += gridHeight * direction;
	    			}
	    		}
	    		tp1 = tp2;
			}
    		int t1 = tp1.getTime();// - t0;
    		int x1 = tp1.getX();
    		int y1 = tp1.getY();
    		int p1 = tp1.getPressure();
    		int s1 = tp1.getSize();
    		boolean e1 = tp1.isSelected();

			// add new GridSignal point
			int gx = (int)(x1 / gridWidth) * gridWidth;
			int gy = (int)(y1 / gridWidth) * gridWidth;
			if (gpList.size() == 0
					|| gpList.get(gpList.size()-1).getX() != gx
					|| gpList.get(gpList.size()-1).getY() != gy) {
				tp = new TrajectoryPoint();
				tp.setValues(t1, gx, gy, p1, s1);
    			if (t1 < 0) {
    				t1 = 0;
    			}
				tp.markSelect(e1);
				gpList.add(tp);
			}
			mGPList = gpList;
		}
    	return 0;
    }

    public int normalize(int viewWidth) {
    	//List<TrajectoryPoint> gpList = new ArrayList<TrajectoryPoint>();
    	TrajectoryPoint tp;
    	
    	if (mGPList.size() > 0) {
        	for (int i=0; i<mGPList.size(); ++i) {
        		tp = mGPList.get(i);
        		int t = tp.getTime();// - t0;
        		int x = tp.getX();
        		int y = tp.getY();
        		int p = tp.getPressure();
        		int s = tp.getSize();
        		boolean e = tp.isSelected();

				// add new GridSignal point
        		int nx = (int)(x * normalizer) / viewWidth;
        		int ny = (int)(y * normalizer) / viewWidth;
        		tp.setValues(t, nx, ny, p, s);
        		tp.markSelect(e);
        		mGPList.set(i, tp);
 			}
		}
    	return 0;
    }

    public int denormalize(int viewWidth) {
    	//List<TrajectoryPoint> gpList = new ArrayList<TrajectoryPoint>();
    	TrajectoryPoint tp;
    	
    	if (mGPList.size() > 0) {
        	for (int i=0; i<mGPList.size(); ++i) {
        		tp = mGPList.get(i);
        		int t = tp.getTime();// - t0;
        		int x = tp.getX();
        		int y = tp.getY();
        		int p = tp.getPressure();
        		int s = tp.getSize();
        		boolean e = tp.isSelected();

				// add new GridSignal point
        		int nx = (int)(x * viewWidth) / normalizer;
        		int ny = (int)(y * viewWidth) / normalizer;
        		tp.setValues(t, nx, ny, p, s);
        		tp.markSelect(e);
        		mGPList.set(i, tp);
 			}
		}
    	return 0;
    }
    
    public float compare(TrajectoryPattern tp) {
    	int count = 0, countAll = 0;
    	float errorRate;
    	int i, j;
		int x1, x2, y1, y2;
		int t1, t2;
		int p1, p2;
		int s1, s2;
		//int torg1, torg2;
		
		if (mGPList == null || tp == null) {
			return 1;
		}
		
		TrajectoryPattern tpShort;
		TrajectoryPattern tpLong;
		
		int dist;
		int temp;
		int j_sel = 0;
		if (mGPList.size() < tp.size()) {
			tpShort = this;
			tpLong = tp;
		} else {
			tpShort = tp;
			tpLong = this;
		}
		//torg1 = tpLong.get(0).getTime();
		//torg2 = tpShort.get(0).getTime();
		
		for (i = 0; i < tpLong.size(); ++i) {
			x1 = tpLong.get(i).getX();
			y1 = tpLong.get(i).getY();
			p1 = tpLong.get(i).getPressure();
			s1 = tpLong.get(i).getSize();
			t1 = tpLong.get(i).getTime();
			
			dist = 9999;
			for (j = j_sel = 0; j < tpShort.size(); ++j) {
    			x2 = tpShort.get(j).getX();
    			y2 = tpShort.get(j).getY();
    			temp = (int) Math.sqrt((double)((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)));
    			if (dist > temp) {
    				dist = temp;
    				j_sel = j;
        		}
    		}
			x2 = tpShort.get(j_sel).getX();
			y2 = tpShort.get(j_sel).getY();
			p2 = tpShort.get(j_sel).getPressure();
			s2 = tpShort.get(j_sel).getSize();
			t2 = tpShort.get(j_sel).getTime();
			
			//if (Math.abs((t2 - torg2) - (t1 - torg1)) > this.thresTime) {
			if (Math.abs(t2 - t1) > this.thresTime) {
				count++;
				Log.d("Touch01", "Time difference (ms) = " + Math.abs(t2 - t1));
			}
			if (Math.abs(Math.sqrt((double)((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)))) > this.thresDist) {
				count++;
				//Log.d("Touch01", "Point difference (dp) = " + Math.abs(Math.sqrt((double)((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)))));
				Log.d("Touch01", "Point difference (x1,y1) (x2,y2) = (" + x1 + "," + y1 + ") (" + x2 + "," + y2 + ")");
			}
			if (Math.abs(p2 - p1) > this.thresPres) {
				count++;
				Log.d("Touch01", "Pressure difference (0-100) = " + Math.abs(p2 - p1));				
			}
			/*if (Math.abs(s2 - s1) > this.thresSize) {
				count++;
				//Log.d("Touch01", "Size difference (0-100) = " + Math.abs(s2 - s1));				
			}
			countAll += 4;*/
			countAll += 3;
		}
		if(countAll == 0){
			errorRate = 1;
		} else {
			errorRate = (float)count / (float)countAll;
    		//DecimalFormat myFormatter = new DecimalFormat("#.##");
    		//String errorRateStr = myFormatter.format(errorRate);
			//Log.d("Touch01", + count + " Errors in Total " + countAll + " (" + errorRateStr + "% errors)");
		}
    	return errorRate;
    }
    
    public TrajectoryPattern average(TrajectoryPattern tp) {
    	TrajectoryPattern tPattern = new TrajectoryPattern();
    	int i, j;
		int x1, x2, y1, y2;
		int t1, t2;
		int p1, p2;
		int s1, s2;
		boolean e1, e2;
		//int torg1, torg2;
		
		if (mGPList == null || tp == null) {
			return null;
		}
		
		int dist;
		int temp;
		int j_sel = 0;
		
		//torg1 = mGPList.get(0).getTime();
		//torg2 = tp.get(0).getTime();
		
		for (i = 0; i < mGPList.size(); ++i) {
			x1 = mGPList.get(i).getX();
			y1 = mGPList.get(i).getY();
			p1 = mGPList.get(i).getPressure();
			s1 = mGPList.get(i).getSize();
			t1 = mGPList.get(i).getTime();
			e1 = mGPList.get(i).isSelected();
			
			dist = 9999;
			for (j = j_sel = 0; j < tp.size(); ++j) {
    			x2 = tp.get(j).getX();
    			y2 = tp.get(j).getY();
    			temp = (int) Math.sqrt((double)((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)));
    			if (dist > temp) {
    				dist = temp;
    				j_sel = j;
        		}
    		}
			x2 = tp.get(j_sel).getX();
			y2 = tp.get(j_sel).getY();
			p2 = tp.get(j_sel).getPressure();
			s2 = tp.get(j_sel).getSize();
			t2 = tp.get(j_sel).getTime();
			e2 = tp.get(j_sel).isSelected();
			
			int count = 0;
			//if (Math.abs((t2 - torg2) - (t1 - torg1)) > this.thresTime) {
			if (Math.abs(t2 - t1) > this.thresTime) {
				count++;
				//Log.d("Touch01", "Time difference (ms) = " + Math.abs((t2 - torg2) - (t1 - torg1)));
			}
			if (Math.abs(Math.sqrt((double)((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)))) > this.thresDist) {
				count++;
				//Log.d("Touch01", "Point difference (dp) = " + Math.abs(Math.sqrt((double)((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)))));
			}
			if (Math.abs(p2 - p1) > this.thresPres) {
				count++;
				//Log.d("Touch01", "Pressure difference (0-100) = " + Math.abs(p2 - p1));
			}
			/*if (Math.abs(s2 - s1) > this.thresSize) {
				count++;
				//Log.d("Touch01", "Size difference (0-100) = " + Math.abs(s2 - s1));
			}*/
			//tPattern.addValues((t1-torg1+t2-torg2)/2, (x1+x2)/2, (y1+y2)/2, (p1+p2)/2, (s1+s2)/2);
			//if ((t1-torg1+t2-torg2)/2 < 0) {
			tPattern.addValues((t1+t2)/2, (x1+x2)/2, (y1+y2)/2, (p1+p2)/2, (s1+s2)/2);
			if ((t1+t2)/2 < 0) {
				t1 = 0;
			}
			if (count > 0 || e1 == false || e2 == false) {
				tPattern.markSelect(false, tPattern.size() - 1);
			} else {
				tPattern.markSelect(true, tPattern.size() - 1);
			}
		}
		return tPattern;
    }
    
    public float validity(){
    	float result;
    	int count = 0;
    	for (int i=0; i<mGPList.size(); ++i) {
    		if (mGPList.get(i).isSelected() == false) {
    			count++;
    		}
    	}
    	result = (float)(mGPList.size() - count) / (float)mGPList.size();
		//DecimalFormat myFormatter = new DecimalFormat("#.##");
		//String resultStr = myFormatter.format(result * 100);
    	//Log.d("Touch01", "Validity result: " + resultStr + "% valid (" + (mGPList.size() - count) + "/" + mGPList.size() + ")");
    	
    	return result;
    }
    
    
    public void markSelect(boolean select) {
    	this.selected = select;
    }
    
    public boolean isSelected() {
    	return this.selected;
    }
    
    public void markSelect(boolean select, int location) {
    	this.mGPList.get(location).markSelect(select);
    }
    
    public boolean isSelected(int location) {
    	return this.mGPList.get(location).isSelected();
    }
}
