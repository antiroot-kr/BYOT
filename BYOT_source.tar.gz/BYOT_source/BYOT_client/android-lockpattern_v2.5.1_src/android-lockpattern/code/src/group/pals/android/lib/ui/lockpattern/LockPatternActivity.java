/*
 *   Copyright 2012 Hai Bison
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package group.pals.android.lib.ui.lockpattern;

import group.pals.android.lib.ui.lockpattern.util.IEncrypter;
import group.pals.android.lib.ui.lockpattern.util.UI;
import group.pals.android.lib.ui.lockpattern.widget.LockPatternView;
import group.pals.android.lib.ui.lockpattern.widget.LockPatternView.Cell;
import group.pals.android.lib.ui.lockpattern.widget.LockPatternView.DisplayMode;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Point;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Main activity for this library.
 * <p>
 * You must use either {@link #_ActionCreatePattern} or
 * {@link #_ActionComparePattern}. Otherwise an
 * {@link UnsupportedOperationException} will be thrown.
 * </p>
 * <p>
 * You can deliver result to {@link PendingIntent}s and/ or
 * {@link ResultReceiver} too. See {@link #_OkPendingIntent},
 * {@link #_CancelledPendingIntent} and {@link #_ResultReceiver} for more
 * details.
 * </p>
 * <p>
 * <strong>NOTES</strong>
 * <li>You must use one of the themes that this library provides. They start
 * with {@code R.style.Alp_Theme_*}. The reason is the themes contain resources
 * that the library needs.</li>
 * <li>In mode comparing pattern, there are <strong><i>3 possible result
 * codes</i></strong>: {@link Activity#RESULT_OK},
 * {@link Activity#RESULT_CANCELED} and {@link #_ResultFailed}.</li>
 * </p>
 * 
 * @author Hai Bison
 * @since v1.0
 */
@SuppressLint("NewApi")
public class LockPatternActivity extends Activity {

    private static final String _ClassName = LockPatternActivity.class
            .getName();

    /**
     * Use this action to create new pattern. You can provide an
     * {@link IEncrypter} with {@link #_EncrypterClass} to improve security.
     * <p>
     * If the use created a pattern, {@link Activity#RESULT_OK} returns with the
     * pattern ({@link #_Pattern}). Otherwise {@link Activity#RESULT_CANCELED}
     * returns.
     * </p>
     * 
     * @since v2.4 beta
     * @see #_EncrypterClass
     * @see #_OkPendingIntent
     * @see #_CancelledPendingIntent
     */
    public static final String _ActionCreatePattern = _ClassName
            + ".create_pattern";
    
    /**
     * Use this action to compare pattern. You provide the pattern to be
     * compared with {@link #_Pattern}.
     * <p>
     * If the user passes, {@link Activity#RESULT_OK} returns. If not,
     * {@link #_ResultFailed} returns.
     * </p>
     * <p>
     * If the user cancels the task, {@link Activity#RESULT_CANCELED} returns.
     * </p>
     * <p>
     * In any case, there will be key {@link #_ExtraRetryCount} available in the
     * intent result.
     * </p>
     * 
     * @since v2.4 beta
     * @see #_Pattern
     * @see #_EncrypterClass
     * @see #_OkPendingIntent
     * @see #_CancelledPendingIntent
     * @see #_ResultFailed
     * @see #_ExtraRetryCount
     */
    public static final String _ActionComparePattern = _ClassName
            + ".compare_pattern";

    public static final String _ActionUnlockOtherPattern = _ClassName
            + ".unlock_other_pattern";
    
    public static final String _ActionReviewLinePattern = _ClassName
            + ".review_line_pattern";

    public static final String _ActionReviewGridPattern = _ClassName
            + ".review_grid_pattern";
    
    /**
     * If you use {@link #_ActionComparePattern} and the user fails to "login"
     * after a number of tries, this activity will finish with this result code.
     * 
     * @see #_ActionComparePattern
     * @see #_MaxRetry
     * @see #_ExtraRetryCount
     */
    public static final int _ResultFailed = RESULT_FIRST_USER + 1;

    /**
     * If you use {@link #_ActionComparePattern}, and the user fails to "login"
     * after a number of tries, this key holds that number.
     * 
     * @see #_ActionComparePattern
     * @see #_MaxRetry
     */
    public static final String _ExtraRetryCount = _ClassName + ".retry_count";

    /**
     * Sets value of this key to a theme in {@code R.style.Alp_Theme_*}. Default
     * is the one you set in AndroidManifest.xml.
     * 
     * @since v1.5.3 beta
     */
    public static final String _Theme = _ClassName + ".theme";

    /**
     * Specify if the pattern will be saved automatically or not.
     * <p>
     * Default: {@code false}
     * </p>
     */
    public static final String _AutoSave = _ClassName + ".auto_save";

    /**
     * Use this key to set the minimum wired-dots that are allowed.
     * <p>
     * Default: {@code 4} -- min: {@code 1} -- max: {@code 9}
     * </p>
     */
    public static final String _MinWiredDots = _ClassName + ".min_wired_dots";

    /**
     * Maximum retry times, used with {@link #_ActionComparePattern}.
     * <p>
     * Default: {@code 5}
     * </p>
     */
    public static final String _MaxRetry = _ClassName + ".max_retry";
    
    /**
     * Number of training times, used with {@link #_ActionCreatePattern}.
     * <p>
     * Default: {@code 5}
     * </p>
     */
    public static final String _NumTraining = _ClassName + ".num_training";

    /**
     * Key to hold pattern. Can be a SHA-1 string <i><b>or</b></i> an encrypted
     * string of its (if {@link #_EncrypterClass} is used).
     * 
     * @since v2 beta
     */
    public static final String _Pattern = _ClassName + ".pattern";
    public static final String _TruePattern = _ClassName + ".true_pattern";
    public static final String _ReplacedPatternIndex = _ClassName + ".replaced_pattern_index";
    public static final String _ThumbPressure = _ClassName + ".thumb_pressure";
    public static final String _ThumbSize = _ClassName + ".thumb_size";
    public static final String _TipPressure = _ClassName + ".tip_pressure";
    public static final String _TipSize = _ClassName + ".tip_size";
    
    /**
     * Key to hold touch signal. Can be a SHA-1 string <i><b>or</b></i> an encrypted
     * string of its (if {@link #_EncrypterClass} is used).
     * 
     * @since v2 beta
     */
    public static final String _RawTrajectory = _ClassName + ".raw_trajectory";

    /**
     * Key to hold touch signals. Can be a SHA-1 string <i><b>or</b></i> an encrypted
     * string of its (if {@link #_EncrypterClass} is used).
     * 
     * @since v2 beta
     */
    public static final String _RawTrajectories = _ClassName + ".raw_trajectories";

    /**
     * Key to hold grid signal. Can be a SHA-1 string <i><b>or</b></i> an encrypted
     * string of its (if {@link #_EncrypterClass} is used).
     * 
     * @since v2 beta
     */
    public static final String _QuantizedTrajectory = _ClassName + ".quantized_trajectory";

    /**
     * Key to hold grid signals. Can be a SHA-1 string <i><b>or</b></i> an encrypted
     * string of its (if {@link #_EncrypterClass} is used).
     * 
     * @since v2 beta
     */
    public static final String _QuantizedTrajectories = _ClassName + ".quantized_trajectories";

    /**
     * Key to hold background color. Can be a SHA-1 string <i><b>or</b></i> an encrypted
     * string of its (if {@link #_EncrypterClass} is used).
     * 
     * @since v2 beta
     */
    public static final String _BgColor = _ClassName + ".bg_color";

    /**
     * Key to hold implemented class of {@link IEncrypter}.<br>
     * If {@code null}, nothing will be used.
     * 
     * @since v2 beta
     */
    public static final String _EncrypterClass = IEncrypter.class.getName();

    /**
     * You can provide an {@link ResultReceiver} with this key. The activity
     * will notify your receiver the same result code and intent data as you
     * will receive them in {@link #onActivityResult(int, int, Intent)}.
     * 
     * @since v2.4 beta
     */
    public static final String _ResultReceiver = _ClassName
            + ".result_receiver";

    /**
     * Set to {@code true} if you want to use invisible pattern (there will be
     * no visible feedback as the user enters the pattern).
     * <p>
     * Default: {@code false}
     * </p>
     */
    public static final String _StealthMode = _ClassName + ".stealth_mode";

    /**
     * Put a {@link PendingIntent} into this key. It will be sent before
     * {@link Activity#RESULT_OK} will be returning. If you were calling this
     * activity with {@link #_ActionCreatePattern}, key {@link #_Pattern} will
     * be attached to the original intent which the pending intent holds.
     */
    public static final String _OkPendingIntent = _ClassName
            + ".ok_pending_intent";

    /**
     * Put a {@link PendingIntent} into this key. It will be sent before
     * {@link Activity#RESULT_CANCELED} will be returning.
     */
    public static final String _CancelledPendingIntent = _ClassName
            + ".cancelled_pending_intent";

	public static final int _GridsPerPoint = 16;
	
	public static final String _ID = _ClassName + ".id";
	public static final String _TotalScore = _ClassName + ".total_score";
	public static final String _AttackScore = _ClassName + ".attack_score";
	public static final String _DefenseScore = _ClassName + ".defense_score";
	public static final String _UsabilityScore = _ClassName + ".usability_score";
    
    
    /**
     * Helper enum for button OK commands. (Because we use only one "OK" button
     * for different commands).
     * 
     * @author Hai Bison
     * 
     */
    private static enum ButtonOkCommand {
        Continue, Done
    }// ButtonOkCommand

    /*
     * FIELDS
     */
    //private SharedPreferences mPrefs;
    private int mMaxRetry;
    private int mNumTraining;
    private int mCurTraining;
    private int mNumAccepting;
    //private boolean mAutoSave;
    //private IEncrypter mEncrypter;
    private int mMinWiredDots;
    private ButtonOkCommand mBtnOkCmd;
    private Intent mIntentResult;
    
    private int mThumbPres;
    private int mThumbSize;
    private int mTipPres;
    private int mTipSize;
    
    //private List<Cell> mPattern;
    private List<Cell> mTruePattern;
    //private TrajectoryPattern mTouchSignal;
    private List<TrajectoryPattern> mTouchSignals;
    private TrajectoryPattern mGridSignal;
    private List<TrajectoryPattern> mGridSignals;
    private static float[][] mDiffMatrix;
    
    private final float admitRate = (float) 0.05;

    private int bgColor;
    /*
     * CONTROLS
     */
    private TextView mTxtInfo;
    private TextView mTxtInfoID;
    private TextView mTxtInfoScore;
    private TextView mTxtInfoAScore;
    private TextView mTxtInfoDScore;
    private TextView mTxtInfoUScore;
    private LockPatternView mLockPatternView;
    
    private int mScreenWidth;
    private int mScreenHeight;
    //private View mFooter;
    //private Button mBtnCancel;
    //private Button mBtnConfirm;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (BuildConfig.DEBUG)
            Log.d(_ClassName, "ClassName = " + _ClassName);

        /*
         * THEME
         */
        
        mCurTraining = 0;

        if (getIntent().hasExtra(_Theme))
            setTheme(getIntent().getIntExtra(_Theme, R.style.Alp_Theme_Dark));

        super.onCreate(savedInstanceState);
        
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        //mPrefs = getSharedPreferences(LockPatternActivity.class.getName(), 0);

        if (!_ActionCreatePattern.equals(getIntent().getAction())
                && !_ActionComparePattern.equals(getIntent().getAction())
                && !_ActionUnlockOtherPattern.equals(getIntent().getAction())
                && !_ActionReviewLinePattern.equals(getIntent().getAction())
                && !_ActionReviewGridPattern.equals(getIntent().getAction()))
            throw new UnsupportedOperationException("Unknown Action >> "
                    + getIntent().getAction());
        
        mNumTraining = getIntent().getIntExtra(_NumTraining, 7);
        if (mNumTraining < 4)
        	mNumTraining = 4;
        else if (mNumTraining > 10)
        	mNumTraining = 10;
        
        mDiffMatrix = new float[mNumTraining][mNumTraining];
        for (int i=0; i<mNumTraining; ++i)
        	for (int j=0; j<mNumTraining; ++j)
        		mDiffMatrix[i][j] = 0;

        mNumAccepting = mNumTraining - 2;

        mMinWiredDots = getIntent().getIntExtra(_MinWiredDots, 4);
        if (mMinWiredDots <= 0 || mMinWiredDots > 9)
            mMinWiredDots = 4;

        mMaxRetry = getIntent().getIntExtra(_MaxRetry, 1000);
        if (mMaxRetry <= 0)
        	mMaxRetry = 1000;

        mThumbPres = getIntent().getIntExtra(_ThumbPressure, 90);
        mThumbSize = getIntent().getIntExtra(_ThumbSize, 90);
        mTipPres = getIntent().getIntExtra(_TipPressure, 10);
        mTipSize = getIntent().getIntExtra(_TipSize, 10);
        
        /*
         * Set this to false by default, for security enhancement.
         */
        //mAutoSave = getIntent().getBooleanExtra(_AutoSave, true);
        /*
         * If false, clear previous values (currently it is the pattern only).
         */
        //if (!mAutoSave)
        //    mPrefs.edit().clear().commit();

        /*
         * Encrypter.
         */
        /*Class<?> encrypterClass = (Class<?>) getIntent().getSerializableExtra(
                _EncrypterClass);
        if (encrypterClass != null) {
            try {
                mEncrypter = (IEncrypter) encrypterClass.newInstance();
            } catch (Throwable t) {
                throw new InvalidEncrypterException();
            }
        }*/

        mIntentResult = new Intent();
        setResult(RESULT_CANCELED, mIntentResult);
        
        //mPattern = null;
        mTruePattern = null;
        
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        mScreenWidth = size.x;
        mScreenHeight = size.y;

        initContentView();
    }// onCreate()

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d(_ClassName, "onConfigurationChanged()");
        super.onConfigurationChanged(newConfig);
        initContentView();
    }// onConfigurationChanged()

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && 
        		( _ActionComparePattern.equals(getIntent().getAction()) || 
        		  _ActionUnlockOtherPattern.equals(getIntent().getAction()) )
        		) {
            /*
             * Use this hook instead of onBackPressed(), because onBackPressed()
             * is not available in API 4.
             */
            finishWithNegativeResult(RESULT_CANCELED);
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }// onKeyDown()

    /**
     * Initializes UI...
     */
    private void initContentView() {
        /*
         * In case screen orientation changed, save all controls' state to
         * restore later.
         */
        CharSequence infoText = mTxtInfo != null ? mTxtInfo.getText() : null;
        //Boolean btnOkEnabled = mBtnConfirm != null ? mBtnConfirm.isEnabled()
        //        : null;
        LockPatternView.DisplayMode lastDisplayMode = mLockPatternView != null ? mLockPatternView
                .getDisplayMode() : null;
        List<Cell> lastPattern = mLockPatternView != null ? mLockPatternView
                .getPattern() : null;

        setContentView(R.layout.alp_lock_pattern_activity);
        
        bgColor = getIntent().getIntExtra(_BgColor, 0xff000000);
        LinearLayout layout = (LinearLayout) findViewById(R.id.layout);
        layout.setBackgroundColor(bgColor);
        UI.adjustDialogSizeForLargeScreen(getWindow());

        
        int temp;
        String str;
        
        mTxtInfo = (TextView) findViewById(R.id.alp_info);

        str = getIntent().getStringExtra(_ID);
    	mTxtInfoID = (TextView) findViewById(R.id.alp_info_id);
        if (str != null && str.isEmpty() == false) {
        	str += "'s\nunlock pattern";
        	mTxtInfoID.setText(str);
        } else {
        	mTxtInfoID.setText("unlock pattern");
        }
        
        temp = getIntent().getIntExtra(_TotalScore, 0);
        mTxtInfoScore = (TextView) findViewById(R.id.alp_info_total_score);
        if (temp == 0) {
            mTxtInfoScore.setText("-");
        } else {
            mTxtInfoScore.setText(Integer.toString(temp));
        }

        temp = getIntent().getIntExtra(_AttackScore, 0);
        mTxtInfoAScore = (TextView) findViewById(R.id.alp_info_attack_score);
        if (temp == 0) {
            mTxtInfoAScore.setText("-");
        } else {
        	mTxtInfoAScore.setText(Integer.toString(temp));
        }
        
        temp = getIntent().getIntExtra(_DefenseScore, 0);
        mTxtInfoDScore = (TextView) findViewById(R.id.alp_info_defense_score);
        if (temp == 0) {
            mTxtInfoDScore.setText("-");
        } else {
        	mTxtInfoDScore.setText(Integer.toString(temp));
        }
        
        temp = getIntent().getIntExtra(_UsabilityScore, 0);
        mTxtInfoUScore = (TextView) findViewById(R.id.alp_info_usability_score);
        if (temp == 0) {
            mTxtInfoUScore.setText("-");
        } else {
        	mTxtInfoUScore.setText(Integer.toString(temp));
        }
        
        mLockPatternView = (LockPatternView) findViewById(R.id.alp_lock_pattern);

        //mFooter = findViewById(R.id.alp_footer);
        //mBtnCancel = (Button) findViewById(R.id.alp_cancel);
        //mBtnConfirm = (Button) findViewById(R.id.alp_confirm);

        /*
         * LOCK PATTERN VIEW
         */

        if (getResources().getBoolean(R.bool.alp_is_large_screen)
                && !getWindow().isFloating()) {
            int size = getResources().getDimensionPixelSize(
                    R.dimen.alp_lockpatternview_size);
            LayoutParams lp = mLockPatternView.getLayoutParams();
            lp.width = size;
            lp.height = size;
            mLockPatternView.setLayoutParams(lp);
        }

        /*
         * Haptic feedback.
         */
        boolean hapticFeedbackEnabled = false;
        try {
            hapticFeedbackEnabled = Settings.System.getInt(
                    getContentResolver(),
                    Settings.System.HAPTIC_FEEDBACK_ENABLED, 0) != 0;
        } catch (Throwable t) {
            /*
             * Ignore it.
             */
        }
        mLockPatternView.setTactileFeedbackEnabled(hapticFeedbackEnabled);

        mLockPatternView.setInStealthMode(getIntent().getBooleanExtra(_StealthMode, false));
        mLockPatternView.setInReviewLineMode(_ActionReviewLinePattern.equals(getIntent().getAction()));
        mLockPatternView.setInReviewGridMode(_ActionReviewGridPattern.equals(getIntent().getAction()));
        mLockPatternView.setInCreateMode(_ActionCreatePattern.equals(getIntent().getAction()));
        mLockPatternView.setInCompareMode(_ActionComparePattern.equals(getIntent().getAction()) ||
        	_ActionUnlockOtherPattern.equals(getIntent().getAction()));
        mLockPatternView.setOnPatternListener(mPatternViewListener);
        
        mLockPatternView.setPressureAndSize(mThumbPres, mThumbSize, mTipPres, mTipSize);
        
        if (lastPattern != null && lastDisplayMode != null)
            mLockPatternView.setPattern(lastDisplayMode, lastPattern);
        
        if (_ActionReviewLinePattern.equals(getIntent().getAction())) {
        	str = getIntent().getStringExtra(_RawTrajectories);
            mTouchSignals = convertStringToTrajectoryPatterns(str);
        	mLockPatternView.setTouchSignals(mTouchSignals);
        	
        	str = getIntent().getStringExtra(_RawTrajectory);
        	/*if (mTouchSignal == null) {
        		mTouchSignal = new TrajectoryPattern();
        	}
            mTouchSignal.setPattern(str);
            mLockPatternView.setTouchSignal(mTouchSignal);*/
        } else if (_ActionReviewGridPattern.equals(getIntent().getAction())) {
        	str = getIntent().getStringExtra(_QuantizedTrajectory);
        	if (mGridSignal == null) {
        		mGridSignal = new TrajectoryPattern();
        	}
            mGridSignal.setPattern(str);
            mGridSignal.denormalize(mScreenWidth);
            mLockPatternView.setGridSignal(mGridSignal);

        	str = getIntent().getStringExtra(_QuantizedTrajectories);
            mGridSignals = convertStringToTrajectoryPatterns(str);
        	mLockPatternView.setGridSignals(mGridSignals);
        } else if (_ActionComparePattern.equals(getIntent().getAction())) {
        	str = getIntent().getStringExtra(_RawTrajectories);
            mTouchSignals = convertStringToTrajectoryPatterns(str);
        	mLockPatternView.setTouchSignals(mTouchSignals);

        	str = getIntent().getStringExtra(_TruePattern);
            mTruePattern = convertStringToPattern(str);
        	mLockPatternView.setTruePattern(mTruePattern);
        	
        	//str = getIntent().getStringExtra(_RawTrajectory);
        	/*if (mTouchSignal == null) {
        		mTouchSignal = new TrajectoryPattern();
        	}
            mTouchSignal.setPattern(str);
            mLockPatternView.setTouchSignal(mTouchSignal);*/
            
        	str = getIntent().getStringExtra(_QuantizedTrajectory);
        	if (mGridSignal == null) {
        		mGridSignal = new TrajectoryPattern();
        	}
            mGridSignal.setPattern(str);
            mGridSignal.denormalize(mScreenWidth);
            mLockPatternView.setGridSignal(mGridSignal);

        	str = getIntent().getStringExtra(_QuantizedTrajectories);
            mGridSignals = convertStringToTrajectoryPatterns(str);
        	mLockPatternView.setGridSignals(mGridSignals);
        } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())) {
        	str = getIntent().getStringExtra(_TruePattern);
            mTruePattern = convertStringToPattern(str);
        	mLockPatternView.setTruePattern(mTruePattern);
        	
        	str = getIntent().getStringExtra(_QuantizedTrajectory);
        	if (mGridSignal == null) {
        		mGridSignal = new TrajectoryPattern();
        	}
            mGridSignal.setPattern(str);
            mGridSignal.denormalize(mScreenWidth);
            mLockPatternView.setGridSignal(mGridSignal);
        }
        

        /*
         * COMMAND BUTTONS
         */

        if (_ActionCreatePattern.equals(getIntent().getAction())) {
            //mBtnCancel.setOnClickListener(mBtnCancelOnClickListener);
            //mBtnConfirm.setOnClickListener(mBtnConfirmOnClickListener);

            //mFooter.setVisibility(View.GONE);

            if (infoText != null)
                mTxtInfo.setText(infoText);
            else{
            	str = getString(R.string.alp_msg_draw_an_unlock_pattern) + " (" + mNumTraining + " times)";
                mTxtInfo.setText(str);
            }

            /*
             * BUTTON OK
             */
            /*if (mBtnOkCmd == null)
                mBtnOkCmd = ButtonOkCommand.Continue;
            switch (mBtnOkCmd) {
            case Continue:
                mBtnConfirm.setText(R.string.alp_cmd_continue);
                break;
            case Done:
                mBtnConfirm.setText(R.string.alp_cmd_confirm);
                break;
            }
            if (btnOkEnabled != null)
                mBtnConfirm.setEnabled(btnOkEnabled);*/
        }// _ActionCreatePattern
        else if (_ActionComparePattern.equals(getIntent().getAction())) {
            //mFooter.setVisibility(View.GONE);

            if (infoText != null)
                mTxtInfo.setText(infoText);
            else
                mTxtInfo.setText(R.string.alp_msg_draw_pattern_to_unlock);
        }// _ActionComparePattern
        else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())) {
            //mFooter.setVisibility(View.GONE);

            if (infoText != null)
                mTxtInfo.setText(infoText);
            else
                mTxtInfo.setText(R.string.alp_msg_draw_pattern_to_unlock);
        }// _ActionComparePattern
    }// initContentView()

    /**
     * Encodes {@code pattern} to a string.
     * <p>
     * <li>If {@link #_EncrypterClass} is not set, returns SHA-1 of
     * {@code pattern}.</li>
     * 
     * <li>If {@link #_EncrypterClass} is set, calculates SHA-1 of
     * {@code pattern}, then encrypts the SHA-1 value and returns the result.</li>
     * </p>
     * 
     * @param pattern
     *            the pattern.
     * @return SHA-1 of {@code pattern}, or encrypted string of its.
     * @since v2 beta
     */
    /*private String encodePattern(List<Cell> pattern) {
        if (mEncrypter == null) {
            return LockPatternUtils.patternToSha1(pattern);
        } else {
            try {
                return mEncrypter.encrypt(this,
                        LockPatternUtils.patternToSha1(pattern));
            } catch (Throwable t) {
                throw new InvalidEncrypterException();
            }
        }
    }// encodePattern()*/

    private int mRetryCount = 0;

    private void doCompareOtherPattern(List<Cell> pattern, TrajectoryPattern touchSignal) {
    	float errorRate;
        if (pattern == null)
            return;

        TrajectoryPattern gridSignal = new TrajectoryPattern();
        gridSignal.copyFrom(touchSignal);
    	gridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
    	errorRate = 0;
        if (convertPatternToString(pattern).equals(convertPatternToString(mTruePattern))
        	&& (errorRate = gridSignal.compare(mGridSignal)) < admitRate) {
        	// unlock succeeded
        	
        	Toast toast;
    		DecimalFormat myFormatter = new DecimalFormat("#.##");
    		String errorRateStr = myFormatter.format(errorRate * 100);
       		toast = Toast.makeText(this, errorRateStr + "% different (success)", Toast.LENGTH_SHORT);
        	toast.show();
  
            finishWithResultOk(//null,
            		-1,
            		null,
            		//mTouchSignal.toString(),
            		null,
            		null,
            		null);
        }
        else {
        	// unlock failed
        	//Toast toast;
        	if (errorRate == 0) {
        		mTxtInfo.setText("Wrong pattern, try again");
           		//toast = Toast.makeText(this, "Pattern mismatch", Toast.LENGTH_SHORT);
        		//toast.show();
        	} else if (errorRate >= admitRate) {
        		DecimalFormat myFormatter = new DecimalFormat("#.##");
        		String errorRateStr = myFormatter.format(errorRate * 100);
           		mTxtInfo.setText(errorRateStr + "% error, try again");
           		//toast = Toast.makeText(this, errorRateStr + "% different", Toast.LENGTH_SHORT);
        		//toast.show();
        	}
        	
            mRetryCount++;
            mIntentResult.putExtra(_ExtraRetryCount, mRetryCount);

            if (mRetryCount >= mMaxRetry)
                finishWithNegativeResult(_ResultFailed);
            else {
                mLockPatternView.setDisplayMode(DisplayMode.Wrong);
                //mTxtInfo.setText(R.string.alp_msg_try_again);
            }
        }
    }// doCompareOtherPattern()
        
    private void doComparePattern(List<Cell> pattern, TrajectoryPattern touchSignal) {
    	int res = 0;
    	float errorRate;
    	int replacedPatternIndex = -1;
    	Boolean noUpdate = false;
        if (pattern == null)
            return;

        //mPattern = new ArrayList<LockPatternView.Cell>();
        //mPattern.addAll(pattern);

        /*String currentPattern = getIntent().getStringExtra(_Pattern);
        if (currentPattern == null)
            currentPattern = mPrefs.getString(_Pattern, null);*/

        TrajectoryPattern gridSignal = new TrajectoryPattern();
        gridSignal.copyFrom(touchSignal);
    	gridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
    	errorRate = 0;
        //if (encodePattern(pattern).equals(currentPattern) && (errorRate = gridSignal.compare(mGridSignal)) < admitRate) {
        if (convertPatternToString(pattern).equals(convertPatternToString(mTruePattern))
        	&& (errorRate = gridSignal.compare(mGridSignal)) < admitRate) {
        	// unlock succeeded
        	
        	// 1) clear(true) all the prior selection marks
        	
        	// 2) find out one worst pattern to replace with the current input
        	replacedPatternIndex = worstTrajectoryPattern(mGridSignals);
        	Log.d("Touch01", "Worst index = " + replacedPatternIndex);
        	mGridSignals.set(replacedPatternIndex, gridSignal);
        	mTouchSignals.set(replacedPatternIndex, touchSignal);
        	
        	// 3.1) re-create the moving average among available input signals
        	res = compareTrajectoryPatterns(mGridSignals);
        	if (res != 0) {
        		Log.e("Touch01", "Error on compareTrajectoryPatterns()");
        		mTxtInfo.setText("Error on compare(), Touch back to restart!");
        		return;
        	}
        	
        	// 3.2) using the difference matrix, select top K similar grid signals
        	res = selectTrajectoryPatterns(mGridSignals);
        	if (res != 0) {
        		Log.e("Touch01", "Error on selectTrajectoryPatterns()");
        		mTxtInfo.setText("Error on select(), Touch back to restart!");
        		return;
        	}
        	
        	// 3.3) verify top K grid signals using the difference matrix 
        	//    succeeds if there is no mark among the top K grid signals
        	//    fails otherwise
        	res = countSelectedTrajectoryPatterns(mGridSignals);
        	if (res < mNumAccepting) {
        		Log.d("Touch01", "Less similar inputs: " + res);
        		//mTxtInfo.setText("Less similar inputs: " + res + ", Touch back to restart!");
        		
        		// In this case, 
        		// we don't update the lock pattern, 
        		// and successfully return to caller
        		noUpdate = true;
        	} else {
            	// TODO: or, should we accept the case of insufficient acceptable inputs? 
            	
            	// 3.4) perform moving average (50:50) by the chronological order 
            	//    mark error on each point when the difference of the two input signal points is significant 
            	//    (here we use a threshold value for each category of the input signal) 
            	//    mark error on each point when error(s) exists on the two input signal points
            
            	mGridSignal = getAverageTrajectoryPatterns(mGridSignals);
            	mGridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
            	mGridSignal.normalize(mScreenWidth);
            	
            	float validRate = mGridSignal.validity();
            	if (validRate < 0.67) {
            		DecimalFormat myFormatter = new DecimalFormat("#.##");
            		String ValidRateStr = myFormatter.format(validRate * 100);
            		Log.d("Touch01", "Less valid input portion: " + ValidRateStr + "% valid");
            		//mTxtInfo.setText("Less valid input portion: " + ValidRateStr + "%, Touch back to restart!");
            		
            		// In this case, 
            		// we don't update the lock pattern, 
            		// and successfully return to caller
            		noUpdate = true;
            	}
        	}
        	
        	Toast toast;
    		DecimalFormat myFormatter = new DecimalFormat("#.##");
    		String errorRateStr = myFormatter.format(errorRate * 100);
       		toast = Toast.makeText(this, errorRateStr + "% different (success)", Toast.LENGTH_SHORT);
        	toast.show();
  

        	//mTouchSignal = getAverageTrajectoryPatterns(mTouchSignals);
        	
            /*if (mAutoSave){
                //mPrefs.edit().putString(_RawTrajectory, mTouchSignal.toString()).commit();
                mPrefs.edit().putString(_RawTrajectories,
                		convertTrajectoryPatternsToString(mTouchSignals)).commit();
                mPrefs.edit().putString(_QuantizedTrajectory,
                		mGridSignal.toString()).commit();
                mPrefs.edit().putString(_QuantizedTrajectories,
                		convertTrajectoryPatternsToString(mGridSignals)).commit();
            }*/
        	if (noUpdate) {
                finishWithResultOk(//null,
                		-1,
                		null,
                		//mTouchSignal.toString(),
                		null,
                		null,
                		null);
        	} else {
                finishWithResultOk(//null,
                		replacedPatternIndex,
                		null,
                		//mTouchSignal.toString(),
                		convertTrajectoryPatternsToString(mTouchSignals),
                		mGridSignal.toString(),
                		convertTrajectoryPatternsToString(mGridSignals));
        	}
            //finishWithResultOk(null, null, null, null);
        }
        else {
        	// unlock failed
        	//Toast toast;
        	if (errorRate == 0) {
        		mTxtInfo.setText("Wrong pattern, try again");
           		//toast = Toast.makeText(this, "Pattern mismatch", Toast.LENGTH_SHORT);
        		//toast.show();
        	} else if (errorRate >= admitRate) {
        		DecimalFormat myFormatter = new DecimalFormat("#.##");
        		String errorRateStr = myFormatter.format(errorRate * 100);
           		mTxtInfo.setText(errorRateStr + "% error, try again");
           		//toast = Toast.makeText(this, errorRateStr + "% different", Toast.LENGTH_SHORT);
        		//toast.show();
        	}
        	
            mRetryCount++;
            mIntentResult.putExtra(_ExtraRetryCount, mRetryCount);

            if (mRetryCount >= mMaxRetry)
                finishWithNegativeResult(_ResultFailed);
            else {
                mLockPatternView.setDisplayMode(DisplayMode.Wrong);
                //mTxtInfo.setText(R.string.alp_msg_try_again);
            }
        }
    }// doComparePattern()
    

    private List<TrajectoryPattern> convertStringToTrajectoryPatterns(String tsString) {
    	if (tsString == null) {
    		return null;
    	}
    	List<TrajectoryPattern> touchSignals = new ArrayList<TrajectoryPattern>();
    	StringTokenizer tsToken = new StringTokenizer(tsString, " ");
    	TrajectoryPattern touchSignal;
    	while (tsToken.hasMoreElements()) {
    		touchSignal = new TrajectoryPattern();
    		touchSignal.setPattern((String) tsToken.nextElement());
    		touchSignals.add(touchSignal);
    	}
    	return touchSignals;
    }
    
    private String convertTrajectoryPatternsToString(List<TrajectoryPattern> touchSignals) {
    	String str;
    	Iterator<TrajectoryPattern> it = touchSignals.iterator();
    	
    	str = "";
    	
    	while(it.hasNext()){
    		TrajectoryPattern touchSignal = it.next();
    		str += touchSignal.toString();
    		str += " "; // divider for the multiple List<TouchSignal> objects
	    }
    	return str;
    }

    private String convertPatternToString(List<Cell> pattern) {
    	String str;
    	Iterator<Cell> it = pattern.iterator();
    	
    	str = "";
    	
    	while(it.hasNext()){
    		Cell cell = it.next();
    		str += cell.toStringSimple();
    		//str += " "; // divider for the each Cell object
	    }
    	return str;
    }
    
    private List<Cell> convertStringToPattern(String pString) {
    	if (pString == null) {
    		return null;
    	}
    	List<Cell> pattern = new ArrayList<Cell>();
    	StringTokenizer pToken = new StringTokenizer(pString, ",");
    	Cell cell;
    	while (pToken.hasMoreElements()) {
    		cell = new Cell();
    		String str1 = (String) pToken.nextElement();
    		String str2 = (String) pToken.nextElement();
    		if (str1 != null && str2 != null) {
    			str1 = str1 + "," + str2;
    		}
    		cell.setFromStringSimple(str1);
    		//Log.d("Touch01", str1);
    		pattern.add(cell);
    	}
    	return pattern;
    }
    

    
    private void doCreatePattern(List<Cell> pattern, TrajectoryPattern touchSignal) {
    	int res = 0;
    	TrajectoryPattern gridSignal;
        if (pattern.size() < mMinWiredDots) {
            mLockPatternView.setDisplayMode(DisplayMode.Wrong);
            mTxtInfo.setText(getString(R.string.alp_pmsg_connect_x_dots,
                    mMinWiredDots));
            return;
        }

        // Here, we perform K times of training for the creation. 
        // We also need to construct an average-based merge operation for the K input patterns 
        if (mTruePattern == null) {
        	mTruePattern = new ArrayList<LockPatternView.Cell>();
        	mTruePattern.addAll(pattern);
        	
        	mTouchSignals = new ArrayList<TrajectoryPattern>();
        	TrajectoryPattern currentTouchSignal = new TrajectoryPattern();
        	currentTouchSignal.copyFrom(touchSignal);
        	mTouchSignals.add(currentTouchSignal);

        	mGridSignals = new ArrayList<TrajectoryPattern>();
        	gridSignal = new TrajectoryPattern();
        	gridSignal.copyFrom(currentTouchSignal);
        	gridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
        	mGridSignals.add(gridSignal);
        	
            mCurTraining++;
            String str = getString(R.string.alp_msg_pattern_recorded) + " (" + (mNumTraining - mCurTraining) + " times left)";
            mTxtInfo.setText(str);
        } else {
            if (convertPatternToString(mTruePattern).equals(convertPatternToString(pattern))) {
            	TrajectoryPattern currentTouchSignal = new TrajectoryPattern();
            	currentTouchSignal.copyFrom(touchSignal);
            	mTouchSignals.add(currentTouchSignal);
            	// transform the captured raw signals to grid signals
            	gridSignal = new TrajectoryPattern();
               	gridSignal.copyFrom(currentTouchSignal);
               	gridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
            	mGridSignals.add(gridSignal);
            	
                mCurTraining++;
                if(mNumTraining == mCurTraining){
                	// Here we try to create the aggregated pattern using the following steps
                	// 0) transform the captured raw signals to grid signals (done) 
                	// 1) perform comparison among the created raw patterns and mark difference matrix
                	// 2) using the difference matrix, select top K similar grid signals 
                	// 3) verify top K grid signals using the difference matrix 
                	//    succeeds if there is no mark among the top K grid signals
                	//    fails otherwise
                	// 4) perform moving average (50:50) by the chronological order 
                	//    mark error on each point when the difference of the two input signal points is significant 
                	//    (here we use a threshold value for each category of the input signal) 
                	//    mark error on each point when error(s) exists on the two input signal points
                	// 5) save the last M grid signals and an aggregate signal pattern for future use.   
                
                	// 1) perform comparison among the created raw patterns and mark difference matrix
                	res = compareTrajectoryPatterns(mGridSignals);
                	if (res != 0) {
                		Log.e("Touch01", "Error on compareTrajectoryPatterns()");
                		mTxtInfo.setText("Error on compare() - Please retry with easier pattern!");
                		
                		// In this case, 
                		// we re-start from the beginning,
                		// so re-initiate all the important (changed) variables
                		mTruePattern = null;
                		mGridSignals = null;
                		mTouchSignals = null;
                		mCurTraining = 0;
                		return;
                	}
                	
                	// 2) using the difference matrix, select top K similar grid signals
                	res = selectTrajectoryPatterns(mGridSignals);
                	if (res != 0) {
                		Log.e("Touch01", "Error on selectTrajectoryPatterns()");
                		mTxtInfo.setText("Error on select() - Please retry with easier pattern!");
                		
                		// In this case, 
                		// we re-start from the beginning,
                		// so re-initiate all the important (changed) variables
                		mTruePattern = null;
                		mGridSignals = null;
                		mTouchSignals = null;
                		mCurTraining = 0;
                		return;
                	}
                	
                	// 3) verify top K grid signals using the difference matrix 
                	//    succeeds if there is no mark among the top K grid signals
                	//    fails otherwise
                	res = countSelectedTrajectoryPatterns(mGridSignals);
                	if (res < mNumAccepting) {
                		Log.e("Touch01", "Insufficient acceptable inputs: " + res);
                		mTxtInfo.setText("Inputs are so different - Please retry with easier pattern!");
                		
                		// In this case, 
                		// we re-start from the beginning,
                		// so re-initiate all the important (changed) variables
                		mTruePattern = null;
                		mGridSignals = null;
                		mTouchSignals = null;
                		mCurTraining = 0;
                		return;
                	}
                	// TODO: or, should we accept the case of insufficient acceptable inputs? 
                	
                	// 4) perform moving average (50:50) by the chronological order 
                	//    mark error on each point when the difference of the two input signal points is significant 
                	//    (here we use a threshold value for each category of the input signal) 
                	//    mark error on each point when error(s) exists on the two input signal points
                
                	mGridSignal = getAverageTrajectoryPatterns(mGridSignals);
                	mGridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
                	mGridSignal.normalize(mScreenWidth);

                	float validRate = mGridSignal.validity();
                	if (validRate < 0.8) {
                		DecimalFormat myFormatter = new DecimalFormat("#.##");
                		String ValidRateStr = myFormatter.format(validRate * 100);
                		Log.e("Touch01", "Less valid input portion: " + ValidRateStr + "%");
                		mTxtInfo.setText("Inputs are so different - Please retry with easier pattern!");
                		
                		// In this case, 
                		// we re-start from the beginning,
                		// so re-initiate all the important (changed) variables
                		mTruePattern = null;
                		mGridSignals = null;
                		mTouchSignals = null;
                		mCurTraining = 0;
                		return;
                	}
                	
                	//mTouchSignal = getAverageTrajectoryPatterns(mTouchSignals);

                	/*if (mGridSignal == null) {
                		mGridSignal = new TrajectoryPattern();
                	}
                	mGridSignal.copyFrom(mTouchSignal);
                	mGridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight()); 
                	
                	mGridSignals = new ArrayList<TrajectoryPattern>();
                	for (int i=0; i<mTouchSignals.size(); ++i) {
                    	gridSignal = new TrajectoryPattern();
                    	gridSignal.copyFrom(mTouchSignals.get(i));
                    	gridSignal.quantize((int) mLockPatternView.getGridWidth(), (int) mLockPatternView.getGridHeight());
                    	mGridSignals.add(gridSignal);
                	}*/
                	
                    /*if (mAutoSave){
                        //mPrefs.edit().putString(_Pattern,
                        //		encodePattern(mPattern)).commit();
                        mPrefs.edit().putString(_TruePattern,
                        		convertPatternToString(mTruePattern)).commit();
                        //mPrefs.edit().putString(_RawTrajectory, mTouchSignal.toString()).commit();
                        mPrefs.edit().putString(_RawTrajectories,
                        		convertTrajectoryPatternsToString(mTouchSignals)).commit();
                        mPrefs.edit().putString(_QuantizedTrajectory,
                        		mGridSignal.toString()).commit();
                        mPrefs.edit().putString(_QuantizedTrajectories,
                        		convertTrajectoryPatternsToString(mGridSignals)).commit();
                    }*/
                    //Log.d("Touch01", "Pattern: " + encodePattern(mPattern));
                    //Log.d("Touch01", "TouchSignal: " + convertTouchSignalToString(mTouchSignal));
                    //Log.d("Touch01", "TouchSignals: " + convertTouchSignalsToString(mTouchSignals));
                    finishWithResultOk(//encodePattern(mPattern),
                    		-1,
                    		convertPatternToString(mTruePattern),
                    		//mTouchSignal.toString(),
                    		convertTrajectoryPatternsToString(mTouchSignals),
                    		mGridSignal.toString(),
                    		convertTrajectoryPatternsToString(mGridSignals));
                } else {
                    String str = getString(R.string.alp_msg_pattern_recorded) + " (" + (mNumTraining - mCurTraining) + " times left)";
                    mTxtInfo.setText(str);
                }
                //mTxtInfo.setText(R.string.alp_msg_your_new_unlock_pattern);
                //mBtnConfirm.setEnabled(true);
            } else {
                String str = getString(R.string.alp_msg_redraw_pattern_to_confirm) + " (" + (mNumTraining - mCurTraining) + " times left)";
                mTxtInfo.setText(str);
                //mTxtInfo.setText(R.string.alp_msg_redraw_pattern_to_confirm);
                //mBtnConfirm.setEnabled(false);
                mLockPatternView.setDisplayMode(DisplayMode.Wrong);
            }
        }
        //mBtnConfirm.setEnabled(true);
    }// doCreatePattern()
    
    private int compareTrajectoryPatterns(List<TrajectoryPattern> tpList) {
    	int i, j;
    	int size = tpList.size();
    	float errorRate = 0;
    	if (size != mNumTraining) {
    		Log.d("Touch01", "size = " + size);
    		return 1;
    	}
    	
    	// first of all, we fill the matrix with zeros 
    	for (i=0; i<mNumTraining; ++i)
    		for (j=0; j<mNumTraining; ++j)
    			mDiffMatrix[i][j] = 0;
    	
    	// second, let's compare one by one 
    	for (i=0; i<size-1; ++i) {
    		for (j=i+1; j<size; ++j) {
    			errorRate = tpList.get(i).compare(tpList.get(j));
    			mDiffMatrix[j][i] = mDiffMatrix[i][j] = errorRate;
        		//Log.d("Touch01", "mDiffMatrix[" + i + "][" + j + "] = " + errorRate);
    		}
    	}
    	return 0;
    }
    
    private int selectTrajectoryPatterns(List<TrajectoryPattern> tpList) {
    	int i, j;
    	int size = tpList.size();
    	int filtered = 0;
    	float errorRate = 0;
    	float maxError = 0;
    	int selected = 0;
    	if (size != mNumTraining) {
    		return 1;
    	}
    	if (mNumTraining < mNumAccepting) {
    		return 1;
    	}
    	filtered = 0;
    	
    	for (i=0; i<size; ++i) {
    		tpList.get(i).markSelect(true);
    	}
    	
    	while (true) {
    		selected = -1;
        	for (i=0, maxError=0; i<size; ++i) {
    			if (tpList.get(i).isSelected() == false)
    				continue;
        		for (j=0, errorRate=0; j<size; ++j) {
        			if (tpList.get(j).isSelected() == true)
        				errorRate += mDiffMatrix[i][j];
        		}
        		if (maxError < errorRate) {
        			maxError = errorRate;
        			selected = i;
        		}
        	}
        	if (selected == -1) {
        		break;
        	}
        	
        	if (maxError < admitRate/2 * mNumAccepting) {
        		Log.d("Touch01", "Not too different ones, so keep " + (mNumTraining - filtered) + " input patterns");
        		break;
        	}

    		tpList.get(selected).markSelect(false);
    		DecimalFormat myFormatter = new DecimalFormat("#.##");
    		String errorRateStr = myFormatter.format(maxError * 100);
    		Log.d("Touch01", "Exclude " + selected + "-th input: " + errorRateStr + "% cumulative errors");
    		filtered++;
    	}
    	return 0;
    }

    private int worstTrajectoryPattern(List<TrajectoryPattern> tpList) {
    	int i, j;
    	int size = tpList.size();
    	float errorRate = 0;
    	float maxError = 0;
    	int selected = 0;
    	
    	// first of all, clear(true) selection marks
    	for (i=0; i<size; ++i) {
    		tpList.get(i).markSelect(true);
    		for(j=0; j<tpList.get(i).size(); ++j) {
    			tpList.get(i).markSelect(true, j);
    		}
    	}
    	
		selected = -1;
    	for (i=0, maxError=0; i<size; ++i) {
    		for (j=0, errorRate=0; j<size; ++j) {
    			errorRate += mDiffMatrix[i][j];
    		}
    		if (maxError < errorRate) {
    			maxError = errorRate;
    			selected = i;
    		}
    	}
    	if (selected == -1) {
    		return 0;
    	}
    	return selected;
    }
    
    private int countSelectedTrajectoryPatterns(List<TrajectoryPattern> tpList) {
    	int i;
    	int size = tpList.size();
    	int count;    	
    	for (i=count=0; i<size; ++i) {
    		if (tpList.get(i).isSelected() == true)
    			count++;
    	}
    	return count;
    }
    
    private TrajectoryPattern getAverageTrajectoryPatterns(List<TrajectoryPattern> tpList) {
    	int i, init;
    	int size = tpList.size();
    	TrajectoryPattern tpTmp1 = null;
    	if (size <= 0) {
    		return null;
    	}
    	for (i=init=0; i<size; ++i) {
    		if (tpList.get(i).isSelected() == true) {
    	    	tpTmp1 = tpList.get(i);
    	    	init = i;
    	    	break;
    		}
    	}
    	
    	for (i=init + 1; i<size; ++i) {
        	TrajectoryPattern tpTmp2 = tpList.get(i);
        	if (tpTmp2.isSelected() == false) {
        		continue;
        	}
    		if (tpTmp1.size() < tpTmp2.size()) {
    			tpTmp1 = tpTmp2.average(tpTmp1);
    		} else {
    			tpTmp1 = tpTmp1.average(tpTmp2);
    		}
    		//Log.d("Touch01", "Validity[" + i + "-th]: " + tpTmp1.validity());
    	}
    	return tpTmp1;
    }
    
    /**
     * Finishes activity with {@link Activity#RESULT_OK}.
     * 
     * @param pattern
     *            the pattern, if this is in mode creating pattern. Can be
     *            {@code null}.
     */
    private void finishWithResultOk(//String pattern,
    		int replacedPatternIndex,
    		String truePattern, String touchSignals,
    		String gridSignal, String gridSignals) {
        if (_ActionCreatePattern.equals(getIntent().getAction())){
            //mIntentResult.putExtra(_Pattern, pattern);
            mIntentResult.putExtra(_TruePattern, truePattern);
            //mIntentResult.putExtra(_RawTrajectory, touchSignal);
            mIntentResult.putExtra(_RawTrajectories, touchSignals);
            mIntentResult.putExtra(_QuantizedTrajectory, gridSignal);
            mIntentResult.putExtra(_QuantizedTrajectories, gridSignals);
        } else if (_ActionComparePattern.equals(getIntent().getAction())){
            //mIntentResult.putExtra(_RawTrajectory, touchSignal);
            mIntentResult.putExtra(_RawTrajectories, touchSignals);
            mIntentResult.putExtra(_QuantizedTrajectory, gridSignal);
            mIntentResult.putExtra(_QuantizedTrajectories, gridSignals);
            mIntentResult.putExtra(_ExtraRetryCount, mRetryCount);
            mIntentResult.putExtra(_ReplacedPatternIndex, replacedPatternIndex);
        } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())){
            mIntentResult.putExtra(_ExtraRetryCount, mRetryCount);
            
            // TODO: IS IT A GOOD IDEA TO JUST USE THE mRetryCount????
            // TODO: WHAT HAPPEN WHEN USER JUST TOUCH BACK BUTTON???
        }
        setResult(RESULT_OK, mIntentResult);

        /*
         * ResultReceiver
         */
        ResultReceiver receiver = getIntent().getParcelableExtra(_ResultReceiver);
        if (receiver != null) {
            Bundle bundle = new Bundle();
            if (_ActionCreatePattern.equals(getIntent().getAction())){
                //bundle.putString(_Pattern, pattern);
                bundle.putString(_TruePattern, truePattern);
                //bundle.putString(_RawTrajectory, touchSignal);
                bundle.putString(_RawTrajectories, touchSignals);
                bundle.putString(_QuantizedTrajectory, gridSignal);
                bundle.putString(_QuantizedTrajectories, gridSignals);
            } else if (_ActionComparePattern.equals(getIntent().getAction())){
                //bundle.putString(_RawTrajectory, touchSignal);
                bundle.putString(_RawTrajectories, touchSignals);
                bundle.putString(_QuantizedTrajectory, gridSignal);
                bundle.putString(_QuantizedTrajectories, gridSignals);
                bundle.putInt(_ExtraRetryCount, mRetryCount + 1);
            } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())){
                bundle.putInt(_ExtraRetryCount, mRetryCount + 1);
                
                // TODO: IS IT A GOOD IDEA TO JUST USE THE mRetryCount????
                // TODO: WHAT HAPPEN WHEN USER JUST TOUCH BACK BUTTON???
            }
            receiver.send(RESULT_OK, bundle);
        }

        /*
         * PendingIntent
         */
        PendingIntent pi = getIntent().getParcelableExtra(_OkPendingIntent);
        if (pi != null) {
            try {
                pi.send(this, RESULT_OK, mIntentResult);
            } catch (Throwable t) {
                if (BuildConfig.DEBUG) {
                    Log.e(_ClassName, "Error sending PendingIntent: " + pi);
                    Log.e(_ClassName, ">>> " + t);
                    t.printStackTrace();
                }
            }
        }

        finish();
    }// finishWithResultOk()

    /**
     * Finishes the activity with negative result (
     * {@link Activity#RESULT_CANCELED} or {@link #_ResultFailed}).
     */
    private void finishWithNegativeResult(int resultCode) {
        if (_ActionComparePattern.equals(getIntent().getAction())) {
            mIntentResult.putExtra(_ExtraRetryCount, mRetryCount);
        } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())) {
            mIntentResult.putExtra(_ExtraRetryCount, mRetryCount);
        }

        setResult(resultCode, mIntentResult);

        /*
         * ResultReceiver
         */
        ResultReceiver receiver = getIntent().getParcelableExtra(
                _ResultReceiver);
        if (receiver != null) {
            Bundle resultBundle = null;
            if (_ActionComparePattern.equals(getIntent().getAction())) {
                resultBundle = new Bundle();
                resultBundle.putInt(_ExtraRetryCount, mRetryCount);
            } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())) {
                resultBundle = new Bundle();
                resultBundle.putInt(_ExtraRetryCount, mRetryCount);
            }
            receiver.send(resultCode, resultBundle);
        }

        /*
         * PendingIntent
         */
        PendingIntent pi = getIntent().getParcelableExtra(
                _CancelledPendingIntent);
        if (pi != null) {
            try {
                pi.send(this, resultCode, mIntentResult);
            } catch (Throwable t) {
                if (BuildConfig.DEBUG) {
                    Log.e(_ClassName, "Error sending PendingIntent: " + pi);
                    Log.e(_ClassName, ">>> " + t);
                    t.printStackTrace();
                }
            }
        }

        finish();
    }// finishWithNegativeResult()

    /*
     * LISTENERS
     */

    private final LockPatternView.OnPatternListener mPatternViewListener = new LockPatternView.OnPatternListener() {

        @Override
        public void onPatternStart() {
            mLockPatternView.setDisplayMode(DisplayMode.Correct);

            if (_ActionCreatePattern.equals(getIntent().getAction())) {
                mTxtInfo.setText(R.string.alp_msg_release_finger_when_done);
                //mBtnConfirm.setEnabled(false);
                if (mBtnOkCmd == ButtonOkCommand.Continue)
                    mTruePattern = null;
            }
        }// onPatternStart()

        @Override
        public void onPatternDetected(List<Cell> pattern, TrajectoryPattern touchSignal) {
            if (_ActionCreatePattern.equals(getIntent().getAction())) {
                doCreatePattern(pattern, touchSignal);
            } else if (_ActionComparePattern.equals(getIntent().getAction())) {
                doComparePattern(pattern, touchSignal);
            } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())) {
                doCompareOtherPattern(pattern, touchSignal);
            }
        }// onPatternDetected()

        @Override
        public void onPatternCleared() {
            mLockPatternView.setDisplayMode(DisplayMode.Correct);

            if (_ActionCreatePattern.equals(getIntent().getAction())) {
                //mBtnConfirm.setEnabled(false);
                if (mBtnOkCmd == ButtonOkCommand.Continue) {
                    mTruePattern = null;
                    String str = getString(R.string.alp_msg_draw_an_unlock_pattern) + " (" + mNumTraining + " times)";
                    mTxtInfo.setText(str);
                } else
                    mTxtInfo.setText(R.string.alp_msg_redraw_pattern_to_confirm);
            } else if (_ActionComparePattern.equals(getIntent().getAction())) {
                mTxtInfo.setText(R.string.alp_msg_draw_pattern_to_unlock);
            } else if (_ActionUnlockOtherPattern.equals(getIntent().getAction())) {
                mTxtInfo.setText(R.string.alp_msg_draw_pattern_to_unlock);
            }
        }// onPatternCleared()

        @Override
        public void onPatternCellAdded(List<Cell> pattern) {
            // TODO Auto-generated method stub
        }// onPatternCellAdded()
    };// mPatternViewListener
}
