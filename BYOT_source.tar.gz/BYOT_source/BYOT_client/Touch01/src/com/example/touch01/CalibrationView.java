/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.touch01;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class CalibrationView extends View {

	private Paint mPaint = new Paint();
    private Paint mPathPaint = new Paint();

    private float mDiameterFactor = 0.10f;
    private final int mStrokeAlpha = 160;

    private float mScreenWidth;
    private float mScreenHeight;

    private Bitmap mBitmapBackground;
    private Bitmap mBitmapResized = null;

    private int mBitmapWidth;
    private int mBitmapHeight;

    private final Context mContext;
    
    private int mBitmapID;
    
    private int inTouchProgress;
    
    private boolean inLittleTipMode = false;
    
    private int inIdleAnimate = 0;

    public CalibrationView(Context context) {
        this(context, null);
    }

    public CalibrationView(Context context, AttributeSet attrs) {
        super(context, attrs);

        mContext = context;

        setClickable(true);

        mPathPaint.setAntiAlias(true);
        mPathPaint.setDither(true);
        mPathPaint.setColor(Color.WHITE);
        mPathPaint.setAlpha(mStrokeAlpha);
        mPathPaint.setStyle(Paint.Style.STROKE);
        mPathPaint.setStrokeJoin(Paint.Join.ROUND);
        mPathPaint.setStrokeCap(Paint.Cap.ROUND);

        mBitmapBackground = getBitmapFor(R.drawable.thumb_base_768_868);
        mBitmapWidth = mBitmapBackground.getWidth();
        mBitmapHeight = mBitmapBackground.getHeight();
    }// LockPatternView()

    public Boolean setBitmapID(int resID) {
    	mBitmapID = resID;
    	Bitmap bitmap = getBitmapFor(mBitmapID);
    	if (bitmap != null) {
    		mBitmapBackground = bitmap;
            mBitmapWidth = mBitmapBackground.getWidth();
            mBitmapHeight = mBitmapBackground.getHeight();
            //Log.d("Touch01", "Bitmap w=" + mBitmapWidth + " h=" + mBitmapHeight);
    		return true;
    	} else {
    		return false;
    	}
    }
    
    public void setLittleTipMode(boolean mode) {
    	this.inLittleTipMode = mode;
    }
    
    public int getBitmapWidth() {
    	return mBitmapWidth;
    }
    
    public int getBitmapHeight() {
    	return mBitmapHeight;
    }
    
    public void setInTouchProgress(int inTouchProgress) {
    	this.inTouchProgress = inTouchProgress;
    }
    
    public void setInIdleAnimate(int inIdleAnimate) {
    	this.inIdleAnimate = inIdleAnimate;
    }
    
    private Bitmap getBitmapFor(int resId) {
        return BitmapFactory.decodeResource(getContext().getResources(), resId);
    }
    
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        final int minimumWidth = getSuggestedMinimumWidth();
        final int minimumHeight = getSuggestedMinimumHeight();
        int viewWidth = resolveMeasured(widthMeasureSpec, minimumWidth);
        int viewHeight = resolveMeasured(heightMeasureSpec, minimumHeight);
        setMeasuredDimension(viewWidth, viewHeight);
        //Log.d("Touch01", "mw=" + minimumWidth + " mh=" + minimumHeight + " vw=" + viewWidth + " vh=" + viewHeight);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    	mScreenWidth = w;
    	mScreenHeight = h;
        //Log.d("Touch01", "Screen Width=" + w + " Height=" + h);
    }

    private int resolveMeasured(int measureSpec, int desired) {
        int result = 0;
        int specSize = MeasureSpec.getSize(measureSpec);
        switch (MeasureSpec.getMode(measureSpec)) {
        case MeasureSpec.UNSPECIFIED:
            result = desired;
            break;
        case MeasureSpec.AT_MOST:
            result = Math.max(specSize, desired);
            break;
        case MeasureSpec.EXACTLY:
        default:
            result = specSize;
        }
        return result;
    }

    @Override
    protected int getSuggestedMinimumWidth() {
        // View should be large enough to contain 3 side-by-side target bitmaps
        return 3 * mBitmapWidth;
    }

    @Override
    protected int getSuggestedMinimumHeight() {
        // View should be large enough to contain 3 side-by-side target bitmaps
        return 3 * mBitmapWidth;
    }

    @SuppressLint("DrawAllocation")
	@Override
    protected void onDraw(Canvas canvas) {
        float radius = (mScreenWidth * mDiameterFactor);
        int w = canvas.getWidth()-8;
        int h = canvas.getHeight()-8;
        //Log.d("Touch01", "Canvas w=" + w + " h=" + h);
        Rect rd = new Rect(0, 0, w, h);
        Rect rs = new Rect(0, 0, mBitmapWidth, mBitmapHeight);
        
        if (inLittleTipMode) { 
        	if (inTouchProgress == -1) {
            	switch (inIdleAnimate) {
            	case 0:
            		setBitmapID(R.drawable.little_tip_768_868_5);
            		break;
            	case 1:
            		setBitmapID(R.drawable.little_tip_768_868_1);
            		break;
            	case 2:
            		setBitmapID(R.drawable.little_tip_768_868_2);
            		break;
            	case 3:
            		setBitmapID(R.drawable.little_tip_768_868_3);
            		break;
            	case 4:
            		setBitmapID(R.drawable.little_tip_768_868_4);
            		break;
            	case 5:
            	default:
            		setBitmapID(R.drawable.little_tip_768_868_5);
            		break;
            	}
        	} else {
        		setBitmapID(R.drawable.little_tip_768_868_5);
        	}
        }
        
        mPaint.setColor(Color.BLACK);
        canvas.drawRect(rd, mPaint);
        canvas.drawBitmap(mBitmapBackground, rs, rd, null);
        
        boolean oldFlag = (mPaint.getFlags() & Paint.FILTER_BITMAP_FLAG) != 0;
        mPaint.setFilterBitmap(true); // draw with higher quality since we
                                      // render with transforms
		int color = Color.rgb(0, 0, 255);
        //mPathPaint.setStrokeWidth(radius * 0.25f);
        mPathPaint.setColor(color);
        mPathPaint.setTextSize(radius);
        mPathPaint.setAlpha(mStrokeAlpha);
        mPathPaint.setTextAlign(Align.CENTER);

        mPaint.setStyle(Style.FILL);
        mPaint.setColor(color);
        mPaint.setAlpha(mStrokeAlpha);

        // TODO: Draw progress bar here
        switch (inTouchProgress) {
        case 13:
        	// OK
        	canvas.drawText("got it!", w/2, h/3, mPathPaint);
        case 12:
        	// Left-top
        	canvas.drawRect(0, radius, radius, h/3, mPaint);
        case 11:
        	// Left-middle
        	canvas.drawRect(0, h/3, radius, 2*h/3, mPaint);
        case 10:
        	// Left-bottom
        	canvas.drawRect(0, 2*h/3, radius, h-radius, mPaint);
        case 9:
        	// Bottom-left
        	canvas.drawRect(0, h-radius, w/3, h, mPaint);
        case 8:
        	// Bottom-middle
        	canvas.drawRect(w/3, h-radius, 2*w/3, h, mPaint);
        case 7:
        	// Bottom-right
        	canvas.drawRect(2*w/3, h-radius, w-radius, h, mPaint);
        case 6:
        	// Right-bottom
        	canvas.drawRect(w-radius, 2*h/3, w, h, mPaint);
        case 5:
        	// Right-middle
        	canvas.drawRect(w-radius, h/3, w, 2*h/3, mPaint);
        case 4:
        	// Right-top
        	canvas.drawRect(w-radius, radius, w, h/3, mPaint);
        case 3:
        	// Top-right
        	canvas.drawRect(2*w/3, 0, w, radius, mPaint);
        case 2:
        	// Top-middle
        	canvas.drawRect(w/3, 0, 2*w/3, radius, mPaint);
        case 1:
        	// Top-left
        	canvas.drawRect(0, 0, w/3, radius, mPaint);
        case 0:
        case -1:
        	// No draw
        	break;
        }

        mPaint.setFilterBitmap(oldFlag); // restore default flag
    }
}
