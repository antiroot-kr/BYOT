package com.example.touch01;

import java.util.StringTokenizer;

public class TrajPattern {
	private int dbid;
	private int time;
	private String name;
	private int manifest;
	private String pattern;
	
	public static final int _RAW = 1;
	public static final int _QUANTIZED = 2;
	public static final int _AGGREGATED = 3;
	
	public int getDBID(){
		return this.dbid;
	}
	
	public int getTime(){
		return this.time;
	}
	
	public String getName(){
		return this.name;
	}
	
	public int getManifest(){
		return this.manifest;
	}
	
	public String getPattern(){
		return this.pattern;
	}
	
	public TrajPattern(String name){
		this.dbid = 0;
    	this.time = (int) (System.currentTimeMillis() / 1000);
		this.name = name;
		this.manifest = 0;
		this.pattern = null;
	}
		
	public TrajPattern(String name, String pattern, int manifest){
		this.dbid = 0;
    	this.time = (int) (System.currentTimeMillis() / 1000);
		this.name = name;
		this.manifest = manifest;
		this.pattern = pattern;
	}
		
	public TrajPattern(int dbid, int time, String name, String pattern, int manifest){
		this.dbid = dbid;
		this.time = time;
		this.name = name;
		this.manifest = manifest;
		this.pattern = pattern;
	}
	
	public void setDBID(int dbid){
		this.dbid = dbid;
	}

	public void setTime(int time){
		this.time = time;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setManifest(int manifest){
		this.time = manifest;
	}
	
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	
    public String toString() {
    	String str = "";
    	str += "dbid=" + dbid + ", time=" + time + ", name="
    			+ name + ", manifest=" + manifest + ", pattern=" + pattern;
    	return str;
    }
    
    public String toStringSimple() {
    	String str = "";
    	str += dbid + "_" + time + "_" + name + "_" + manifest + "_" + pattern;
    	return str;
    }

    public boolean setFromStringSimple(String str) {
    	if (str == null || str.isEmpty()) {
    		return false;
    	}
    	StringTokenizer token = new StringTokenizer(str, "_");
    	int i = 0;
    	while (token.hasMoreElements()) {
    		switch (i) {
    		case 0:
    			this.dbid = Integer.parseInt((String) token.nextElement());
    			break;
    		case 1:
    			this.time = Integer.parseInt((String) token.nextElement());
    			break;
    		case 2:
    			this.name = (String) token.nextElement();
    			break;
    		case 3:
    			this.manifest = Integer.parseInt((String) token.nextElement());
    			break;
    		case 4:
    			this.pattern = (String) token.nextElement();
    			break;
    		}
    		++i;
    	}
    	return true;
    }
}
