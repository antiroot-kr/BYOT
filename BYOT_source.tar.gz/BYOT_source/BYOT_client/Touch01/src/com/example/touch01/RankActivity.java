package com.example.touch01;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class RankActivity extends Activity 
implements AsyncResponse.AsyncUserProfileListResponse {
	private DBHelper dbHelper;
	private SQLiteDatabase db;
    private SharedPreferences mPrefs;
    private static final String _ClassName = RankActivity.class.getName();
	public static final String _UserProfileList = _ClassName + ".user_profile_list";
	public static final String _UserProfile = _ClassName + ".user_profile";
	private ImageView imgView;
	private Boolean fromMenu;
	private Button details_button;
	private String _nickname;
	private UserProfile _userProfile;
	List<UserProfile> _upList;
    private String _device_id;
    private Context _context;
    
    private class AsyncUserProfileListLookupTask extends AsyncTask<Integer, Void, List<UserProfile>> {
    	public AsyncResponse.AsyncUserProfileListResponse delegate = null;

		@Override
        protected List<UserProfile> doInBackground(Integer... rank) {
			List<UserProfile> _upList = dbHelper.lookupUsersByRank(rank[0], rank[1]);
    		if (_upList == null) {
    			Log.e("Touch01", "Error on lookupUsersByRank()");
    			_upList = new ArrayList<UserProfile>();
    			_upList.clear();
    		}
    		return _upList;
        }
        protected void onPostExecute(List<UserProfile> result) {
        	delegate.processUserProfileListFinish(result);
        	this.cancel(true);
        }
    }
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
		setContentView(R.layout.rank);

		this.dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();
		this.dbHelper.setWritableDatabase(db);
		
		_context = this.getApplicationContext();
		
		final TelephonyManager tm =
				(TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);
		_device_id = tm.getDeviceId();
		
    	String str;
    	
    	str = null;
    	str = getIntent().getStringExtra(_UserProfile);
		if (str != null && str.isEmpty() == false) {
        	_userProfile = new UserProfile();
        	_userProfile.setFromStringSimple(str);
		} else {
			// we then lookup user profile from SharedPreferences and the DB
			// TODO: this can be done in an "async way"
			mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
			_nickname = mPrefs.getString(LoginActivity._Nickname, null);

			_userProfile = dbHelper.lookupUser(_nickname);
			if (_userProfile == null) {
				Log.e("Touch01", "Error on lookupUser()");
				_userProfile = new UserProfile(_nickname);
			}
			int rank = dbHelper.lookupUserRank(_nickname);
			if (rank == 0) {
				Log.e("Touch01", "Error on reading user's ranking!");
				rank = 1;
			}
			_userProfile.setRank(rank);
		}
		
    	str = null;
		str = getIntent().getStringExtra(_UserProfileList);
		if (str != null) {
	        StringTokenizer tsToken;
            UserProfile profile;
        	_upList = new ArrayList<UserProfile>();
        	tsToken = new StringTokenizer(str, " ");
        	while (tsToken.hasMoreElements()) {
        		profile = new UserProfile();
        		profile.setFromStringSimple((String) tsToken.nextElement());
        		_upList.add(profile);
        	}
        	UserRankingAdapter urAdapter = new UserRankingAdapter(this, R.layout.rank_list, _upList);
    		ListView listView = (ListView) findViewById(R.id.listViewUserRank);
    		listView.setAdapter(urAdapter);
		} else {
			// we then lookup users by rank from the DB
			_upList = null;
			AsyncUserProfileListLookupTask upListLookupTask = new AsyncUserProfileListLookupTask();
			upListLookupTask.delegate = this;
			upListLookupTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 0, 100);
		}
		
		details_button = (Button) findViewById(R.id.details_button);
		details_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				Uri uri = Uri.parse("http://byotweb.antiroot.net");
			    Intent nextIntent = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(nextIntent);
			}
		});
		
		if (_userProfile != null) {
			TextView textView;

			textView = (TextView) findViewById(R.id.textYourRank);
			int rank = _userProfile.getRank();
			if (rank > 0) {
				textView.setText(Integer.toString(rank));
			} else {
				textView.setText("-");
			}

			textView = (TextView) findViewById(R.id.textYourID);
			textView.setText(_userProfile.getName());
			
			textView = (TextView) findViewById(R.id.textYourTotalScore);
			textView.setText(Integer.toString(_userProfile.getTotalPoint()));
			
			textView = (TextView) findViewById(R.id.textYourAttackScore);
			textView.setText(Integer.toString(_userProfile.getAttackPoint()));
			
			textView = (TextView) findViewById(R.id.textYourDefenseScore);
			textView.setText(Integer.toString(_userProfile.getDefensePoint()));
			
			textView = (TextView) findViewById(R.id.textYourUsabilityScore);
			textView.setText(Integer.toString(_userProfile.getUsabilityPoint()));
		}
	}

	@Override
	public void processUserProfileListFinish(List<UserProfile> output) {
		if (output == null) {
			this._upList = new ArrayList<UserProfile>();
		} else {
			this._upList = output;
		}
		UserRankingAdapter urAdapter = new UserRankingAdapter(this, R.layout.rank_list, _upList);
		ListView listView = (ListView) findViewById(R.id.listViewUserRank);
		listView.setAdapter(urAdapter);
		Log.d("Touch01", "AsyncUserProfileListLookupTask is finished.");
	}
	
	@Override
	public void onBackPressed(){
	    if (dbHelper != null) {
	    	dbHelper.clearWritableDatabase();
	        dbHelper.close();
	        dbHelper = null;
	    }
	    if (db != null) {
	        db.close();
	        db = null;
	    }
	    super.onBackPressed();
	}
}
