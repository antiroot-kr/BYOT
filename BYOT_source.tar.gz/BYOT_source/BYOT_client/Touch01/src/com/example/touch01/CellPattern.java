package com.example.touch01;

import java.util.StringTokenizer;

public class CellPattern {
	private int dbid;
	private int time;
	private String name;
	private String pattern;
	
	public int getDBID(){
		return this.dbid;
	}
	
	public int getTime(){
		return this.time;
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getPattern(){
		return this.pattern;
	}
	
	public CellPattern(String name){
		this.dbid = 0;
    	this.time = (int) (System.currentTimeMillis() / 1000);
		this.name = name;
		this.pattern = null;
	}
		
	public CellPattern(String name, String pattern){
		this.dbid = 0;
    	this.time = (int) (System.currentTimeMillis() / 1000);
		this.name = name;
		this.pattern = pattern;
	}
		
	public CellPattern(int dbid, int time, String name, String pattern){
		this.dbid = dbid;
		this.time = time;
		this.name = name;
		this.pattern = pattern;
	}
	
	public void setDBID(int dbid){
		this.dbid = dbid;
	}

	public void setTime(int time){
		this.time = time;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	
    public String toString() {
    	String str = "";
    	str += "dbid=" + dbid + ", time=" + time + ", name=" + name + ", pattern=" + pattern;
    	return str;
    }
    
    public String toStringSimple() {
    	String str = "";
    	str += dbid + "_" + time + "_" + name + "_" + pattern;
    	return str;
    }

    public boolean setFromStringSimple(String str) {
    	if (str == null || str.isEmpty()) {
    		return false;
    	}
    	StringTokenizer token = new StringTokenizer(str, "_");
    	int i = 0;
    	while (token.hasMoreElements()) {
    		switch (i) {
    		case 0:
    			this.dbid = Integer.parseInt((String) token.nextElement());
    			break;
    		case 1:
    			this.time = Integer.parseInt((String) token.nextElement());
    			break;
    		case 2:
    			this.name = (String) token.nextElement();
    			break;
    		case 3:
    			this.pattern = (String) token.nextElement();
    			break;
    		}
    		++i;
    	}
    	return true;
    }
}
