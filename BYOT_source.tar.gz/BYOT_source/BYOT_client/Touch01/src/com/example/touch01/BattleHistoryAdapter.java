package com.example.touch01;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class BattleHistoryAdapter extends BaseAdapter{
	private List<BattleHistory> bhList;
	private Context ctx;
	private int itemLayout;
	private String _nickname;

	public BattleHistoryAdapter(Context ctx, int itemLayout, List<BattleHistory> bhList){
		this.ctx = ctx;
		this.itemLayout = itemLayout;
		this.bhList = bhList;
		this._nickname = null;
	}
	
	@Override
	public int getCount() {
		return bhList.size();
	}

	@Override
	public BattleHistory getItem(int position) {
		return bhList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	public void setName(String name){
		this._nickname = name;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(itemLayout, parent, false);
		}
		TextView textView = (TextView) convertView.findViewById(R.id.textWonOrLost);
		int manifest = bhList.get(position).getManifest();
		Boolean bPlayerAttacker = bhList.get(position).getPlayerName().equals(_nickname);
		switch (manifest) {
		case BattleHistory._WON:
			if (bPlayerAttacker) {
				textView.setText("W");
				textView.setTextColor(Color.GREEN);
			} else {
				textView.setText("L");
				textView.setTextColor(Color.RED);
			}
			break;
		case BattleHistory._LOST:
			if (bPlayerAttacker) {
				textView.setText("L");
				textView.setTextColor(Color.RED);
			} else {
				textView.setText("W");
				textView.setTextColor(Color.GREEN);
			}
			break;
		case BattleHistory._RESET:
			textView.setText("R");
			textView.setTextColor(Color.BLUE);
			break;
		case BattleHistory._SUCCESS:
			textView.setText("S");
			textView.setTextColor(Color.GREEN);
			break;
		case BattleHistory._FAIL:
			textView.setText("F");
			textView.setTextColor(Color.RED);
			break;
		default:
			textView.setText("");
			break;
		}
		textView = (TextView) convertView.findViewById(R.id.textBattleAttackerScore);
		int point;
		String str;
		point = bhList.get(position).getRewardPoint();
		str = bhList.get(position).getPlayerName();
		if (str.equals(_nickname)) {
			textView.setTypeface(null, Typeface.BOLD);
		} else {
			textView.setTypeface(null, Typeface.NORMAL);
		}
		str += " (" + bhList.get(position).getPlayerPoint() + ")";
		textView.setText(str);

		textView = (TextView) convertView.findViewById(R.id.textBattleDefenderScore);
		str = bhList.get(position).getOpponentName();
		if (str != null && str.length() > 0 && str.equals("(null)") == false) {
			if (str.equals(_nickname)) {
				textView.setTypeface(null, Typeface.BOLD);
			} else {
				textView.setTypeface(null, Typeface.NORMAL);
			}
			str += " (" + bhList.get(position).getOpponentPoint() + ")";
			textView.setTextColor(Color.WHITE);
		} else {
			switch (manifest) {
			case BattleHistory._RESET:
				str = "reset";
				textView.setTextColor(Color.GRAY);
				break;
			case BattleHistory._SUCCESS:
			case BattleHistory._FAIL:
				str = "self unlock";
				textView.setTextColor(Color.GRAY);
				break;
			default:
				textView.setTextColor(Color.WHITE);
				str = " ";
				break;
			}
		}
		textView.setText(str);

		textView = (TextView) convertView.findViewById(R.id.textBattleReward);
		if (bhList.get(position).getPlayerName().equals(_nickname) == false) {
			point = 0 - point;
		}
		textView.setText(Integer.toString(point));
		if (point >= 0) {
			textView.setTextColor(Color.GREEN);
		} else {
			textView.setTextColor(Color.RED);
		}
		
		textView = (TextView) convertView.findViewById(R.id.textBattleTime);
		
		int logTime = bhList.get(position).getTime();
		int curTime = (int)(System.currentTimeMillis() / 1000) - logTime;
		if (curTime < 0) {
			curTime = 0;
		}
		if (curTime >= 31536000) {
			curTime /= 31536000;
			str = curTime + " year";
		} else if (curTime >= 86400) {
			curTime /= 86400;
			str = curTime + " day";
		} else if (curTime >= 3600) {
			curTime /= 3600;
			str = curTime + " hour";
		} else if (curTime >= 60) {
			curTime /= 60;
			str = curTime + " minute";
		} else {
			str = curTime + " second";
		}
		if (curTime > 1) {
			str += "s";
		}
		str += " ago ";
		textView.setText(str);
		return convertView;
	}
}
