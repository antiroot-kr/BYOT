package com.example.touch01;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ProfileActivity extends Activity 
implements AsyncResponse.AsyncUserProfileResponse {
	private DBHelper dbHelper;
	private SQLiteDatabase db;
	
    private static final String _ClassName = ProfileActivity.class.getName();
	public static final String _UserProfile = _ClassName + ".user_profile";
	
	private Button details_button;
	private TextView textID;
	private TextView textScore;
	private TextView textRank;
	private TextView textTSS;
	private TextView textTSSP;
	private TextView textTFS;
	private TextView textTFSP;
	private TextView textFSS;
	private TextView textFSSP;
	private TextView textFFS;
	private TextView textFFSP;
	private TextView textTFO;
	private TextView textTFOP;
	private TextView textFSO;
	private TextView textFSOP;
	private ImageView imgView;

	private String _nickname;
	private UserProfile _userProfile;
    private SharedPreferences mPrefs;
	
    private class AsyncUserProfileLookupTask extends AsyncTask<String, Void, UserProfile> {
    	public AsyncResponse.AsyncUserProfileResponse delegate = null;

		@Override
        protected UserProfile doInBackground(String... names) {
        	UserProfile _userProfile = dbHelper.lookupUser(names[0]);
    		if (_userProfile == null) {
    			Log.e("Touch01", "Error on lookupUser()");
    			_userProfile = new UserProfile(names[0]);
    		}
    		int rank = dbHelper.lookupUserRank(names[0]);
			if (rank == 0) {
				Log.e("Touch01", "Error on reading user's ranking!");
				rank = 1;
			}
			_userProfile.setRank(rank);
    		return _userProfile;
        }

        protected void onPostExecute(UserProfile result) {
        	delegate.processUserProfileFinish(result);
        }
    }
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.profile);
		
		this.dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();
		this.dbHelper.setWritableDatabase(db);
		
    	String str;
    	
    	str = null;
    	str = getIntent().getStringExtra(_UserProfile);
		if (str != null && str.isEmpty() == false) {
        	_userProfile = new UserProfile();
        	_userProfile.setFromStringSimple(str);
        	
			// Now, let's initiate text boxes. 
        	int tmp, tmp2;
			textID = (TextView) findViewById(R.id.textProfileID);
			str = _userProfile.getName();
			textID.setText(str);
			textScore = (TextView) findViewById(R.id.textProfileScore);
			tmp = _userProfile.getTotalPoint();
			textScore.setText(Integer.toString(tmp));
			textRank = (TextView) findViewById(R.id.textProfileRank);
			tmp = _userProfile.getRank();
			if (tmp > 0) {
				textRank.setText(Integer.toString(tmp));
			} else {
				textRank.setText("-");
			}
			textTSS = (TextView) findViewById(R.id.textProfileTSS);
			tmp = _userProfile.getTrueSuccessSelf();
			textTSS.setText(Integer.toString(tmp));
			textTSS.setTypeface(null, Typeface.BOLD);
			textTSSP = (TextView) findViewById(R.id.textProfileTSSP);
			tmp = _userProfile.getTrueSuccessSelf();
			tmp2 = tmp + _userProfile.getFalseFailureSelf();
			if (tmp2 == 0) tmp = 0;
			else tmp = tmp * 100 / tmp2;
			str = "(" + tmp + "%)";
			textTSSP.setText(str);
			textTSSP.setTypeface(null, Typeface.BOLD);
			textTFS = (TextView) findViewById(R.id.textProfileTFS);
			tmp = _userProfile.getTrueFailureSelf();
			textTFS.setText(Integer.toString(tmp));
			textTFSP = (TextView) findViewById(R.id.textProfileTFSP);
			tmp = _userProfile.getTrueFailureSelf();
			tmp2 = tmp + _userProfile.getFalseSuccessSelf();
			if (tmp2 == 0) tmp = 0;
			else tmp = tmp * 100 / tmp2;
			str = "(" + tmp + "%)";
			textTFSP.setText(str);
			textFSS = (TextView) findViewById(R.id.textProfileFSS);
			tmp = _userProfile.getFalseSuccessSelf();
			textFSS.setText(Integer.toString(tmp));
			textFSS.setTypeface(null, Typeface.BOLD);
			textFSSP = (TextView) findViewById(R.id.textProfileFSSP);
			tmp = _userProfile.getFalseSuccessSelf();
			tmp2 = tmp + _userProfile.getTrueFailureSelf();
			if (tmp2 == 0) tmp = 0;
			else tmp = tmp * 100 / tmp2;
			str = "(" + tmp + "%)";
			textFSSP.setText(str);
			textFSSP.setTypeface(null, Typeface.BOLD);
			textFFS = (TextView) findViewById(R.id.textProfileFFS);
			tmp = _userProfile.getFalseFailureSelf();
			textFFS.setText(Integer.toString(tmp));
			textFFSP = (TextView) findViewById(R.id.textProfileFFSP);
			tmp = _userProfile.getFalseFailureSelf();
			tmp2 = tmp + _userProfile.getTrueSuccessSelf();
			if (tmp2 == 0) tmp = 0;
			else tmp = tmp * 100 / tmp2;
			str = "(" + tmp + "%)";
			textFFSP.setText(str);
			textTFO = (TextView) findViewById(R.id.textProfileTFO);
			tmp = _userProfile.getTrueFailureOther();
			textTFO.setText(Integer.toString(tmp));
			textTFO.setTypeface(null, Typeface.BOLD);
			textTFOP = (TextView) findViewById(R.id.textProfileTFOP);
			tmp = _userProfile.getTrueFailureOther();
			tmp2 = tmp + _userProfile.getFalseSuccessOther();
			if (tmp2 == 0) tmp = 0;
			else tmp = tmp * 100 / tmp2;
			str = "(" + tmp + "%)";
			textTFOP.setText(str);
			textTFOP.setTypeface(null, Typeface.BOLD);
			textFSO = (TextView) findViewById(R.id.textProfileFSO);
			tmp = _userProfile.getFalseSuccessOther();
			textFSO.setText(Integer.toString(tmp));
			textFSOP = (TextView) findViewById(R.id.textProfileFSOP);
			tmp = _userProfile.getFalseSuccessOther();
			tmp2 = tmp + _userProfile.getTrueFailureOther();
			if (tmp2 == 0) tmp = 0;
			else tmp = tmp * 100 / tmp2;
			str = "(" + tmp + "%)";
			textFSOP.setText(str);
		} else {
			// we then lookup user profile from SharedPreferences and the DB
			mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
			_nickname = mPrefs.getString(LoginActivity._Nickname, null);

			AsyncUserProfileLookupTask upLookupTask = new AsyncUserProfileLookupTask();
			upLookupTask.delegate = this;
			upLookupTask.execute(_nickname);
		}
		
		//imgView = (ImageView) this.findViewById(R.id.imageProfile);
				
		details_button = (Button) findViewById(R.id.details_button);
		details_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				Uri uri = Uri.parse("http://byotweb.antiroot.net");
			    Intent nextIntent = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(nextIntent);
			}
		});
	}

	@Override
	public void processUserProfileFinish(UserProfile output) {
		this._userProfile = output;

		// Now, let's initiate text boxes. 
    	int tmp, tmp2;
    	String str;
		textID = (TextView) findViewById(R.id.textProfileID);
		str = _userProfile.getName();
		textID.setText(str);
		textScore = (TextView) findViewById(R.id.textProfileScore);
		tmp = _userProfile.getTotalPoint();
		textScore.setText(Integer.toString(tmp));
		textRank = (TextView) findViewById(R.id.textProfileRank);
		tmp = _userProfile.getRank();
		if (tmp > 0) {
			textRank.setText(Integer.toString(tmp));
		} else {
			textRank.setText("-");
		}
		textTSS = (TextView) findViewById(R.id.textProfileTSS);
		tmp = _userProfile.getTrueSuccessSelf();
		textTSS.setText(Integer.toString(tmp));
		textTSSP = (TextView) findViewById(R.id.textProfileTSSP);
		tmp = _userProfile.getTrueSuccessSelf();
		tmp2 = tmp + _userProfile.getFalseFailureSelf();
		if (tmp2 == 0) tmp = 0;
		else tmp = tmp * 100 / tmp2;
		str = "(" + tmp + "%)";
		textTSSP.setText(str);
		textTFS = (TextView) findViewById(R.id.textProfileTFS);
		tmp = _userProfile.getTrueFailureSelf();
		textTFS.setText(Integer.toString(tmp));
		textTFSP = (TextView) findViewById(R.id.textProfileTFSP);
		tmp = _userProfile.getTrueFailureSelf();
		tmp2 = tmp + _userProfile.getFalseSuccessSelf();
		if (tmp2 == 0) tmp = 0;
		else tmp = tmp * 100 / tmp2;
		str = "(" + tmp + "%)";
		textTFSP.setText(str);
		textFSS = (TextView) findViewById(R.id.textProfileFSS);
		tmp = _userProfile.getFalseSuccessSelf();
		textFSS.setText(Integer.toString(tmp));
		textFSSP = (TextView) findViewById(R.id.textProfileFSSP);
		tmp = _userProfile.getFalseSuccessSelf();
		tmp2 = tmp + _userProfile.getTrueFailureSelf();
		if (tmp2 == 0) tmp = 0;
		else tmp = tmp * 100 / tmp2;
		str = "(" + tmp + "%)";
		textFSSP.setText(str);
		textFFS = (TextView) findViewById(R.id.textProfileFFS);
		tmp = _userProfile.getFalseFailureSelf();
		textFFS.setText(Integer.toString(tmp));
		textFFSP = (TextView) findViewById(R.id.textProfileFFSP);
		tmp = _userProfile.getFalseFailureSelf();
		tmp2 = tmp + _userProfile.getTrueSuccessSelf();
		if (tmp2 == 0) tmp = 0;
		else tmp = tmp * 100 / tmp2;
		str = "(" + tmp + "%)";
		textFFSP.setText(str);
		textTFO = (TextView) findViewById(R.id.textProfileTFO);
		tmp = _userProfile.getTrueFailureOther();
		textTFO.setText(Integer.toString(tmp));
		textTFOP = (TextView) findViewById(R.id.textProfileTFOP);
		tmp = _userProfile.getTrueFailureOther();
		tmp2 = tmp + _userProfile.getFalseSuccessOther();
		if (tmp2 == 0) tmp = 0;
		else tmp = tmp * 100 / tmp2;
		str = "(" + tmp + "%)";
		textTFOP.setText(str);
		textFSO = (TextView) findViewById(R.id.textProfileFSO);
		tmp = _userProfile.getFalseSuccessOther();
		textFSO.setText(Integer.toString(tmp));
		textFSOP = (TextView) findViewById(R.id.textProfileFSOP);
		tmp = _userProfile.getFalseSuccessOther();
		tmp2 = tmp + _userProfile.getTrueFailureOther();
		if (tmp2 == 0) tmp = 0;
		else tmp = tmp * 100 / tmp2;
		str = "(" + tmp + "%)";
		textFSOP.setText(str);
		
		Log.d("Touch01", "AsyncUserProfileLookupTask is finished.");
	}
	
	@Override
	public void onBackPressed(){
	    if (dbHelper != null) {
	    	dbHelper.clearWritableDatabase();
	        dbHelper.close();
	        dbHelper = null;
	    }
	    if (db != null) {
	        db.close();
	        db = null;
	    }
	    super.onBackPressed();

	}
}
