package com.example.touch01;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class UserRankingAdapter extends BaseAdapter{
	private List<UserProfile> upList;
	private Context ctx;
	private int itemLayout;

	public UserRankingAdapter(Context ctx, int itemLayout, List<UserProfile> upList){
		this.ctx = ctx;
		this.itemLayout = itemLayout;
		this.upList = upList;
	}
	
	@Override
	public int getCount() {
		return upList.size();
	}

	@Override
	public UserProfile getItem(int position) {
		return upList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(itemLayout, parent, false);
		}
		TextView textView;
		textView = (TextView) convertView.findViewById(R.id.textGlobalRank);
		textView.setText(Integer.toString(position + 1));
		/*int rank = upList.get(position).getRank();
		if (rank > 0) {
			textView.setText(Integer.toString(upList.get(position).getRank()));
		} else {
			textView.setText("-");
		}*/

		textView = (TextView) convertView.findViewById(R.id.textGlobalID);
		textView.setText(upList.get(position).getName());
		
		textView = (TextView) convertView.findViewById(R.id.textGlobalTotalScore);
		textView.setText(Integer.toString(upList.get(position).getTotalPoint()));
		
		textView = (TextView) convertView.findViewById(R.id.textGlobalAttackScore);
		textView.setText(Integer.toString(upList.get(position).getAttackPoint()));
		
		textView = (TextView) convertView.findViewById(R.id.textGlobalDefenseScore);
		textView.setText(Integer.toString(upList.get(position).getDefensePoint()));
		
		textView = (TextView) convertView.findViewById(R.id.textGlobalUsabilityScore);
		textView.setText(Integer.toString(upList.get(position).getUsabilityPoint()));
		return convertView;
	}
}
