package com.example.touch01;

import java.util.StringTokenizer;

public class UserProfile {
	private int dbid = 0;
	private String name = "dummy";
	private int time = 0;
	private int last_login = 0;
	private int total_point = 0;
	private int attack_point = 0;
	private int defense_point = 0;
	private int usability_point = 0;
	private int rank = 0;
	private int n_trial_self = 0;
	private int n_trial_other = 0;
	private int n_true_success_self = 0;
	private int n_true_failure_self = 0;
	private int n_false_success_self = 0;
	private int n_false_failure_self = 0; // NOT USED THIS TIME
	private int n_true_success_other = 0; // NOT USED THIS TIME
	private int n_true_failure_other = 0;
	private int n_false_success_other = 0;
	private int n_false_failure_other = 0;
	public static final int default_total_point = 1500;
	public static final int default_attack_point = 500;
	public static final int default_defense_point = 500;
	public static final int default_usability_point = 500;
	
	
	public int getDBID(){
		return this.dbid;
	}
	
	public String getName(){
		return this.name;
	}
	
	public int getTime(){
		return this.time;
	}
	
	public int getLastLogin(){
		return this.last_login;
	}
	
	public int getTotalPoint(){
		return this.total_point;
	}
	
	public int getAttackPoint(){
		return this.attack_point;
	}
	
	public int getDefensePoint(){
		return this.defense_point;
	}
	
	public int getUsabilityPoint(){
		return this.usability_point;
	}
	
	public int getRank(){
		return this.rank;
	}
	
	public int getTrialSelf(){
		return this.n_trial_self;
	}
	
	public int getTrialOther(){
		return this.n_trial_other;
	}
	
	public int getTrueSuccessSelf(){
		return this.n_true_success_self;
	}
	
	public int getTrueFailureSelf(){
		return this.n_true_failure_self;
	}
	
	public int getFalseSuccessSelf(){
		return this.n_false_success_self;
	}
	
	public int getFalseFailureSelf(){
		return this.n_false_failure_self;
	}
	
	public int getTrueSuccessOther(){
		return this.n_true_success_other;
	}
	
	public int getTrueFailureOther(){
		return this.n_true_failure_other;
	}
	
	public int getFalseSuccessOther(){
		return this.n_false_success_other;
	}
	
	public int getFalseFailureOther(){
		return this.n_false_failure_other;
	}

	public UserProfile(){
		this.dbid = 0;
		this.name = "";
		this.time = (int) (System.currentTimeMillis() / 1000);
		this.last_login = this.time;
		this.rank = 0;
		this.total_point = UserProfile.default_total_point;
		this.attack_point = UserProfile.default_attack_point;
		this.defense_point = UserProfile.default_defense_point;
		this.usability_point = UserProfile.default_usability_point;
		this.n_trial_self = 0;
		this.n_trial_other = 0;
		this.n_true_success_self = 0;
		this.n_true_failure_self = 0;
		this.n_false_success_self = 0;
		this.n_false_failure_self = 0;
		this.n_true_success_other = 0;
		this.n_true_failure_other = 0;
		this.n_false_success_other = 0;
		this.n_false_failure_other = 0;
	}
	
	public UserProfile(String name){
		this.dbid = 0;
		this.name = name;
		this.time = (int) (System.currentTimeMillis() / 1000);
		this.last_login = this.time;
		this.rank = 0;
		this.total_point = UserProfile.default_total_point;
		this.attack_point = UserProfile.default_attack_point;
		this.defense_point = UserProfile.default_defense_point;
		this.usability_point = UserProfile.default_usability_point;
		this.n_trial_self = 0;
		this.n_trial_other = 0;
		this.n_true_success_self = 0;
		this.n_true_failure_self = 0;
		this.n_false_success_self = 0;
		this.n_false_failure_self = 0;
		this.n_true_success_other = 0;
		this.n_true_failure_other = 0;
		this.n_false_success_other = 0;
		this.n_false_failure_other = 0;
	}
	
	public UserProfile(int dbid, int time, int last_login, String name,
			int total_point, int attack_point,
			int defense_point, int usability_point,
			int n_trial_self, int n_trial_other,
			int n_true_success_self, int n_true_failure_self,
			int n_false_success_self, int n_false_failure_self,
			int n_true_success_other, int n_true_failure_other,
			int n_false_success_other, int n_false_failure_other){
		this.rank = 0;
		this.dbid = dbid;
		this.time = time;
		this.last_login = last_login;
		this.name = name;
		this.total_point = total_point;
		this.attack_point = attack_point;
		this.defense_point = defense_point;
		this.usability_point = usability_point;
		this.n_trial_self = n_trial_self;
		this.n_trial_other = n_trial_other;
		this.n_true_success_self = n_true_success_self;
		this.n_true_failure_self = n_true_failure_self;
		this.n_false_success_self = n_false_success_self;
		this.n_false_failure_self = n_false_failure_self;
		this.n_true_success_other = n_true_success_other;
		this.n_true_failure_other = n_true_failure_other;
		this.n_false_success_other = n_false_success_other;
		this.n_false_failure_other = n_false_failure_other;
	}
	
	public void setDBID(int dbid){
		this.dbid = dbid;
	}

	public void setName(String name){
		this.name = name;
	}
	
	public void setTime(int time){
		this.time = time;
	}
	
	public void setLastLogin(int last_login){
		this.last_login = last_login;
	}
	
	public void setTotalPoint(int point){
		this.total_point = point;
	}
	
	public void setAttackPoint(int point){
		this.attack_point = point;
	}
	
	public void setDefensePoint(int point){
		this.defense_point = point;
	}
	
	public void setUsabilityPoint(int point){
		this.usability_point = point;
	}
	
	public void setRank(int rank){
		this.rank = rank;
	}
	
	public void setTrialSelf(int trial_self){
		this.n_trial_self = trial_self;
	}
	
	public void setTrialOther(int trial_other){
		this.n_trial_other = trial_other;
	}
	
	public void incTrialSelf(){
		this.n_trial_self++;
	}
	
	public void incTrialOther(){
		this.n_trial_other++;
	}
	
	public void setTrueSuccessSelf(int true_success_self){
		this.n_true_success_self = true_success_self;
	}
	
	public void setTrueFailureSelf(int true_failure_self){
		this.n_true_failure_self = true_failure_self;
	}
	
	public void setFalseSuccessSelf(int false_success_self){
		this.n_false_success_self = false_success_self;
	}
	
	public void setFalseFailureSelf(int false_failure_self){
		this.n_false_failure_self = false_failure_self;
	}
	
	public void setTrueSuccessOther(int true_success_other){
		this.n_true_success_other = true_success_other;
	}
	
	public void setTrueFailureOther(int true_failure_other){
		this.n_true_failure_other = true_failure_other;
	}
	
	public void setFalseSuccessOther(int false_success_other){
		this.n_false_success_other = false_success_other;
	}
	
	public void setFalseFailureOther(int false_failure_other){
		this.n_false_failure_other = false_failure_other;
	}

	public void incTrueSuccessSelf(){
		this.n_true_success_self++;
	}
	
	public void incTrueFailureSelf(){
		this.n_true_failure_self++;
	}
	
	public void incFalseSuccessSelf(){
		this.n_false_success_self++;
	}
	
	public void incFalseFailureSelf(){
		this.n_false_failure_self++;
	}
	
	public void incTrueSuccessOther(){
		this.n_true_success_other++;
	}
	
	public void incTrueFailureOther(){
		this.n_true_failure_other++;
	}
	
	public void incFalseSuccessOther(){
		this.n_false_success_other++;
	}
	
	public void incFalseFailureOther(){
		this.n_false_failure_other++;
	}
	
	public void setAllDigits(
			int total_point, int attack_point,
			int defense_point, int usability_point,
			int trial_self, int trial_other,
			int true_success_self, int true_failure_self,
			int false_success_self, int false_failure_self,
			int true_success_other, int true_failure_other,
			int false_success_other, int false_failure_other) {
		this.total_point = total_point;
		this.attack_point = attack_point;
		this.defense_point = defense_point;
		this.usability_point = usability_point;
		this.n_trial_self = trial_self;
		this.n_trial_other = trial_other;
		this.n_true_success_self = true_success_self;
		this.n_true_failure_self = true_failure_self;
		this.n_false_success_self = false_success_self;
		this.n_false_failure_self = false_failure_self;
		this.n_true_success_other = true_success_other;
		this.n_true_failure_other = true_failure_other;
		this.n_false_success_other = false_success_other;
		this.n_false_failure_other = false_failure_other;
	}

    public String toString() {
    	String str = "";
    	str += "dbid=" + dbid + ", time=" + time
    		+ ", last_login=" + last_login + ", name=" + name
    		+ ", total_point=" + total_point
    		+ ", attack_point=" + attack_point
    		+ ", defense_point=" + defense_point
    		+ ", usability_point=" + usability_point
    		+ ", nts=" + n_trial_self + ", nto=" + n_trial_other
    		+ ", ntss=" + n_true_success_self + ", ntfs=" + n_true_failure_self
    		+ ", nfss=" + n_false_success_self + ", nffs=" + n_false_failure_self
    		+ ", ntso=" + n_true_success_other + ", ntfo=" + n_true_failure_other
    		+ ", nfso=" + n_false_success_other + ", nffo=" + n_false_failure_other;
    	return str;
    }

    public String toStringSimple() {
    	String str = "";
    	str += dbid + "_" + time
    		+ "_" + last_login
    		+ "_" + name
    		+ "_" + total_point
    		+ "_" + attack_point
    		+ "_" + defense_point
    		+ "_" + usability_point
    		+ "_" + n_trial_self + "_" + n_trial_other
    		+ "_" + n_true_success_self + "_" + n_true_failure_self
    		+ "_" + n_false_success_self + "_" + n_false_failure_self
    		+ "_" + n_true_success_other + "_" + n_true_failure_other
    		+ "_" + n_false_success_other + "_" + n_false_failure_other
    		+ "_" + rank;
    	return str;
    }

    public boolean setFromStringSimple(String str) {
    	if (str == null || str.isEmpty()) {
    		return false;
    	}
    	StringTokenizer token = new StringTokenizer(str, "_");
    	int i = 0;
    	while (token.hasMoreElements()) {
    		switch (i) {
    		case 0:
    			this.dbid = Integer.parseInt((String) token.nextElement());
    			break;
    		case 1:
    			this.time = Integer.parseInt((String) token.nextElement());
    			break;
    		case 2:
    			this.last_login = Integer.parseInt((String) token.nextElement());
    			break;
    		case 3:
    			this.name = (String) token.nextElement();
    			break;
    		case 4:
    			this.total_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 5:
    			this.attack_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 6:
    			this.defense_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 7:
    			this.usability_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 8:
    			this.n_trial_self = Integer.parseInt((String) token.nextElement());
    			break;
    		case 9:
    			this.n_trial_other = Integer.parseInt((String) token.nextElement());
    			break;
    		case 10:
    			this.n_true_success_self = Integer.parseInt((String) token.nextElement());
    			break;
    		case 11:
    			this.n_true_failure_self = Integer.parseInt((String) token.nextElement());
    			break;
    		case 12:
    			this.n_false_success_self = Integer.parseInt((String) token.nextElement());
    			break;
    		case 13:
    			this.n_false_failure_self = Integer.parseInt((String) token.nextElement());
    			break;
    		case 14:
    			this.n_true_success_other = Integer.parseInt((String) token.nextElement());
    			break;
    		case 15:
    			this.n_true_failure_other = Integer.parseInt((String) token.nextElement());
    			break;
    		case 16:
    			this.n_false_success_other = Integer.parseInt((String) token.nextElement());
    			break;
    		case 17:
    			this.n_false_failure_other = Integer.parseInt((String) token.nextElement());
    			break;
    		case 18:
    			this.rank = Integer.parseInt((String) token.nextElement());
    			break;
    		}
    		++i;
    	}
    	return true;
    }

}
