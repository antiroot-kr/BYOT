package com.example.touch01;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;

import group.pals.android.lib.ui.lockpattern.LockPatternActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

@SuppressLint("NewApi")
public class MenuActivity extends Activity
implements AsyncResponse.AsyncUserProfileResponse, 
AsyncResponse.AsyncUserProfileListResponse,
AsyncResponse.AsyncBattleHistoryListResponse,
AsyncResponse.AsyncCellPatternResponse, 
AsyncResponse.AsyncRawTrajPatternResponse, 
AsyncResponse.AsyncQuanTrajPatternResponse, 
AsyncResponse.AsyncAggTrajPatternResponse, 
AsyncResponse.AsyncCountUserResponse 
{
	private DBHelper dbHelper;
	private SQLiteDatabase db;
	
    private static final String _ClassName = MenuActivity.class.getName();
	public static final String _UserProfile = _ClassName + ".user_profile";

	private Button create_button;
	private Button unlock_button;
	private Button review_line_button;
	private Button review_grid_button;
	private Button recali_button;
	private Button battle_button;
	private Button rankin_button;
	
	private Boolean create_button_enabled = false;
	private Boolean unlock_button_enabled = false;
	private Boolean review_line_button_enabled = false;
	private Boolean review_grid_button_enabled = false;
	private Boolean recali_button_enabled = false;
	private Boolean battle_button_enabled = false;
	private Boolean rankin_button_enabled = false;
	
	
	public static final int _ReqCreatePattern = 1;
	public static final int _ReqUnlockPattern = 2;
	public static final int _ReqRecalibration = 3;
	public static final int _ReqBattleWorld = 4;
	public static final int mNumTraining = 8;
	
	private final int btnColorInactive = 0xff000000;
	private final int txtColorInactive = 0xff505050;
	private final int txtColorActive = 0xffffffff;
	private final int btnColorCreate = 0xff550000;
	private final int btnColorReviewLine = 0xff403000;
	private final int btnColorReviewGrid = 0xff304000;
	private final int btnColorUnlock = 0xff005500;
	private final int btnColorBattle = 0xff003040;
	private final int btnColorRecali = 0xff000055;
	private final int btnColorRankin = 0xff300040;
	
	/*private final int btnColor1 = 0xff660066;
	private final int btnColor2 = 0xff990099;
	private final int btnColor3 = 0xff993399;
	private final int btnColor4 = 0xff663366;
	private final int btnColor5 = 0xff996699;
	private final int btnColor6 = 0xff663399;
	private final int btnColor7 = 0xff9966CC;*/
	
	public String _createdPattern;
	public String _createdTruePattern;
	public String _createdTouchSignal;
	public String _createdTouchSignals;
	public String _createdGridSignal;
	public String _createdGridSignals;
    private SharedPreferences mPrefs;
    private long _timeBackKey = 0;
    private Toast _quitToast;
    private String _nickname;
    private int _numUsers;
    private String _device_id;
    private Context _context;
    
    private UserProfile _userProfile;
    private List<UserProfile> _upList;
    private List<BattleHistory> _bhList;
    //private ProgressBar _progressBar;
    
    private int _thumbPres;
    private int _thumbSize;
    private int _tipPres;
    private int _tipSize;
    
    private Toast waitToast = null;

    private class AsyncCountUserTask extends AsyncTask<Void, Void, Integer> {
    	public AsyncResponse.AsyncCountUserResponse delegate = null;

		@Override
        protected Integer doInBackground(Void... args) {
    		if (dbHelper == null) {
    			return null;
    		}
			int count = dbHelper.countUsers();
    		if (count == 0) {
    			Log.e("Touch01", "Error on countUsers()");
    			count = 1;
    		}
    		return Integer.valueOf(count);
        }
        protected void onPostExecute(Integer result) {
        	delegate.processCountUserFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncUserProfileLookupTask extends AsyncTask<String, Void, UserProfile> {
    	public AsyncResponse.AsyncUserProfileResponse delegate = null;

		@Override
        protected UserProfile doInBackground(String... names) {
    		if (dbHelper == null) {
    			return null;
    		}
        	UserProfile _userProfile = dbHelper.lookupUser(names[0]);
    		if (_userProfile == null) {
    			Log.e("Touch01", "Error on lookupUser()");
    			_userProfile = new UserProfile(names[0]);
    		}
    		if (dbHelper == null) {
    			return null;
    		}
    		int rank = dbHelper.lookupUserRank(names[0]);
			if (rank == 0) {
				Log.d("Touch01", "Error on reading user's ranking!");
				rank = 0;
			}
			_userProfile.setRank(rank);
    		return _userProfile;
        }

        protected void onPostExecute(UserProfile result) {
        	delegate.processUserProfileFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncUserProfileListLookupTask extends AsyncTask<Integer, Void, List<UserProfile>> {
    	public AsyncResponse.AsyncUserProfileListResponse delegate = null;

		@Override
        protected List<UserProfile> doInBackground(Integer... rank) {
    		if (dbHelper == null) {
    			return null;
    		}
			List<UserProfile> _upList = dbHelper.lookupUsersByRank(rank[0], rank[1]);
    		if (_upList == null) {
    			Log.e("Touch01", "Error on lookupUsersByRank()");
    			_upList = new ArrayList<UserProfile>();
    			_upList.clear();
    		}
    		return _upList;
        }
        protected void onPostExecute(List<UserProfile> result) {
        	delegate.processUserProfileListFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncBattleHistoryListLookupTask extends AsyncTask<String, Void, List<BattleHistory>> {
    	public AsyncResponse.AsyncBattleHistoryListResponse delegate = null;

		@Override
        protected List<BattleHistory> doInBackground(String... names) {
    		if (dbHelper == null) {
    			return null;
    		}
			List<BattleHistory> _bhList = dbHelper.lookupBattHistory(names[0]);
    		if (_bhList == null) {
    			Log.d("Touch01", "There is no battle history.");
    			_bhList = new ArrayList<BattleHistory>();
    			_bhList.clear();
    		}
    		return _bhList;
        }
        protected void onPostExecute(List<BattleHistory> result) {
        	delegate.processBattleHistoryListFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncCellPatternLookupTask extends AsyncTask<String, Void, CellPattern> {
    	public AsyncResponse.AsyncCellPatternResponse delegate = null;

		@Override
        protected CellPattern doInBackground(String... names) {
    		if (dbHelper == null) {
    			return null;
    		}
			CellPattern _cellPattern = dbHelper.lookupCellPattern(names[0]);
    		if (_cellPattern == null) {
    			Log.d("Touch01", "There is no cell pattern.");
    		}
    		return _cellPattern;
        }
        protected void onPostExecute(CellPattern result) {
        	delegate.processCellPatternFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncRawTrajPatternLookupTask extends AsyncTask<String, Void, List<TrajPattern>> {
    	public AsyncResponse.AsyncRawTrajPatternResponse delegate = null;

		@Override
        protected List<TrajPattern> doInBackground(String... names) {
    		if (dbHelper == null) {
    			return null;
    		}
			List<TrajPattern> _rawPatterns = dbHelper.lookupTrajPattern(names[0], TrajPattern._RAW);
    		if (_rawPatterns == null) {
    			Log.d("Touch01", "There are no raw traj patterns.");
    		}
    		return _rawPatterns;
        }
        protected void onPostExecute(List<TrajPattern> result) {
        	delegate.processRawTrajPatternFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncQuanTrajPatternLookupTask extends AsyncTask<String, Void, List<TrajPattern>> {
    	public AsyncResponse.AsyncQuanTrajPatternResponse delegate = null;

		@Override
        protected List<TrajPattern> doInBackground(String... names) {
    		if (dbHelper == null) {
    			return null;
    		}
			List<TrajPattern> _quanPatterns = dbHelper.lookupTrajPattern(names[0], TrajPattern._QUANTIZED);
    		if (_quanPatterns == null) {
    			Log.d("Touch01", "There are no quantized traj patterns.");
    		}
    		return _quanPatterns;
        }
        protected void onPostExecute(List<TrajPattern> result) {
        	delegate.processQuanTrajPatternFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncAggTrajPatternLookupTask extends AsyncTask<String, Void, TrajPattern> {
    	public AsyncResponse.AsyncAggTrajPatternResponse delegate = null;

		@Override
        protected TrajPattern doInBackground(String... names) {
    		if (dbHelper == null) {
    			return null;
    		}
			List<TrajPattern> _aggPatterns = dbHelper.lookupTrajPattern(names[0], TrajPattern._AGGREGATED);
    		if (_aggPatterns == null) {
    			Log.d("Touch01", "There is no aggregated traj pattern.");
    			return null;
    		} else {
    			return _aggPatterns.get(0);
    		}
        }
        protected void onPostExecute(TrajPattern result) {
        	delegate.processAggTrajPatternFinish(result);
        	this.cancel(true);
        }
    }
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.menu);
		
		this.dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();
		this.dbHelper.setWritableDatabase(db);
		
		_context = this.getApplicationContext();
		
		final TelephonyManager tm =
				(TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);
		_device_id = tm.getDeviceId();

		mPrefs = getSharedPreferences(CalibrationBaseActivity.class.getName(), 0);
		_thumbPres = mPrefs.getInt(CalibrationBaseActivity._Pressure, 90);
		_thumbSize = mPrefs.getInt(CalibrationBaseActivity._Size, 90);
		
		mPrefs = getSharedPreferences(CalibrationTipActivity.class.getName(), 0);
		_tipPres = mPrefs.getInt(CalibrationTipActivity._Pressure, 90);
		_tipSize = mPrefs.getInt(CalibrationTipActivity._Size, 90);
		
		String str = "Thumb (p, s)= (" + _thumbPres + ", " + _thumbSize + "),  Tip (p, s)= (" + _tipPres + ", " + _tipSize + ")";
		Log.d("Touch01", str);
		
		/*_progressBar = (ProgressBar) findViewById(R.id.menu_progress_bar);
		Drawable drawable = this.getResources().getDrawable(R.drawable.custom_progress_bar);
		_progressBar.setProgressDrawable(drawable);
		_progressBar.setMax(100);
		_progressBar.setProgress(0);*/
		
		create_button = (Button) findViewById(R.id.create_button);
		//create_button.setBackgroundColor(btnColorCreate);
		create_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				if (create_button_enabled == false) {
					return;
				}
				if (_createdTruePattern.isEmpty() == false) {
					DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface dialog, int which) {
					        switch (which){
					        case DialogInterface.BUTTON_POSITIVE:
					            //Yes button clicked
								Intent intent = new Intent(LockPatternActivity._ActionCreatePattern, null, 
										MenuActivity.this, LockPatternActivity.class);
								intent.putExtra(LockPatternActivity._NumTraining, mNumTraining);
								intent.putExtra(LockPatternActivity._BgColor, btnColorCreate);
								
								intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
								intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
								intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
								intent.putExtra(LockPatternActivity._TipSize, _tipSize);

								if (_userProfile != null) {
									intent.putExtra(LockPatternActivity._ID, _userProfile.getName());
									intent.putExtra(LockPatternActivity._TotalScore, _userProfile.getTotalPoint());
									intent.putExtra(LockPatternActivity._AttackScore, _userProfile.getAttackPoint());
									intent.putExtra(LockPatternActivity._DefenseScore, _userProfile.getDefensePoint());
									intent.putExtra(LockPatternActivity._UsabilityScore, _userProfile.getUsabilityPoint());
								}
								startActivityForResult(intent, _ReqCreatePattern);
					            break;

					        case DialogInterface.BUTTON_NEGATIVE:
					            //No button clicked
					            break;
					        }
					    }
					};
					AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
					builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
				    .setNegativeButton("No", dialogClickListener).show();
				} else {
					Intent intent = new Intent(LockPatternActivity._ActionCreatePattern, null, 
							MenuActivity.this, LockPatternActivity.class);
					intent.putExtra(LockPatternActivity._NumTraining, mNumTraining);
					intent.putExtra(LockPatternActivity._BgColor, btnColorCreate);
					
					intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
					intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
					intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
					intent.putExtra(LockPatternActivity._TipSize, _tipSize);

					if (_userProfile != null) {
						intent.putExtra(LockPatternActivity._ID, _userProfile.getName());
						intent.putExtra(LockPatternActivity._TotalScore, _userProfile.getTotalPoint());
						intent.putExtra(LockPatternActivity._AttackScore, _userProfile.getAttackPoint());
						intent.putExtra(LockPatternActivity._DefenseScore, _userProfile.getDefensePoint());
						intent.putExtra(LockPatternActivity._UsabilityScore, _userProfile.getUsabilityPoint());
					}
					
					startActivityForResult(intent, _ReqCreatePattern);
				}
			}
		});
		create_button.setActivated(false);
		create_button.setBackgroundColor(btnColorInactive);
		create_button.setTextColor(txtColorInactive);
		
		review_line_button = (Button) findViewById(R.id.review_line_button);
		//review_line_button.setBackgroundColor(btnColorReviewLine);
		review_line_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				if (review_line_button_enabled == false) {
					return;
				}
				if(_createdTruePattern == null || _createdTruePattern.isEmpty()){
					waitToast = Toast.makeText(MenuActivity.this, 
							"Please Create Your Lock Pattern First!", Toast.LENGTH_SHORT);
					waitToast.show();
				} else if (_createdTouchSignals == null || _createdGridSignals == null ||
						_createdGridSignal == null) {
					waitToast = Toast.makeText(MenuActivity.this,
							"Please Wait Few Seconds To Get Your Patterns.", Toast.LENGTH_SHORT);
					waitToast.show();
				} else {
					Intent intent = new Intent(LockPatternActivity._ActionReviewLinePattern, null, 
							MenuActivity.this, LockPatternActivity.class);
					intent.putExtra(LockPatternActivity._MaxRetry, 1000);
					intent.putExtra(LockPatternActivity._NumTraining, mNumTraining);
					intent.putExtra(LockPatternActivity._BgColor, btnColorReviewLine);
					
					intent.putExtra(LockPatternActivity._RawTrajectories, _createdTouchSignals);
					intent.putExtra(LockPatternActivity._QuantizedTrajectory, _createdGridSignal);
					intent.putExtra(LockPatternActivity._QuantizedTrajectories, _createdGridSignals);
					
					intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
					intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
					intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
					intent.putExtra(LockPatternActivity._TipSize, _tipSize);
					
					if (_userProfile != null) {
						intent.putExtra(LockPatternActivity._ID, _userProfile.getName());
						intent.putExtra(LockPatternActivity._TotalScore, _userProfile.getTotalPoint());
						intent.putExtra(LockPatternActivity._AttackScore, _userProfile.getAttackPoint());
						intent.putExtra(LockPatternActivity._DefenseScore, _userProfile.getDefensePoint());
						intent.putExtra(LockPatternActivity._UsabilityScore, _userProfile.getUsabilityPoint());
					}
					startActivityForResult(intent, _ReqUnlockPattern);
				}
			}
		});
		review_line_button.setActivated(false);
		review_line_button.setBackgroundColor(btnColorInactive);
		review_line_button.setTextColor(txtColorInactive);
		
		review_grid_button = (Button) findViewById(R.id.review_grid_button);
		//review_grid_button.setBackgroundColor(btnColorReviewGrid);
		review_grid_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				if (review_grid_button_enabled == false) {
					return;
				}
				if(_createdTruePattern == null || _createdTruePattern.isEmpty()){
					waitToast = Toast.makeText(MenuActivity.this, 
							"Please Create Your Lock Pattern First!", Toast.LENGTH_SHORT);
					waitToast.show();
				} else if (_createdTouchSignals == null || _createdGridSignals == null ||
						_createdGridSignal == null) {
					waitToast = Toast.makeText(MenuActivity.this,
							"Please Wait Few Seconds To Get Your Patterns.", Toast.LENGTH_SHORT);
					waitToast.show();
				} else {
					Intent intent = new Intent(LockPatternActivity._ActionReviewGridPattern, null, 
							MenuActivity.this, LockPatternActivity.class);
					intent.putExtra(LockPatternActivity._MaxRetry, 1000);
					intent.putExtra(LockPatternActivity._NumTraining, mNumTraining);
					intent.putExtra(LockPatternActivity._BgColor, btnColorReviewGrid);

					intent.putExtra(LockPatternActivity._RawTrajectories, _createdTouchSignals);
					intent.putExtra(LockPatternActivity._QuantizedTrajectory, _createdGridSignal);
					intent.putExtra(LockPatternActivity._QuantizedTrajectories, _createdGridSignals);
					
					intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
					intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
					intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
					intent.putExtra(LockPatternActivity._TipSize, _tipSize);
					
					if (_userProfile != null) {
						intent.putExtra(LockPatternActivity._ID, _userProfile.getName());
						intent.putExtra(LockPatternActivity._TotalScore, _userProfile.getTotalPoint());
						intent.putExtra(LockPatternActivity._AttackScore, _userProfile.getAttackPoint());
						intent.putExtra(LockPatternActivity._DefenseScore, _userProfile.getDefensePoint());
						intent.putExtra(LockPatternActivity._UsabilityScore, _userProfile.getUsabilityPoint());
					}
					
					startActivityForResult(intent, _ReqUnlockPattern);
				}
			}
		});
		review_grid_button.setActivated(false);
		review_grid_button.setBackgroundColor(btnColorInactive);
		review_grid_button.setTextColor(txtColorInactive);
		
		unlock_button = (Button) findViewById(R.id.unlock_button);
		//unlock_button.setBackgroundColor(btnColorUnlock);
		unlock_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				if (unlock_button_enabled == false) {
					return;
				}
				if(_createdTruePattern == null || _createdTruePattern.isEmpty()){
					waitToast = Toast.makeText(MenuActivity.this, 
							"Please Create Your Lock Pattern First!", Toast.LENGTH_SHORT);
					waitToast.show();
				} else if (_createdTouchSignals == null || _createdGridSignals == null ||
						_createdGridSignal == null) {
					waitToast = Toast.makeText(MenuActivity.this,
							"Please Wait Few Seconds To Get Your Patterns.", Toast.LENGTH_SHORT);
					waitToast.show();
				} else {
					Intent intent = new Intent(LockPatternActivity._ActionComparePattern, null, 
							MenuActivity.this, LockPatternActivity.class);
					intent.putExtra(LockPatternActivity._MaxRetry, 1000);
					intent.putExtra(LockPatternActivity._NumTraining, mNumTraining);
					intent.putExtra(LockPatternActivity._BgColor, btnColorUnlock);

					intent.putExtra(LockPatternActivity._TruePattern, _createdTruePattern);
					intent.putExtra(LockPatternActivity._RawTrajectories, _createdTouchSignals);
					intent.putExtra(LockPatternActivity._QuantizedTrajectory, _createdGridSignal);
					intent.putExtra(LockPatternActivity._QuantizedTrajectories, _createdGridSignals);
					
					intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
					intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
					intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
					intent.putExtra(LockPatternActivity._TipSize, _tipSize);
					
					if (_userProfile != null) {
						intent.putExtra(LockPatternActivity._ID, _userProfile.getName());
						intent.putExtra(LockPatternActivity._TotalScore, _userProfile.getTotalPoint());
						intent.putExtra(LockPatternActivity._AttackScore, _userProfile.getAttackPoint());
						intent.putExtra(LockPatternActivity._DefenseScore, _userProfile.getDefensePoint());
						intent.putExtra(LockPatternActivity._UsabilityScore, _userProfile.getUsabilityPoint());
					}

					startActivityForResult(intent, _ReqUnlockPattern);
				}
			}
		});
		unlock_button.setActivated(false);
		unlock_button.setBackgroundColor(btnColorInactive);
		unlock_button.setTextColor(txtColorInactive);
		
		battle_button = (Button) findViewById(R.id.battle_button);
		//battle_button.setBackgroundColor(btnColorBattle);
		battle_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				if (battle_button_enabled == false) {
					return;
				}
				Intent intent = new Intent(MenuActivity.this, BattleMenuActivity.class);
				if (_userProfile != null) {
					intent.putExtra(BattleMenuActivity._UserProfile, _userProfile.toStringSimple());
				}
				if (_numUsers != 0) {
					intent.putExtra(BattleMenuActivity._NumUsers, Integer.valueOf(_numUsers));
				}
				if (_upList != null) {
					String str = "";
					Iterator<UserProfile> it = _upList.iterator();
					while (it.hasNext()) {
						str += it.next().toStringSimple() + " ";
					}
					intent.putExtra(BattleMenuActivity._UserProfileList, str);
				}
				if (_bhList != null) {
					String str = "";
					Iterator<BattleHistory> it = _bhList.iterator();
					while (it.hasNext()) {
						str += it.next().toStringSimple() + " ";
					}
					intent.putExtra(BattleMenuActivity._BattHistoryList, str);
				}
				startActivityForResult(intent, _ReqBattleWorld);
			}
		});
		battle_button.setActivated(false);
		battle_button.setBackgroundColor(btnColorInactive);
		battle_button.setTextColor(txtColorInactive);
		
		recali_button = (Button) findViewById(R.id.recali_button);
		recali_button.setBackgroundColor(btnColorRecali);
		recali_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				Intent intent = new Intent(MenuActivity.this, CalibrationBaseActivity.class);
				intent.putExtra(CalibrationBaseActivity._FromMenu, true);
				startActivityForResult(intent, _ReqRecalibration);
			}
		});
		
		rankin_button = (Button) findViewById(R.id.rankin_button);
		//rankin_button.setBackgroundColor(btnColorRankin);
		rankin_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (waitToast != null) {
					waitToast.cancel();
				}
				if (rankin_button_enabled == false) {
					return;
				}
				Intent intent = new Intent(MenuActivity.this, RankActivity.class);
				if (_upList != null) {
					String str = "";
					Iterator<UserProfile> it = _upList.iterator();
					while (it.hasNext()) {
						str += it.next().toStringSimple() + " ";
					}
					intent.putExtra(RankActivity._UserProfileList, str);
				}
				if (_userProfile != null) {
					intent.putExtra(RankActivity._UserProfile, _userProfile.toStringSimple());
				}
				startActivity(intent);
			}
		});
		rankin_button.setActivated(false);
		rankin_button.setBackgroundColor(btnColorInactive);
		rankin_button.setTextColor(txtColorInactive);
		
		mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
		_nickname = mPrefs.getString(LoginActivity._Nickname, null);
		_device_id = mPrefs.getString(LoginActivity._DeviceID, null);

		_userProfile = null;
    	str = getIntent().getStringExtra(_UserProfile);
		if (str != null && str.isEmpty() == false) {
        	_userProfile = new UserProfile();
        	_userProfile.setFromStringSimple(str);
        	activateButtons();
		} else {
			// we then lookup user profile from SharedPreferences and the DB
			AsyncUserProfileLookupTask upLookupTask = new AsyncUserProfileLookupTask();
			upLookupTask.delegate = this;
			upLookupTask.execute(_nickname);
		}
		
		/*// CellPatternLookup needs to be 'synchronized'
		CellPattern cPattern = dbHelper.lookupCellPattern(_nickname);
		if (cPattern == null) {
			_createdTruePattern = null;
			Log.d("Touch01", "There is no cell pattern.");
		} else {
			_createdTruePattern = cPattern.getPattern();
		}*/
		_createdTruePattern = null;
		AsyncCellPatternLookupTask cellPatternLookupTask = new AsyncCellPatternLookupTask();
		cellPatternLookupTask.delegate = this;
		cellPatternLookupTask.execute(_nickname);
		
		_numUsers = 0;
		AsyncCountUserTask countUserTask = new AsyncCountUserTask();
		countUserTask.delegate = this;
		countUserTask.execute();

		_createdTouchSignals = null;
		AsyncRawTrajPatternLookupTask rawPatternLookupTask = new AsyncRawTrajPatternLookupTask();
		rawPatternLookupTask.delegate = this;
		rawPatternLookupTask.execute(_nickname);
		
		_createdGridSignals = null;
		AsyncQuanTrajPatternLookupTask quanPatternLookupTask = new AsyncQuanTrajPatternLookupTask();
		quanPatternLookupTask.delegate = this;
		quanPatternLookupTask.execute(_nickname);
		
		_createdGridSignal = null;
		AsyncAggTrajPatternLookupTask aggPatternLookupTask = new AsyncAggTrajPatternLookupTask();
		aggPatternLookupTask.delegate = this;
		aggPatternLookupTask.execute(_nickname);
		
		_upList = null;
		AsyncUserProfileListLookupTask upListLookupTask = new AsyncUserProfileListLookupTask();
		upListLookupTask.delegate = this;
		upListLookupTask.execute(0, 100);
		
		_bhList = null;
		AsyncBattleHistoryListLookupTask bhListLookupTask = new AsyncBattleHistoryListLookupTask();
		bhListLookupTask.delegate = this;
		bhListLookupTask.execute(_nickname);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	        Intent data) {
		Toast toast;
        AsyncBattleHistoryListLookupTask bhListLookupTask;
        AsyncUserProfileListLookupTask upListLookupTask;
        AsyncUserProfileLookupTask upLookupTask;
        
	    switch (requestCode) {
	    case _ReqCreatePattern:
	        if (resultCode == RESULT_OK) {
	            //_createdPattern = data.getStringExtra(LockPatternActivity._Pattern);
	            _createdTruePattern = data.getStringExtra(LockPatternActivity._TruePattern);
	            //_createdTouchSignal = data.getStringExtra(LockPatternActivity._RawTrajectory);
	            _createdTouchSignals = data.getStringExtra(LockPatternActivity._RawTrajectories);
	            _createdGridSignal = data.getStringExtra(LockPatternActivity._QuantizedTrajectory);
	            _createdGridSignals = data.getStringExtra(LockPatternActivity._QuantizedTrajectories);

	            //Log.d("Touch01", "Created Pattern= " + _createdPattern);
	            //Log.d("Touch01", "Created TouchSignal= " + _createdTouchSignal);
	            //Log.d("Touch01", "Created TouchSignals= " + _createdTouchSignals);
	            
	            // here we need to store the patterns on the DB
	            //dbHelper.deleteCellPattern(_nickname, _device_id);
	            dbHelper.deleteTrajPattern(_nickname, _device_id);

	            StringTokenizer tsToken;
	            CellPattern cPattern = new CellPattern(_nickname, _createdTruePattern);
	            dbHelper.createCellPattern(cPattern, _device_id, false);
	            
	        	tsToken = new StringTokenizer(_createdTouchSignals, " ");
	        	TrajPattern tPattern;
	        	while (tsToken.hasMoreElements()) {
	        		tPattern = new TrajPattern(_nickname, (String) tsToken.nextElement(), TrajPattern._RAW);
	        		dbHelper.createTrajPattern(tPattern, _device_id, false);
	        	}
	        	tsToken = new StringTokenizer(_createdGridSignals, " ");
	        	while (tsToken.hasMoreElements()) {
	        		tPattern = new TrajPattern(_nickname, (String) tsToken.nextElement(), TrajPattern._QUANTIZED);
	        		dbHelper.createTrajPattern(tPattern, _device_id, false);
	        	}
        		tPattern = new TrajPattern(_nickname, _createdGridSignal, TrajPattern._AGGREGATED);
        		dbHelper.createTrajPattern(tPattern, _device_id, false);
        		
        		// RESET or make half of the score of the current user profile
        		int aPoint = _userProfile.getAttackPoint();
        		int dPoint = _userProfile.getDefensePoint();
        		int uPoint = _userProfile.getUsabilityPoint();
        		int tPoint = _userProfile.getTotalPoint();
        		int tPointBackup = tPoint;
        		
        		if (aPoint >= 1000) {
        			aPoint /= 2;
        		} else if (aPoint > 500) {
        			aPoint = 500;
        		}
        		if (dPoint >= 1000) {
        			dPoint /= 2;
        		} else if (dPoint > 500) {
        			dPoint = 500;
        		}
        		if (uPoint >= 1000) {
        			uPoint /= 2;
        		} else if (uPoint > 500) {
        			uPoint = 500;
        		}
        		tPoint = aPoint + dPoint + uPoint;
        		_userProfile.setAttackPoint(aPoint);
        		_userProfile.setDefensePoint(dPoint);
        		_userProfile.setUsabilityPoint(uPoint);
        		_userProfile.setTotalPoint(tPoint);
        		dbHelper.updateUser(_userProfile, _device_id);
        		
        		BattleHistory history;
        		history = new BattleHistory(0, 
        				(int) (System.currentTimeMillis() / 1000),
        				_nickname,
        				"(null)",
        				tPoint,
        				0,
        				tPoint - tPointBackup,
        				BattleHistory._RESET);
        		//_bhList.add(history);
        		dbHelper.createBattHistory(history, _device_id, false);

        		if (_bhList != null) {
	        		_bhList.clear();
	        		_bhList = null;
        		}
        		if (_upList != null) {
            		_upList.clear();
            		_upList = null;
        		}
        		_userProfile = null;
        		activateButtons();
    			upLookupTask = new AsyncUserProfileLookupTask();
    			upLookupTask.delegate = this;
    			upLookupTask.execute(_nickname);
        		bhListLookupTask = new AsyncBattleHistoryListLookupTask();
        		bhListLookupTask.delegate = this;
        		bhListLookupTask.execute(_nickname);
        		upListLookupTask = new AsyncUserProfileListLookupTask();
        		upListLookupTask.delegate = this;
        		upListLookupTask.execute(0, 100);
	        }
	        break;
	    case _ReqUnlockPattern:
	        /*
	         * NOTE that there are 3 possible result codes!!!
	         */
	        int retryCount = data.getIntExtra(LockPatternActivity._ExtraRetryCount, 0);
	        int aPoint;
	        int dPoint;
	        int uPoint;
	        int tPoint;
	        int rPoint;
	        BattleHistory history;
    		
	        switch (resultCode) {
	        case RESULT_OK:
	            // The user passed
	        	
	        	// get the updated Touch and Grid signals
	            //_createdTouchSignal = data.getStringExtra(LockPatternActivity._RawTrajectory);
	            String rawPatterns = data.getStringExtra(LockPatternActivity._RawTrajectories);
	            String quantizedPatterns = data.getStringExtra(LockPatternActivity._QuantizedTrajectories);
	            String aggregatedPattern = data.getStringExtra(LockPatternActivity._QuantizedTrajectory);
	            // NOTE: replacedPatternIndex represents an index of a pattern to be substituted. 
	            int replacedPatternIndex = data.getIntExtra(LockPatternActivity._ReplacedPatternIndex, -1);

	            Log.d("Touch01", "Unlocked Pattern!");
				toast = Toast.makeText(MenuActivity.this, 
						"Unlocked Pattern!", Toast.LENGTH_SHORT);
				toast.show();

				if (replacedPatternIndex == -1 || 
	            		rawPatterns == null || 
	            		quantizedPatterns == null || 
	            		aggregatedPattern == null) {
	            	Log.d("Touch01", "No pattern update at this time.");
	            } else {
					
		            // here we need to store the patterns on the DB
		            //dbHelper.deleteTrajPattern(_nickname);

					//Log.d("Touch01", "RawPatterns:");
					//Log.d("Touch01", rawPatterns);
		            StringTokenizer tsToken;
		        	tsToken = new StringTokenizer(rawPatterns, " ");
		        	String tPatternNew = null;
		        	int i = 0;
		        	while (tsToken.hasMoreElements()) {
		        		if (i == replacedPatternIndex) {
		        			tPatternNew = (String) tsToken.nextElement();
		        			break;
		        		} else {
			        		tsToken.nextElement();
			        		i++;
		        		}
		        	}
		        	
					//Log.d("Touch01", "_createdTouchSignals:");
					//Log.d("Touch01", _createdTouchSignals);

		        	tsToken = new StringTokenizer(_createdTouchSignals, " ");
		        	String tPatternOld = null;
		        	i = 0;
		        	while (tsToken.hasMoreElements()) {
		        		if (i == replacedPatternIndex) {
		        			tPatternOld = (String) tsToken.nextElement();
		        			break;
		        		} else {
			        		tsToken.nextElement();
			        		i++;
		        		}
		        	}
	    			dbHelper.updateTrajPattern(_nickname, tPatternOld, tPatternNew, TrajPattern._RAW, _device_id);
	    			_createdTouchSignals = rawPatterns;
		        	
	    			
					//Log.d("Touch01", "quantizedPatterns:");
					//Log.d("Touch01", quantizedPatterns);
					
		        	tsToken = new StringTokenizer(quantizedPatterns, " ");
		        	tPatternNew = null;
		        	i = 0;
		        	while (tsToken.hasMoreElements()) {
		        		if (i == replacedPatternIndex) {
		        			tPatternNew = (String) tsToken.nextElement();
		        			break;
		        		} else {
			        		tsToken.nextElement();
			        		i++;
		        		}
		        	}
		        	
					//Log.d("Touch01", "_createdGridSignals:");
					//Log.d("Touch01", _createdGridSignals);
		        	tsToken = new StringTokenizer(_createdGridSignals, " ");
		        	tPatternOld = null;
		        	i = 0;
		        	while (tsToken.hasMoreElements()) {
		        		if (i == replacedPatternIndex) {
		        			tPatternOld = (String) tsToken.nextElement();
		        			break;
		        		} else {
			        		tsToken.nextElement();
			        		i++;
		        		}
		        	}
	    			dbHelper.updateTrajPattern(_nickname, tPatternOld, tPatternNew, TrajPattern._QUANTIZED, _device_id);
	    			_createdGridSignals = quantizedPatterns;
		        	
		        	dbHelper.updateTrajPattern(_nickname, _createdGridSignal, aggregatedPattern, TrajPattern._AGGREGATED, _device_id);
		        	_createdGridSignal = aggregatedPattern;
	            }
	        	
		        for (int i=0; i< retryCount; ++i) {
		        	// PROFILE UPDATE (FAILED UNLOCKS)
	        		aPoint = _userProfile.getAttackPoint();
	        		dPoint = _userProfile.getDefensePoint();
	        		uPoint = _userProfile.getUsabilityPoint();
	        		tPoint = _userProfile.getTotalPoint();
	        		rPoint = selfEloCalculation(aPoint, dPoint, false);
		        	uPoint += rPoint;
		        	tPoint += rPoint;
	        		_userProfile.setUsabilityPoint(uPoint);
	        		_userProfile.setTotalPoint(tPoint);
	        		_userProfile.incFalseFailureSelf();
	        		_userProfile.incTrialSelf();
	        		
	        		history = new BattleHistory(0, 
	        				(int) (System.currentTimeMillis() / 1000) - retryCount + i,
	        				_nickname,
	        				"(null)",
	        				tPoint,
	        				0,
	        				rPoint,
	        				BattleHistory._FAIL);
	        		//_bhList.add(history);
	        		dbHelper.createBattHistory(history, _device_id, false);
		        }
	        	
        		// PROFILE UPDATE (SUCCESSFUL UNLOCK) 
        		aPoint = _userProfile.getAttackPoint();
        		dPoint = _userProfile.getDefensePoint();
        		uPoint = _userProfile.getUsabilityPoint();
        		tPoint = _userProfile.getTotalPoint();
        		
        		rPoint = selfEloCalculation(aPoint, dPoint, true);
        		uPoint += rPoint;
        		tPoint += rPoint;
        		//_userProfile.setUsabilityPoint(uPoint);
        		//_userProfile.setTotalPoint(tPoint);
        		//_userProfile.incTrueSuccessSelf();
        		//_userProfile.incTrialSelf();
        		//dbHelper.updateUser(_userProfile, _device_id);
        		
        		history = new BattleHistory(0, 
        				(int) (System.currentTimeMillis() / 1000),
        				_nickname,
        				"(null)",
        				tPoint,
        				0,
        				rPoint,
        				BattleHistory._SUCCESS);
        		//_bhList.add(history);
        		dbHelper.createBattHistory(history, _device_id, false);
        		
        		if (_bhList != null) {
        			_bhList.clear();
        			_bhList = null;
        		}
        		if (_upList != null) {
	        		_upList.clear();
	        		_upList = null;
        		}
        		_userProfile = null;
        		activateButtons();
    			upLookupTask = new AsyncUserProfileLookupTask();
    			upLookupTask.delegate = this;
    			upLookupTask.execute(_nickname);
        		bhListLookupTask = new AsyncBattleHistoryListLookupTask();
        		bhListLookupTask.delegate = this;
        		bhListLookupTask.execute(_nickname);
        		upListLookupTask = new AsyncUserProfileListLookupTask();
        		upListLookupTask.delegate = this;
        		upListLookupTask.execute(0, 100);
	            break;
	        case RESULT_CANCELED:
	        case LockPatternActivity._ResultFailed:
	            // The user cancelled the task, or, 
	            // The user failed to enter the pattern
		        
		        for (int i=0; i< retryCount; ++i) {
		        	// PROFILE UPDATE (FAILED UNLOCKS)
	        		aPoint = _userProfile.getAttackPoint();
	        		dPoint = _userProfile.getDefensePoint();
	        		uPoint = _userProfile.getUsabilityPoint();
	        		tPoint = _userProfile.getTotalPoint();
	        		rPoint = selfEloCalculation(aPoint, dPoint, false);
		        	uPoint += rPoint;
		        	tPoint += rPoint;
	        		_userProfile.setUsabilityPoint(uPoint);
	        		_userProfile.setTotalPoint(tPoint);
	        		_userProfile.incFalseFailureSelf();
	        		_userProfile.incTrialSelf();
	        		
	        		history = new BattleHistory(0, 
	        				(int) (System.currentTimeMillis() / 1000) - retryCount + i,
	        				_nickname,
	        				"(null)",
	        				tPoint,
	        				0,
	        				rPoint,
	        				BattleHistory._FAIL);
	        		//_bhList.add(history);
	        		dbHelper.createBattHistory(history, _device_id, false);
		        }
		        if (retryCount > 0) {
	        		//dbHelper.updateUser(_userProfile, _device_id);

		        	if (_bhList != null) {
		        		_bhList.clear();
		        		_bhList = null;
		        	}
		        	if (_upList != null) {
		        		_upList.clear();
		        		_upList = null;
		        	}
	        		_userProfile = null;
	        		activateButtons();
	    			upLookupTask = new AsyncUserProfileLookupTask();
	    			upLookupTask.delegate = this;
	    			upLookupTask.execute(_nickname);
	        		bhListLookupTask = new AsyncBattleHistoryListLookupTask();
	        		bhListLookupTask.delegate = this;
	        		bhListLookupTask.execute(_nickname);
	        		upListLookupTask = new AsyncUserProfileListLookupTask();
	        		upListLookupTask.delegate = this;
	        		upListLookupTask.execute(0, 100);
		        }
	            break;
	        }

	        /*
	         * In any case, there's always a key _ExtraRetryCount, which holds
	         * the number of tries that the user did.
	         */
	        Log.d("Touch01", "RETRY COUNT: " + retryCount);
	        break;
	    case _ReqRecalibration:
			mPrefs = getSharedPreferences(CalibrationBaseActivity.class.getName(), 0);
			_thumbPres = mPrefs.getInt(CalibrationBaseActivity._Pressure, 90);
			_thumbSize = mPrefs.getInt(CalibrationBaseActivity._Size, 90);
			
			mPrefs = getSharedPreferences(CalibrationTipActivity.class.getName(), 0);
			_tipPres = mPrefs.getInt(CalibrationTipActivity._Pressure, 90);
			_tipSize = mPrefs.getInt(CalibrationTipActivity._Size, 90);
			
			String str = "Thumb (p, s)= (" + _thumbPres + ", " + _thumbSize + "),  Tip (p, s)= (" + _tipPres + ", " + _tipSize + ")";
			Log.d("Touch01", str);
	        break;
	    case _ReqBattleWorld:
	    	if (_bhList != null) {
	    		_bhList.clear();
	    		_bhList = null;
	    	}
	    	if (_upList != null) {
	    		_upList.clear();
	    		_upList = null;
	    	}
    		_userProfile = null;
    		activateButtons();
			upLookupTask = new AsyncUserProfileLookupTask();
			upLookupTask.delegate = this;
			upLookupTask.execute(_nickname);
    		bhListLookupTask = new AsyncBattleHistoryListLookupTask();
    		bhListLookupTask.delegate = this;
    		bhListLookupTask.execute(_nickname);
    		upListLookupTask = new AsyncUserProfileListLookupTask();
    		upListLookupTask.delegate = this;
    		upListLookupTask.execute(0, 100);
	    }
	}
	
	@Override
	public void onBackPressed(){
		if (waitToast != null) {
			waitToast.cancel();
		}
		if (Math.abs(_timeBackKey - System.currentTimeMillis()) > 3000) {
			_quitToast = Toast.makeText(this, "To quit, touch back again", Toast.LENGTH_SHORT);
			_quitToast.show();
			_timeBackKey = System.currentTimeMillis();
		} else {
		    if (dbHelper != null) {
		    	dbHelper.clearWritableDatabase();
		        dbHelper.close();
		        dbHelper = null;
		    }
		    if (db != null) {
		        db.close();
		        db = null;
		    }
			_quitToast.cancel();
			super.onBackPressed();
		}
	}

	private void activateButtons(){
		create_button_enabled = false;
		review_line_button_enabled = false;
		review_grid_button_enabled = false;
		unlock_button_enabled = false;
		rankin_button_enabled = false;
		battle_button_enabled = false;
		
		if (_numUsers > 0) {
			if (_userProfile != null) {
				if (_createdTruePattern != null) {
					create_button_enabled = true;
					if (_createdTruePattern.isEmpty()) {
						create_button.setText(R.string.create_button);
					} else {
						create_button.setText(R.string.change_button);
					}
					if (_createdTruePattern.isEmpty() == false
						&& _createdTouchSignals != null
						&& _createdGridSignals != null
						&& _createdGridSignal != null) {
						review_line_button_enabled = true;
						review_grid_button_enabled = true;
						unlock_button_enabled = true;
						if (_upList != null) {
							rankin_button_enabled = true;
							if (_bhList != null) {
								battle_button_enabled = true;
							}
						}
					}
				}
			}
		}
		
		if (create_button_enabled == true) {
			create_button.setActivated(true);
			create_button.setBackgroundColor(btnColorCreate);
			create_button.setTextColor(txtColorActive);
		} else {
			create_button.setActivated(false);
			create_button.setBackgroundColor(btnColorInactive);
			create_button.setTextColor(txtColorInactive);
		}
		if (review_line_button_enabled == true) {
			review_line_button.setActivated(true);
			review_line_button.setBackgroundColor(btnColorReviewLine);
			review_line_button.setTextColor(txtColorActive);
		} else {
			review_line_button.setActivated(false);
			review_line_button.setBackgroundColor(btnColorInactive);
			review_line_button.setTextColor(txtColorInactive);
		}
		if (review_grid_button_enabled == true) {
			review_grid_button.setActivated(true);
			review_grid_button.setBackgroundColor(btnColorReviewGrid);
			review_grid_button.setTextColor(txtColorActive);
		} else {
			review_grid_button.setActivated(false);
			review_grid_button.setBackgroundColor(btnColorInactive);
			review_grid_button.setTextColor(txtColorInactive);
		}
		if (unlock_button_enabled == true) {
			unlock_button.setActivated(true);
			unlock_button.setBackgroundColor(btnColorUnlock);
			unlock_button.setTextColor(txtColorActive);
		} else {
			unlock_button.setActivated(false);
			unlock_button.setBackgroundColor(btnColorInactive);
			unlock_button.setTextColor(txtColorInactive);
		}
		if (rankin_button_enabled == true) {
			rankin_button.setActivated(true);
			rankin_button.setBackgroundColor(btnColorRankin);
			rankin_button.setTextColor(txtColorActive);
		} else {
			rankin_button.setActivated(false);
			rankin_button.setBackgroundColor(btnColorInactive);
			rankin_button.setTextColor(txtColorInactive);
		}
		if (battle_button_enabled == true) {
			battle_button.setActivated(true);
			battle_button.setBackgroundColor(btnColorBattle);
			battle_button.setTextColor(txtColorActive);
		} else {
			battle_button.setActivated(false);
			battle_button.setBackgroundColor(btnColorInactive);
			battle_button.setTextColor(txtColorInactive);
		}
	}
	
	@Override
	public void processCountUserFinish(Integer output) {
		if (output == 0) {
			this._numUsers = 1;
		} else {
			this._numUsers = output;
		}
		activateButtons();
		Log.d("Touch01", "AsyncCountUserTask is finished.");
	}

	@Override
	public void processUserProfileFinish(UserProfile output) {
		if (output == null) {
			this._userProfile = null;
		} else {
			this._userProfile = output;
		}
		activateButtons();
		Log.d("Touch01", "AsyncUserProfileLookupTask is finished.");
	}

	@Override
	public void processUserProfileListFinish(List<UserProfile> output) {
		if (output == null) {
			this._upList = new ArrayList<UserProfile>();
		} else {
			this._upList = output;
		}
		activateButtons();
		Log.d("Touch01", "AsyncUserProfileListLookupTask is finished.");
	}

	@Override
	public void processBattleHistoryListFinish(List<BattleHistory> output) {
		if (output == null) {
			this._bhList = new ArrayList<BattleHistory>();
		} else {
			this._bhList = output;
		}
		activateButtons();
		Log.d("Touch01", "AsyncBattleHistoryListLookupTask is finished.");
	}
	
	@Override
	public void processCellPatternFinish(CellPattern output) {
		if (output == null) {
			this._createdTruePattern = "";
		} else {
			this._createdTruePattern = output.getPattern();
		}
		activateButtons();
		Log.d("Touch01", "AsyncCellPatternLookupTask is finished.");
	}
	
	
	@Override
	public void processRawTrajPatternFinish(List<TrajPattern> output) {
		if (output == null) {
			this._createdTouchSignals = null;
		} else {
			Iterator<TrajPattern> it = output.iterator();
			_createdTouchSignals = "";
			while (it.hasNext()) {
				_createdTouchSignals += it.next().getPattern() + " ";
			}
		}
		activateButtons();
		Log.d("Touch01", "AsyncRawTrajPatternLookupTask is finished.");
	}
	
	@Override
	public void processQuanTrajPatternFinish(List<TrajPattern> output) {
		if (output == null) {
			this._createdGridSignals = null;
		} else {
			Iterator<TrajPattern> it = output.iterator();
			_createdGridSignals = "";
			while (it.hasNext()) {
				_createdGridSignals += it.next().getPattern() + " ";
			}
		}
		activateButtons();
		Log.d("Touch01", "AsyncQuanTrajPatternLookupTask is finished.");
	}
	
	@Override
	public void processAggTrajPatternFinish(TrajPattern output) {
		if (output == null) {
			this._createdGridSignal = null;
		} else {
			this._createdGridSignal = output.getPattern();
		}
		activateButtons();
		Log.d("Touch01", "AsyncAggTrajPatternLookupTask is finished.");
	}
	
	private int selfEloCalculation(int aPoint, int dPoint, Boolean won) {
		float e = (float) (1.0f / ( 1.0f + Math.pow(10, (double)(dPoint - aPoint)/400)));
		int elo = (int)(20.0f * ((won ? 1.0f : 0.0f) - e));
		return elo;
	}
}
