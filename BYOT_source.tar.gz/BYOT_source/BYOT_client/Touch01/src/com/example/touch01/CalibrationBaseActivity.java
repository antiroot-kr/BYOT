package com.example.touch01;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewGroup.LayoutParams;
import android.widget.Toast;

@SuppressLint("NewApi")
public class CalibrationBaseActivity extends Activity {    
    private SharedPreferences mPrefs;
    private static final String _ClassName = CalibrationBaseActivity.class.getName();
	public static final String _Calibration = _ClassName + ".calibration";
	public static final String _FromMenu = _ClassName + ".from_menu";
	public static final String _Pressure = _ClassName + ".pressure";
	public static final String _Size = _ClassName + ".size";
	public static final String _UserProfile = _ClassName + ".user_profile";

	private static final long duration = 2000; // 2 seconds to get signal 

	//private ImageView imgView;
	private CalibrationView view;
	private Boolean fromMenu;
	private int presBase;
	private int sizeBase;
	ArrayList<Integer> presList;
	ArrayList<Integer> sizeList;
	
	private Toast toast;
	int inTouchProgress;
	
	private boolean disableRunnables = false;
	private Handler inTouchProgressHandler;
	private Runnable inTouchProgressRun;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        fromMenu = getIntent().getBooleanExtra(_FromMenu, false);
		
		setContentView(R.layout.calibration_base);
		mPrefs = getSharedPreferences(CalibrationBaseActivity.class.getName(), 0);
		
		presList = new ArrayList<Integer>();
		sizeList = new ArrayList<Integer>();
		
		view = (CalibrationView) findViewById (R.id.calibration_view);
		view.setBitmapID(R.drawable.thumb_base_768_868);

		LayoutParams params = view.getLayoutParams();
		
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
		
		params.width = width;
		params.height = width * 868 / 768;
		view.setLayoutParams(params);
		
        this.inTouchProgressHandler = new Handler();
        inTouchProgressRun = new Runnable(){
        	@Override
        	public void run(){
        		if (disableRunnables) {
        			return;
        		}
        		Log.d("Touch01", "Periodic task: inTouchProgress");
        		if (inTouchProgress != -1 && inTouchProgress < 13) {
        			// TODO: invalidate and draw here!
        			inTouchProgress++;
		        	view.setInTouchProgress(inTouchProgress);
        			view.invalidate();
        			inTouchProgressHandler.postDelayed(this, duration/13);
        		}
        	}
        };
		
		view.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				float p;
				float s;
				int temp;
		        switch (event.getAction()) {
		        case MotionEvent.ACTION_DOWN:
		        	presList.clear();
		        	sizeList.clear();
		            p = event.getPressure(0);
		            s = event.getSize(0);
		            presList.add((int)(p*100));
		            sizeList.add((int)(s*100));
		            Log.d("Touch01", "p= " + (int)(p*100) + ", s=" + (int)(s*100));
		            
		    		if (toast != null) {
		    			toast.cancel();
		    		}

		            inTouchProgress = 0;
		            view.setInTouchProgress(inTouchProgress);
		            view.invalidate();
		            inTouchProgressHandler.postDelayed(inTouchProgressRun, duration/13);
		            return true;
		        case MotionEvent.ACTION_UP:
		        	if (inTouchProgress == 13) {
			        	inTouchProgress = -1;
			        	disableRunnables = true;
			    		if (toast != null) {
			    			toast.cancel();
			    		}
		        	} else {
			        	inTouchProgress = -1;
			        	view.setInTouchProgress(inTouchProgress);
			        	view.invalidate();
						toast = Toast.makeText(getBaseContext(), "Please try at least 2 seconds!", Toast.LENGTH_SHORT);
						toast.show();
						inTouchProgressHandler.removeCallbacks(inTouchProgressRun);
		        		return true;
		        	}

		        	for (int i=temp=0; i<presList.size(); ++i) {
		        		if (presList.get(i) > temp) {
		        			temp = presList.get(i);
		        		}
		        	}
		        	presBase = temp * 2 / 3;
		        	
		        	for (int i=temp=0; i<sizeList.size(); ++i) {
		        		if (sizeList.get(i) > temp) {
		        			temp = sizeList.get(i);
		        		}
		        	}
		        	sizeBase = temp * 2 / 3;
		        	
		        	mPrefs.edit().putInt(CalibrationBaseActivity._Pressure, presBase).commit();
		        	mPrefs.edit().putInt(CalibrationBaseActivity._Size, sizeBase).commit();
		        	mPrefs.edit().putBoolean(CalibrationBaseActivity._Calibration, true).commit();

					Intent nextIntent;
		            nextIntent = new Intent(CalibrationBaseActivity.this, CalibrationTipActivity.class);
		            nextIntent.putExtra(CalibrationTipActivity._FromMenu, fromMenu);
		            CalibrationBaseActivity.this.startActivity(nextIntent);
		            CalibrationBaseActivity.this.finish();
		            return true;
		        case MotionEvent.ACTION_MOVE:
		            p = event.getPressure(0);
		            s = event.getSize(0);
		            presList.add((int)(p*100));
		            sizeList.add((int)(s*100));
		            Log.d("Touch01", "p= " + (int)(p*100) + ", s=" + (int)(s*100));
		            return true;
		        case MotionEvent.ACTION_CANCEL:
		        	//TODO: DO WE NEED THIS?
		            return true;
		        }
				return false;
			}
		});
		
		/*imgView = (ImageView) findViewById(R.id.image_thumb_base);
		imgView.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				float p;
				float s;
				int temp;
		        switch (event.getAction()) {
		        case MotionEvent.ACTION_DOWN:
		        	presList.clear();
		        	sizeList.clear();
		            p = event.getPressure(0);
		            s = event.getSize(0);
		            timestamp = (int)System.currentTimeMillis();
		            presList.add((int)(p*100));
		            sizeList.add((int)(s*100));
		            return true;
		        case MotionEvent.ACTION_UP:
		        	temp = (int)System.currentTimeMillis();
		        	if (temp < timestamp + duration) {
						Toast toast = Toast.makeText(getBaseContext(), "Please try at least 2 seconds!", Toast.LENGTH_SHORT);
						toast.show();
		        		return true;
		        	}
		        	for (int i=temp=0; i<presList.size(); ++i) {
		        		if (presList.get(i) > temp) {
		        			temp = presList.get(i);
		        		}
		        	}
		        	presBase = temp;
		        	
		        	for (int i=temp=0; i<sizeList.size(); ++i) {
		        		if (sizeList.get(i) > temp) {
		        			temp = sizeList.get(i);
		        		}
		        	}
		        	sizeBase = temp;
		        	
		        	mPrefs.edit().putInt(CalibrationBaseActivity._Pressure, presBase).commit();
		        	mPrefs.edit().putInt(CalibrationBaseActivity._Size, sizeBase).commit();
		        	mPrefs.edit().putBoolean(CalibrationBaseActivity._Calibration, true).commit();

					Intent nextIntent;
		            nextIntent = new Intent(CalibrationBaseActivity.this, CalibrationTipActivity.class);
		            nextIntent.putExtra(CalibrationTipActivity._FromMenu, fromMenu);
		            CalibrationBaseActivity.this.startActivity(nextIntent);
		            CalibrationBaseActivity.this.finish();
		            return true;
		        case MotionEvent.ACTION_MOVE:
		            p = event.getPressure(0);
		            s = event.getSize(0);
		            presList.add((int)(p*100));
		            sizeList.add((int)(s*100));
		            return true;
		        case MotionEvent.ACTION_CANCEL:
		        	//TODO: DO WE NEED THIS?
		            return true;
		        }
				return false;
			}
		});*/
	}
	
	@Override
	public void onBackPressed() {
		this.disableRunnables = true;
		if (toast != null) {
			toast.cancel();
		}
		super.onBackPressed();
	}
	
}
