package com.example.touch01;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
    private final static int DATABASE_VERSION = 1;
    private final static String _userTable = "user";
    private final static String _cellTable = "cell_pattern";
    private final static String _trajTable = "trajectory_pattern";
    private final static String _battTable = "battle_history";
    private SQLiteDatabase db;
	private RESTHelper rest;
    
    public DBHelper(Context context){
        super(context.getApplicationContext(), 
        		Environment.getExternalStorageDirectory().getAbsolutePath() + "/" 
        	    + context.getResources().getString(R.string.dbfile), 
        		null, DATABASE_VERSION);
		this.rest = new RESTHelper();
    }
    
	public void setWritableDatabase(SQLiteDatabase db) {
		this.db = db;
	}
    
	public void clearWritableDatabase() {
		this.db = null;
	}
    
    // TODO
    public void onCreate(SQLiteDatabase db){
    	this.db = db;
    	String sql;
    	
    	db.execSQL("DROP TABLE IF EXISTS " + _userTable);
    	db.execSQL("DROP TABLE IF EXISTS " + _cellTable);
    	db.execSQL("DROP TABLE IF EXISTS " + _trajTable);
    	db.execSQL("DROP TABLE IF EXISTS " + _battTable);

    	// user table
    	sql = "CREATE TABLE IF NOT EXISTS " + _userTable + " ("
    			+ "id" + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
    			+ "time" + " INTEGER NOT NULL,"
    			+ "last_login" + " INTEGER NOT NULL,"
    			+ "name" + " TEXT NOT NULL,"
    			+ "total_point" + " INTEGER NOT NULL,"
    			+ "attack_point" + " INTEGER NOT NULL,"
    			+ "defense_point" + " INTEGER NOT NULL,"
    			+ "usability_point" + " INTEGER NOT NULL,"
    			+ "n_trial_self" + " INTEGER NOT NULL,"
    			+ "n_trial_other" + " INTEGER NOT NULL,"
    			+ "n_ts_self" + " INTEGER NOT NULL,"
    			+ "n_tf_self" + " INTEGER NOT NULL,"
    			+ "n_fs_self" + " INTEGER NOT NULL,"
    			+ "n_ff_self" + " INTEGER NOT NULL,"
    			+ "n_ts_other" + " INTEGER NOT NULL,"
    			+ "n_tf_other" + " INTEGER NOT NULL,"
    			+ "n_fs_other" + " INTEGER NOT NULL,"
    			+ "n_ff_other" + " INTEGER NOT NULL);";
    	db.execSQL(sql);
    	
    	// cell pattern table
    	sql = "CREATE TABLE IF NOT EXISTS " + _cellTable + " ("
    			+ "id" + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
    			+ "time" + " INTEGER NOT NULL,"
    			+ "name" + " TEXT NOT NULL,"
    			+ "pattern" + " TEXT NOT NULL);";
    	db.execSQL(sql);
    	
    	// trajectory pattern table
    	sql = "CREATE TABLE IF NOT EXISTS " + _trajTable + " ("
    			+ "id" + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
    			+ "time" + " INTEGER NOT NULL,"
    			+ "name" + " TEXT NOT NULL,"
    			+ "manifest" + " INTEGER NOT NULL,"
    			+ "pattern" + " TEXT NOT NULL);";
    	db.execSQL(sql);

    	// battle history table
    	sql = "CREATE TABLE IF NOT EXISTS " + _battTable + " ("
    			+ "id" + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
    			+ "time" + " INTEGER NOT NULL,"
    			+ "pname" + " TEXT NOT NULL,"
    			+ "oname" + " TEXT NOT NULL,"
    			+ "ppoint" + " INTEGER NOT NULL,"
    			+ "opoint" + " INTEGER NOT NULL,"
    			+ "rpoint" + " INTEGER NOT NULL,"
    			+ "manifest" + " INTEGER NOT NULL);";
    	db.execSQL(sql);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
    	db.execSQL("DROP TABLE IF EXISTS " + _userTable);
    	db.execSQL("DROP TABLE IF EXISTS " + _cellTable);
    	db.execSQL("DROP TABLE IF EXISTS " + _trajTable);
    	db.execSQL("DROP TABLE IF EXISTS " + _battTable);
    	onCreate(db);
    }
    
    public Boolean createUser(UserProfile profile, String device_id, Boolean localOnly) {
    	Boolean result;
    	if (localOnly == false) {
        	result = rest.createUser(profile, device_id);
        	if (result == false) {
        		return false;
        	}
    	}
    	String sql = "INSERT INTO " + _userTable + " VALUES(null, "
    			+ profile.getTime() + ", " + profile.getLastLogin() + ", '"
    			+ profile.getName() + "', " + profile.getTotalPoint() + ", "
    			+ profile.getAttackPoint() + ", " + profile.getDefensePoint() + ", " + profile.getUsabilityPoint() + ", "
    			+ profile.getTrialSelf() + ", " + profile.getTrialOther() + ", "
    			+ profile.getTrueSuccessSelf() + ", " + profile.getTrueFailureSelf() + ", "
    			+ profile.getFalseSuccessSelf() + ", " + profile.getFalseFailureSelf() + ", "
    			+ profile.getTrueSuccessOther() + ", " + profile.getTrueFailureOther() + ", "
    			+ profile.getFalseSuccessOther() + ", " + profile.getFalseFailureOther() + ");";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    public Boolean deleteUser(String name, String device_id) {
    	Boolean result;
    	result = rest.deleteUser(name, device_id);
    	if (result == false) {
    		return false;
    	}
    	String sql = "DELETE FROM " + _userTable + " WHERE name = '" + name + "';";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    // TODO
    public UserProfile lookupUser(String name) {
    	UserProfile profile = null;
    	
    	profile = rest.lookupUser(name);
		if (profile == null) {
    		Log.d("Touch01", "WARNING: there is no such a user on a server DB.");
    		return null;
		}
		
    	String sql = "DELETE FROM " + _userTable;
    	if (db == null) {
    		return null;
    	}
    	db.execSQL(sql);
    	
		// Then, we create a user in this local DB.
		createUser(profile, null, true);
		return profile;
		
    	/*String sql = "SELECT * FROM " + _userTable + " WHERE name = '" + name + "';";
    	//Log.d("Touch01", sql);
    	Cursor cursor = db.rawQuery(sql, null);
    	//Cursor cursor = db.query(_userTable, new String[] {"id"}, "username = '" + username + "'", null, null, null, null);
    	if (cursor == null || cursor.getCount() <= 0) {
    		Log.d("Touch01", "WARNING: there is no such a user on a local DB.");
    		// In this case, we lookup the server DB
    		profile = rest.lookupUser(name);
    		if (profile == null) {
        		Log.d("Touch01", "WARNING: there is no such a user on a server DB.");
        		return null;
    		}
    		// Then, we create a user in this local DB.
    		createUser(profile, null, true);
    		return profile;
    	}
    	while (cursor.moveToNext()) {
        	int dbid = cursor.getInt(0);
        	int time = cursor.getInt(1);
        	int last_login = cursor.getInt(2);
        	name = cursor.getString(3);
        	int total_point = cursor.getInt(4);
        	int attack_point = cursor.getInt(5);
        	int defense_point = cursor.getInt(6);
        	int usability_point = cursor.getInt(7);
        	int n_trial_self = cursor.getInt(8);
        	int n_trial_other = cursor.getInt(9);
        	int n_ts_self = cursor.getInt(10);
        	int n_tf_self = cursor.getInt(11);
        	int n_fs_self = cursor.getInt(12);
        	int n_ff_self = cursor.getInt(13);
        	int n_ts_other = cursor.getInt(14);
        	int n_tf_other = cursor.getInt(15);
        	int n_fs_other = cursor.getInt(16);
        	int n_ff_other = cursor.getInt(17);
        	profile = new UserProfile(dbid, time, last_login, name, 
        			total_point, attack_point, defense_point, usability_point,
        			n_trial_self, n_trial_other, n_ts_self, n_tf_self, n_fs_self, n_ff_self,
        			n_ts_other, n_tf_other, n_fs_other, n_ff_other);
			
        	//String str = "We found a user's profile: " + profile.toString();
        	//Log.d("Touch01", str);
        	break;
    	}
    	return profile;*/
    }
    
    public int countUsers() {
    	// count users should be done at the server-side, since it changes frequently
    	return rest.countUsers();
    }

    public Boolean logIn(UserProfile profile, String device_id) {
    	// user log-in should be done at the server-side
    	return rest.logIn(profile, device_id);
    }

    public int lookupUserRank(String name) {
    	// lookup user rank should be done at the server-side, since it changes frequently
    	return rest.lookupUserRank(name);
    }
    
    public List<UserProfile> lookupUsersByRank(int offset, int count) {
    	// lookup user rank should be done at the server-side, since it changes frequently
    	return rest.lookupUsersByRank(offset, count);
    }
    
    // TODO
    public Boolean updateUser(UserProfile profile, String device_id) {
    	Boolean result;
    	result = rest.updateUser(profile, device_id);
    	if (result == false) {
    		return false;
    	}
    	String sql = "UPDATE " + _userTable + " SET ";
    	sql += "time = " + profile.getTime()
    		+ ", last_login = " + profile.getLastLogin()
    		+ ", total_point = " + profile.getTotalPoint()
    		+ ", attack_point = " + profile.getAttackPoint()
    		+ ", defense_point = " + profile.getDefensePoint()
    		+ ", usability_point = " + profile.getUsabilityPoint()
    		+ ", n_trial_self = " + profile.getTrialSelf()
    		+ ", n_trial_other = " + profile.getTrialOther()
    		+ ", n_ts_self = " + profile.getTrueSuccessSelf()
    		+ ", n_tf_self = " + profile.getTrueFailureSelf()
    		+ ", n_fs_self = " + profile.getFalseSuccessSelf()
    		+ ", n_ff_self = " + profile.getFalseFailureSelf()
    		+ ", n_ts_other = " + profile.getTrueSuccessOther()
    		+ ", n_tf_other = " + profile.getTrueFailureOther()
    		+ ", n_fs_other = " + profile.getFalseSuccessOther()
    		+ ", n_ff_other = " + profile.getFalseFailureOther()
    		+ " WHERE name= '" + profile.getName() + "';";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }

    public CellPattern lookupCellPattern(String name) {
    	String sql = "SELECT * FROM " + _cellTable + " WHERE name = '" + name + "';";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return null;
    	}
    	Cursor cursor = db.rawQuery(sql, null);
    	CellPattern pattern = null;
    	if (cursor == null || cursor.getCount() <= 0) {
    		Log.d("Touch01", "WARNING: there is no such a cell pattern on a local DB.");
    		// In this case, we lookup the server DB
    		pattern = rest.lookupCellPattern(name);
    		if (pattern == null) {
        		Log.d("Touch01", "WARNING: there is no such a cell pattern on a server DB.");
        		return null;
    		}
    		// Then, we create a pattern in this local DB.
    		createCellPattern(pattern, null, true);
    		return pattern;
    	}
    	while (cursor.moveToNext()) {
        	int dbid = cursor.getInt(0);
        	int time = cursor.getInt(1);
        	name = cursor.getString(2);
        	String strPattern = cursor.getString(3);
        	pattern = new CellPattern(dbid, time, name, strPattern);
    		//String str = "We found a cell_pattern: " + pattern.toString();
    		//Log.d("Touch01", str);
    		break;
    	}
    	return pattern;
    }
    
    // TODO
    public Boolean createCellPattern(CellPattern pattern, String device_id, Boolean localOnly) {
    	if (localOnly == false) {
    		Boolean result;
        	result = rest.createCellPattern(pattern, device_id);
        	if (result == false) {
        		return false;
        	}
    	}
    	String sql = "INSERT INTO " + _cellTable + " VALUES(null, "
    			+ pattern.getTime() + ", '" + pattern.getName() + "', '" + pattern.getPattern() + "');";
    	//Log.d("Touch01", sql);
    	db.execSQL(sql);
    	if (db == null) {
    		return false;
    	}
    	return true;
    }
    
    // TODO
    public Boolean deleteCellPattern(String name, String device_id) {
    	Boolean result;
    	result = rest.deleteCellPattern(name, device_id);
    	if (result == false) {
    		return false;
    	}
    	String sql = "DELETE FROM " + _cellTable + " WHERE name = '" + name + "';";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    // TODO
    public Boolean createTrajPattern(TrajPattern pattern, String device_id, Boolean localOnly) {
    	if (localOnly == false) {
    		Boolean result;
        	result = rest.createTrajPattern(pattern, device_id);
        	if (result == false) {
        		return false;
        	}
    	}
    	String sql = "INSERT INTO " + _trajTable + " VALUES(null, "
    			+ pattern.getTime() + ", '"
    			+ pattern.getName() + "', "
    			+ pattern.getManifest() + ", '"
    			+ pattern.getPattern() + "');";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    /*public void deleteTrajPattern(String name, String trajPattern, _tpManif manifest) {
    	rest.deleteTrajPattern(name);
    	String sql = "DELETE FROM " + _trajTable + " WHERE name = '" + name
    			+ "' AND manifest = " + manifest + " AND pattern = '" + trajPattern + "');";
    	Log.d("Touch01", sql);
    	db.execSQL(sql);
    }*/
    
    // TODO
    public Boolean deleteTrajPattern(String name, String device_id) {
    	Boolean result;
    	result = rest.deleteTrajPattern(name, device_id);
    	if (result == false) {
    		return false;
    	}
    	String sql = "DELETE FROM " + _trajTable + " WHERE name = '" + name + "';";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    public List<TrajPattern> lookupTrajPattern(String name, int manifest) {
    	String sql = "SELECT * FROM " + _trajTable + " WHERE name = '"
    		+ name + "' AND manifest = " + manifest + ";";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return null;
    	}
    	Cursor cursor = db.rawQuery(sql, null);
    	List<TrajPattern> tpList = null;
    	if (cursor == null || cursor.getCount() <= 0) {
    		String str = "WARNING: there is no such a traj pattern on a local DB. (manifest = " + manifest + ")";
    		Log.d("Touch01", str);
    		// In this case, we lookup the server DB
    		tpList = rest.lookupTrajPattern(name, manifest);
    		if (tpList == null) {
    			str = "WARNING: there is no such a traj pattern on a server DB. (manifest = " + manifest + ")"; 
        		Log.d("Touch01", str);
        		return null;
    		}

    		// Then, we create a pattern in this local DB.
        	Iterator<TrajPattern> it = tpList.iterator();
        	while(it.hasNext()){
        		createTrajPattern(it.next(), null, true);
    	    }
    		return tpList;
    	}
    	
    	tpList = new ArrayList<TrajPattern>();
    	TrajPattern pattern;
    	while (cursor.moveToNext()) {
        	int dbid = cursor.getInt(0);
        	int time = cursor.getInt(1);
        	name = cursor.getString(2);
        	manifest = cursor.getInt(3);
        	String strPattern = cursor.getString(4);
        	pattern = new TrajPattern(dbid, time, name, strPattern, manifest);
        	tpList.add(pattern);
        	//String str = "We found a traj_pattern: " + pattern.toString();
        	//Log.d("Touch01", str);
    	}
    	return tpList;
    }

    
    // TODO
    public Boolean updateTrajPattern(String name, String tPatternOld, String tPatternNew, int manifest, String device_id) {
    	Boolean result;
    	result = rest.updateTrajPattern(name, tPatternOld, tPatternNew, manifest, device_id);
    	if (result == false) {
    		return false;
    	}
    	int time = (int) (System.currentTimeMillis() / 1000);
    	String sql = "UPDATE " + _trajTable + " SET pattern = '"
    			+ tPatternNew + "', time = " + time
    			+ " WHERE name = '" + name + "' AND manifest = "
    			+ manifest + " AND pattern = '" + tPatternOld + "';";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return false;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    // TODO
    public Boolean createBattHistory(BattleHistory history, String device_id, Boolean localOnly) {
    	if (localOnly == false) {
    		Boolean result;
    		result = rest.createBattHistory(history, device_id);
    		if (result == false) {
    			return false;
    		}
    	}
    	String sql = "INSERT INTO " + _battTable + " VALUES(null, "
    			+ history.getTime() + ", '"
    			+ history.getPlayerName() + "', '"
    			+ history.getOpponentName() + "', "
    			+ history.getPlayerPoint() + ", "
    			+ history.getOpponentPoint() + ", "
    			+ history.getRewardPoint() + ", "
    			+ history.getManifest() + ");";
    	//Log.d("Touch01", sql);
    	if (db == null) {
    		return null;
    	}
    	db.execSQL(sql);
    	return true;
    }
    
    public List<BattleHistory> lookupBattHistory(String name) {
    	List<BattleHistory> record = null;
    	
    	record = rest.lookupBattHistory(name);
		if (record == null) {
    		Log.d("Touch01", "WARNING: there is no battle history on a server DB.");
    		return null;
		}
    	
    	String sql = "DELETE FROM " + _battTable;
    	if (db == null) {
    		return null;
    	}
    	db.execSQL(sql);
    	
    	Iterator<BattleHistory> it = record.iterator();
    	while (it.hasNext()) {
    		createBattHistory(it.next(), null, true);
    	}
    	return record;
    	
    	/*String sql = "SELECT * FROM " + _battTable
    		+ " WHERE pname = '" + name + "' OR oname = '" + name + "';";
    	//Log.d("Touch01", sql);
    	Cursor cursor = db.rawQuery(sql, null);
    	if (cursor == null || cursor.getCount() <= 0) {
    		Log.d("Touch01", "WARNING: there is no battle history on a local DB.");
    		// In this case, we lookup the server DB
    		record = rest.lookupBattHistory(name);
    		if (record == null) {
        		Log.d("Touch01", "WARNING: there is no battle history on a server DB.");
        		return null;
    		}
        	it = record.iterator();
        	while(it.hasNext()){
        		createBattHistory(it.next(), null, true);
    	    }
    		return record;
    	}
    	record = new ArrayList<BattleHistory>();
    	BattleHistory history;
    	while (cursor.moveToNext()) {
        	int dbid = cursor.getInt(0);
        	int time = cursor.getInt(1);
        	String pname = cursor.getString(2);
        	String oname = cursor.getString(3);
        	int p_point = cursor.getInt(4);
        	int o_point = cursor.getInt(5);
        	int r_point = cursor.getInt(6);
        	int manifest = cursor.getInt(7);
        	history = new BattleHistory(dbid, time, pname, oname, p_point, o_point, r_point, manifest);
        	record.add(history);
        	//String str = "We found a battle record: " + record.toString();
        	//Log.d("Touch01", str);
    	}
    	return record;*/
    }
}