package com.example.touch01;

import group.pals.android.lib.ui.lockpattern.LockPatternActivity;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

public class Splash extends Activity {
	private String _nickname;
    private SharedPreferences mPrefs;

	private static final int SPLASH_DISPLAY_TIME = 1500; /* 1.5 seconds */
	
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
	    setContentView(R.layout.splash);
	    
		mPrefs = getSharedPreferences(LockPatternActivity.class.getName(), 0);
		_nickname = mPrefs.getString(LoginActivity._Nickname, null);
	
	    new Handler().postDelayed(new Runnable() {
	
	        public void run() {
	            Intent nextIntent;
	        	if(_nickname == null || _nickname.isEmpty()) {
		            nextIntent = new Intent(Splash.this, LoginActivity.class);
	        	}
	        	else {
		            nextIntent = new Intent(Splash.this, MenuActivity.class);
	        	}
	            Splash.this.startActivity(nextIntent);
	            Splash.this.finish();
	            overridePendingTransition(R.anim.mainfadein,
	                    R.anim.splashfadeout);
	        }
	    }, SPLASH_DISPLAY_TIME);
	}
}