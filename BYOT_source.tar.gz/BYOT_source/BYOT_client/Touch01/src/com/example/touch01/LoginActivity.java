package com.example.touch01;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity 
implements AsyncResponse.AsyncCheckServerStatusResponse {
	private DBHelper dbHelper;
	private SQLiteDatabase db;
	private Button start_button;
	private EditText nickname_box;
    private static final String _ClassName = LoginActivity.class.getName();
	public static final String _Nickname = _ClassName + ".nickname";
	public static final String _DeviceID = _ClassName + ".device_id";
	private final int btnColor = 0xffDDDDFF;
	private Context _context;
    
	//private String _profile;
	private UserProfile _userProfile;
	private String _nickname;
	private Boolean _calibrationBase;
	private Boolean _calibrationTip;
    private SharedPreferences mPrefs;
    private long _timeBackKey = 0;
    private Toast _quitToast;
    private Toast _warnToast;
    private RESTHelper rest;
    private Boolean _serverAvailability;
    private String _device_id;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		setContentView(R.layout.login);
		
		this.dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();
		this.dbHelper.setWritableDatabase(db);
		
		_context = this.getApplicationContext();
		
		final TelephonyManager tm =
				(TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);
		_device_id = tm.getDeviceId();
		
		mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
		_nickname = mPrefs.getString(LoginActivity._Nickname, null);
		
		nickname_box = (EditText) findViewById(R.id.editTextNickname);		
		if (_nickname != null && _nickname.isEmpty() == false) {
			nickname_box.setText(_nickname);
		}
		
		start_button = (Button) findViewById(R.id.start_button);
		start_button.setBackgroundColor(btnColor);
		start_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if(_warnToast != null) {
					_warnToast.cancel();
				}
				_nickname = nickname_box.getText().toString();
				if (_nickname == null || _nickname.isEmpty()) {
					_warnToast = Toast.makeText(getBaseContext(), "Please type your nickname!", Toast.LENGTH_SHORT);
					_warnToast.show();
					return;
				}
				
				if (_nickname.length() > 10 || _nickname.contains(" ")) {
					_warnToast = Toast.makeText(getBaseContext(), "Max 10 characters, no whitespaces!", Toast.LENGTH_SHORT);
					_warnToast.show();
					return;
				}
				
				if (_nickname.contains(",") || _nickname.contains("_")) {
					_warnToast = Toast.makeText(getBaseContext(), "No commas, or underscores", Toast.LENGTH_SHORT);
					_warnToast.show();
					return;
				}
				
				if (_nickname.contains("(") || _nickname.contains(")")) {
					_warnToast = Toast.makeText(getBaseContext(), "No parentheses", Toast.LENGTH_SHORT);
					_warnToast.show();
					return;
				}
				
				Boolean result;
				// TODO: Need "Progress Bar" Here! 
				// We then need to lookup the user profile from DB
				_userProfile = dbHelper.lookupUser(_nickname);
				if (_userProfile == null) {
					// there is no record on the DB, so create new one
					_userProfile = new UserProfile(_nickname);
					// now, register the user's profile to the DB
					result = dbHelper.createUser(_userProfile, _device_id, false);
					if (result == false) {
						//Create User Failed (Network problem?)
						_warnToast = Toast.makeText(getBaseContext(),
							"User registration failed! (server comm. error)", Toast.LENGTH_SHORT);
						_warnToast.show();
						return;
					}
				} else {
					// we found the user profile from the DB, so use the one
					// but we need to update the last_login_time on the DB
					_userProfile.setLastLogin((int) (System.currentTimeMillis() / 1000));
					result = dbHelper.logIn(_userProfile, _device_id);
					if (result == false) {
						//Log-in Failed (different device?)
						_warnToast = Toast.makeText(getBaseContext(),
							"User log in failed (may be different device?)", Toast.LENGTH_SHORT);
						_warnToast.show();
						return;
					}
				}
	    		int rank = dbHelper.lookupUserRank(_nickname);
				if (rank == 0) {
					Log.e("Touch01", "Error on reading user's ranking!");
					rank = 1;
				}
				_userProfile.setRank(rank);
				
				//_profile = _userProfile.toStringSimple();
				mPrefs.edit().putString(LoginActivity._Nickname, _nickname).commit();
				mPrefs.edit().putString(LoginActivity._DeviceID, _device_id).commit();
				
				mPrefs = getSharedPreferences(CalibrationBaseActivity.class.getName(), 0);
				_calibrationBase = mPrefs.getBoolean(CalibrationBaseActivity._Calibration, false);
				mPrefs = getSharedPreferences(CalibrationTipActivity.class.getName(), 0);
				_calibrationTip = mPrefs.getBoolean(CalibrationTipActivity._Calibration, false);
				
	            Intent nextIntent;
				if (_calibrationBase == false) {
		            nextIntent = new Intent(LoginActivity.this, CalibrationBaseActivity.class);
					nextIntent.putExtra(CalibrationBaseActivity._UserProfile, _userProfile.toStringSimple());
				} else if (_calibrationTip == false) {
		            nextIntent = new Intent(LoginActivity.this, CalibrationTipActivity.class);
					nextIntent.putExtra(CalibrationTipActivity._UserProfile, _userProfile.toStringSimple());
				} else {
		            nextIntent = new Intent(LoginActivity.this, MenuActivity.class);
					nextIntent.putExtra(MenuActivity._UserProfile, _userProfile.toStringSimple());
				}
			    if (dbHelper != null) {
			        dbHelper.close();
			    }
			    if (db != null) {
			        db.close();
			        db = null;
			    }
	            LoginActivity.this.startActivity(nextIntent);
	            LoginActivity.this.finish();
	            overridePendingTransition(R.anim.mainfadein,
	                    R.anim.splashfadeout);
			}
		});
		
		// IF SERVER IS UNAVAILABLE, SHOW TOAST THAT SYSTEM IS UNAVAILABLE
		// OTHERWISE, JUST GO WITHOUT PROBLEMS
		this.rest = new RESTHelper();
		_serverAvailability = rest.serverAvailability();
		if (_serverAvailability == false) {
			// server is not available at this time
			// thus, just show a dialog box and click to finish
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("\nSorry, the system isn't available now,\nso we can't let you in the BYOT world.\nBut it will be fine in a few minutes!\n")
			       .setCancelable(false)
			       .setNeutralButton("I see, man.\nBut please return back soon!", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			               //do things
			        	   finish();
			           }
			       });
			AlertDialog alert = builder.create();
			alert.show();
		}
	}
	
	@Override
	public void onBackPressed(){
		if (Math.abs(_timeBackKey - System.currentTimeMillis()) > 3000) {
			_quitToast = Toast.makeText(this, "To quit, touch back again", Toast.LENGTH_SHORT);
			_quitToast.show();
			_timeBackKey = System.currentTimeMillis();
		} else {
			if (_warnToast != null) {
				_warnToast.cancel();
			}
			if (_quitToast != null) {
				_quitToast.cancel();
			}
		    if (dbHelper != null) {
		    	dbHelper.clearWritableDatabase();
		        dbHelper.close();
		        dbHelper = null;
		    }
		    if (db != null) {
		        db.close();
		        db = null;
		    }
			super.onBackPressed();
		}
	}
	
	@Override
	public void processCheckServerStatusFinish(String status) {
		Log.d("Touch01", "AsyncCheckServerStatusTask is finished.");
	}
	
}
