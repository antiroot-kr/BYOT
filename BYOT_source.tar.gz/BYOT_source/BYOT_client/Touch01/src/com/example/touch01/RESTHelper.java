package com.example.touch01;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.util.Log;

@SuppressLint("NewApi")
public class RESTHelper {
    private final static String _serverURL = "http://pepperjack.stanford.edu";
    private final static String _userProfilePort = ":8000?";
    private final static String _cellPatternPort = ":8001?";
    private final static String _trajPatternPort = ":8002?";
    private final static String _battHistoryPort = ":8003?";
    private final static String _availaCheckPort = ":8004?";
    
    private final static String _logIn = "query=log_in&";
    private final static String _countUsers = "query=count_users";
    private final static String _lookupUser = "query=lookup_user&";
    private final static String _lookupUserRank = "query=lookup_user_rank&";
    private final static String _lookupUsersByRank = "query=lookup_users_by_rank&";
    private final static String _lookupUsersByScore = "query=lookup_users_by_score&";
    private final static String _createUser = "query=create_user&";
    private final static String _updateUser = "query=update_user&";
    private final static String _deleteUser = "query=delete_user&";
    private final static String _lookupCellPattern = "query=lookup_cell_pattern&";
    private final static String _createCellPattern = "query=create_cell_pattern&";
    private final static String _updateCellPattern = "query=update_cell_pattern&";
    private final static String _deleteCellPattern = "query=delete_cell_pattern&";
    private final static String _lookupTrajPattern = "query=lookup_traj_pattern&";
    private final static String _createTrajPattern = "query=create_traj_pattern&";
    private final static String _updateTrajPattern = "query=update_traj_pattern&";
    private final static String _deleteTrajPattern = "query=delete_traj_pattern&";
    private final static String _lookupBattHistory = "query=lookup_batt_history&";
    private final static String _createBattHistory = "query=create_batt_history&";
    private final static String _deleteBattHistory = "query=delete_batt_history&";
    private final static String _device_id = "device_id=";
    private final static String _name = "name=";
    private final static String _time = "time=";
    private final static String _lastLogin = "last_login=";
    private final static String _offset = "offset=";
    private final static String _count = "count=";
    private final static String _lowScore = "low_score=";
    private final static String _highScore = "high_score=";
    private final static String _totalPoint = "total_point=";
    private final static String _attackPoint = "attack_point=";
    private final static String _defensePoint = "defense_point=";
    private final static String _usabilityPoint = "usability_point=";
    private final static String _nTrialSelf = "n_trial_self=";
    private final static String _nTrialOther = "n_trial_other=";
    private final static String _nTSSelf = "n_ts_self=";
    private final static String _nTFSelf = "n_tf_self=";
    private final static String _nFSSelf = "n_fs_self=";
    private final static String _nFFSelf = "n_ff_self=";
    private final static String _nTSOther = "n_ts_other=";
    private final static String _nTFOther = "n_tf_other=";
    private final static String _nFSOther = "n_fs_other=";
    private final static String _nFFOther = "n_ff_other=";
    private final static String _pattern = "pattern=";
    private final static String _oldPattern = "old_pattern=";
    private final static String _newPattern = "new_pattern=";
    private final static String _manifest = "manifest=";
    private final static String _pname = "pname=";
    private final static String _oname = "oname=";
    private final static String _ppoint = "ppoint=";
    private final static String _opoint = "opoint=";
    private final static String _rpoint = "rpoint=";
    
    private HttpClient mREST;
    
    private class HttpGetNonblockTask extends AsyncTask<String, Void, String> {
    	String _url = null;
    	/*private void retry() {
    		if (_url != null && _url.isEmpty() == false) {
        		this.execute(_url);
    		}
    	}*/

		@Override
        protected String doInBackground(String... urls) {
        	String result = "";
        	if (_url == null) {
        		_url = urls[0];
        	}
        	HttpGet request = new HttpGet(_url);
        	HttpResponse response;
    		try {
    			response = mREST.execute(request);
    	    	StatusLine status = response.getStatusLine();
    	    	if (status.getStatusCode() == HttpStatus.SC_OK) {
    	    		ByteArrayOutputStream outstream = new ByteArrayOutputStream();
    	    		response.getEntity().writeTo(outstream);
    	    		response.getEntity().consumeContent();
    	    		outstream.close();
    	    		result = outstream.toString();
    	    		//Log.d("Touch01", result);
    	    	} else {
    	    		response.getEntity().consumeContent();
    	    		throw new IOException(status.getReasonPhrase());
    	    	}
    		} catch (ClientProtocolException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			Log.e("Touch01", "Error on performGetNonblock() - ClientProtocolException");
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			Log.e("Touch01", "Error on performGetNonblock() - IOException");
    			return null;
    		}
        	return result;
        }

        protected void onPostExecute(String result) {
        	if (result == null) {
        		Log.e("Touch01", "Server is not available at this moment. Sorry!");
        		HttpGetNonblockTask task = new HttpGetNonblockTask();
        		task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this._url);
        	} else if (result.contains("[ERROR]")) {
        		Log.e("Touch01", result);
        	} else if (result.contains("[WARNING]")) {
        		Log.d("Touch01", result);
        	} else {
        		Log.d("Touch01", "onPostExecute() - Succeeded!");
        	}
        	this.cancel(true);
        }
    }

    private class HttpGetTask extends AsyncTask<String, Void, String> {

		@Override
        protected String doInBackground(String... urls) {
        	String result = "";
        	HttpGet request = new HttpGet(urls[0]);
        	HttpResponse response;
    		try {
    			response = mREST.execute(request);
    	    	StatusLine status = response.getStatusLine();
    	    	if (status.getStatusCode() == HttpStatus.SC_OK) {
    	    		ByteArrayOutputStream outstream = new ByteArrayOutputStream();
    	    		response.getEntity().writeTo(outstream);
    	    		response.getEntity().consumeContent();
    	    		outstream.close();
    	    		result = outstream.toString();
    	    		//Log.d("Touch01", result);
    	    	} else {
    	    		response.getEntity().consumeContent();
    	    		throw new IOException(status.getReasonPhrase());
    	    	}
    		} catch (ClientProtocolException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			Log.e("Touch01", "Error on performGet() - ClientProtocolException");
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			Log.e("Touch01", "Error on performGet() - IOException");
    			return null;
    		}
        	return result;
        }
    }
    
    public RESTHelper() {
    	mREST = new DefaultHttpClient();
    	if (mREST == null) {
    		Log.e("Touch01", "Failed to create a http client!");
    	}
    	ClientConnectionManager cConnManger = mREST.getConnectionManager();
    	HttpParams params = mREST.getParams();
    	mREST = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
    		cConnManger.getSchemeRegistry()), params);
    }
    
    private String performGet(String url) {
    	//Log.d("Touch01", url);
    	String result = null;
    	HttpGetTask task = new HttpGetTask();
    	try {
			result = task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, url).get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		task.cancel(true);
    	return result;
    }

    private void performGetNonblock(String url) {
    	HttpGetNonblockTask task = new HttpGetNonblockTask();
		task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, url);
		//task.cancel(false);
    }
    
    public Boolean serverAvailability() {
    	Boolean status = false;
    	String getURL = _serverURL + _availaCheckPort;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server is not available now.");
    		status = serverAvailability();
    	} else if (result.compareTo("BYOT") == 0) {
    		Log.d("Touch01", "Server is available now.");
    		status = true;
    	} else {
    		Log.e("Touch01", "Server is working, but showing different response");
    		status = false;
    	}
    	return status;
    }
    
    public Boolean logIn(UserProfile profile, String device_id) {
    	Boolean boolResult = false;
    	if (profile == null) {
    		Log.e("Touch01", "'profile' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}
    	
    	String getURL = _serverURL + _userProfilePort + _logIn
    			+ _device_id + device_id + "&"
    			+ _name + profile.getName() + "&"
    			+ _lastLogin + profile.getLastLogin();
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server is not available now.");
    		boolResult = logIn(profile, device_id);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	} else {
    		boolResult = true;
    	}
    	return boolResult;
    }

    public Boolean createUser(UserProfile profile, String device_id) {
    	Boolean boolResult = false;
    	if (profile == null) {
    		Log.e("Touch01", "'profile' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}
    	
    	String getURL = _serverURL + _userProfilePort + _createUser;
    	getURL += _device_id + device_id + "&"
    			+ _name + profile.getName() + "&" + _time + profile.getTime() + "&"
        		+ _lastLogin + profile.getLastLogin() + "&"
        		+ _totalPoint + profile.getTotalPoint() + "&" + _attackPoint + profile.getAttackPoint() + "&"
        		+ _defensePoint + profile.getDefensePoint() + "&" + _usabilityPoint + profile.getUsabilityPoint() + "&"
        		+ _nTrialSelf + profile.getTrialSelf() + "&" + _nTrialOther + profile.getTrialOther() + "&"
        		+ _nTSSelf + profile.getTrueSuccessSelf() + "&" + _nTFSelf + profile.getTrueFailureSelf() + "&"
        		+ _nFSSelf + profile.getFalseSuccessSelf() + "&" + _nFFSelf + profile.getFalseFailureSelf() + "&"
        		+ _nTSOther + profile.getTrueSuccessOther() + "&" + _nTFOther + profile.getTrueFailureOther() + "&"
        		+ _nFSOther + profile.getFalseSuccessOther() + "&" + _nFFOther + profile.getFalseFailureOther();
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server is not available now.");
    		boolResult = createUser(profile, device_id);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	} else {
    		boolResult = true;
    	}
    	return boolResult;
    }
    
    public Boolean deleteUser(String name, String device_id) {
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}

    	String getURL = _serverURL + _userProfilePort + _deleteUser
    			+ _device_id + device_id + "&" + _name + name; 
    	/*String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}*/
    	performGetNonblock(getURL);
    	return true;
    }
    
    public int countUsers() {
    	int count = 0;
    	String getURL = _serverURL + _userProfilePort + _countUsers;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		count = countUsers();
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return 0;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return 0;
    	} else {
    		count = Integer.parseInt(result);
    	}
    	return count;
    }
    
    public UserProfile lookupUser(String name) {
    	UserProfile profile = null;
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return null;
    	}
    	
    	String getURL = _serverURL + _userProfilePort + _lookupUser + _name + name;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		profile = lookupUser(name);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return null;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return null;
    	} else {
    		profile = new UserProfile();
    		profile.setFromStringSimple(result);
    	}
    	return profile;
    }
    
    public int lookupUserRank(String name) {
    	int rank = 0;
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return 0;
    	}
    	
    	String getURL = _serverURL + _userProfilePort + _lookupUserRank + _name + name;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		rank = lookupUserRank(name);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return 0;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return 0;
    	} else {
    		rank = Integer.parseInt(result);
    	}
    	return rank;
    }
    
    public List<UserProfile> lookupUsersByRank(int offset, int count) {
    	List<UserProfile> upList = null;
    	String getURL = _serverURL + _userProfilePort + _lookupUsersByRank
    		+ _offset + offset + "&" + _count + count;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		upList = lookupUsersByRank(offset, count);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return null;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return null;
    	} else {
        	upList = new ArrayList<UserProfile>();
        	StringTokenizer tsToken = new StringTokenizer(result, " ");
        	UserProfile profile;
        	while (tsToken.hasMoreElements()) {
        		profile = new UserProfile();
        		profile.setFromStringSimple((String) tsToken.nextElement());
        		upList.add(profile);
        	}
    	}
    	return upList;
    }

    public List<UserProfile> lookupUsersByScore(int lowScore, int highScore) {
    	List<UserProfile> upList = null;
    	String getURL = _serverURL + _userProfilePort + _lookupUsersByScore + _lowScore + lowScore + "&" + _highScore + highScore;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		return null;
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return null;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return null;
    	} else {
        	upList = new ArrayList<UserProfile>();
        	StringTokenizer tsToken = new StringTokenizer(result, " ");
        	UserProfile profile;
        	while (tsToken.hasMoreElements()) {
        		profile = new UserProfile();
        		profile.setFromStringSimple((String) tsToken.nextElement());
        		upList.add(profile);
        	}
    	}
    	return upList;
    }

    public Boolean updateUser(UserProfile profile, String device_id) {
    	if (profile == null) {
    		Log.e("Touch01", "'profile' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}

    	String getURL = _serverURL + _userProfilePort + _updateUser;
    	getURL += _device_id + device_id + "&"
    		+ _name + profile.getName() + "&" + _time + profile.getTime() + "&"
    		+ _lastLogin + profile.getLastLogin() + "&"
    		+ _totalPoint + profile.getTotalPoint() + "&" + _attackPoint + profile.getAttackPoint() + "&"
    		+ _defensePoint + profile.getDefensePoint() + "&" + _usabilityPoint + profile.getUsabilityPoint() + "&"
    		+ _nTrialSelf + profile.getTrialSelf() + "&" + _nTrialOther + profile.getTrialOther() + "&"
    		+ _nTSSelf + profile.getTrueSuccessSelf() + "&" + _nTFSelf + profile.getTrueFailureSelf() + "&"
    		+ _nFSSelf + profile.getFalseSuccessSelf() + "&" + _nFFSelf + profile.getFalseFailureSelf() + "&"
    		+ _nTSOther + profile.getTrueSuccessOther() + "&" + _nTFOther + profile.getTrueFailureOther() + "&"
    		+ _nFSOther + profile.getFalseSuccessOther() + "&" + _nFFOther + profile.getFalseFailureOther();
    	/*String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}*/
    	performGetNonblock(getURL);
    	return true;
    }

    public Boolean createCellPattern(CellPattern pattern, String device_id) {
    	if (pattern == null) {
    		Log.e("Touch01", "'pattern' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}

    	String getURL = _serverURL + _cellPatternPort + _createCellPattern
    			+ _device_id + device_id + "&"
    	    	+ _name + pattern.getName() + "&"
    			+ _time + pattern.getTime() + "&"
    			+ _pattern + pattern.getPattern(); 
    	/*String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}*/
    	performGetNonblock(getURL);
    	return true;
    }
    
    public Boolean deleteCellPattern(String name, String device_id) {
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}

    	
    	String getURL = _serverURL + _cellPatternPort + _deleteCellPattern
    			+ _device_id + device_id + "&"
    			+ _name + name;  
    	String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}
    	//performGetNonblock(getURL);
    	return true;
    }
    
    public CellPattern lookupCellPattern(String name) {
    	CellPattern pattern = null;
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return null;
    	}
    	
    	String getURL = _serverURL + _cellPatternPort + _lookupCellPattern + _name + name;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		pattern = lookupCellPattern(name);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return null;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return null;
    	} else {
    		pattern = new CellPattern(name);
        	pattern.setFromStringSimple(result);
    	}
    	return pattern;
    }
    
    public Boolean updateCellPattern(String name, String pattern, String device_id) {
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return false;
    	}
    	if (pattern == null || pattern.length() == 0) {
    		Log.e("Touch01", "'pattern' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}

    	int time = (int) (System.currentTimeMillis() / 1000);
    	String getURL = _serverURL + _cellPatternPort + _updateCellPattern
    			+ _device_id + device_id + "&"
    	    	+ _name + name + "&" + _time + time + "&" + _pattern + pattern;
    	/*String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}*/
    	performGetNonblock(getURL);
    	return true;
    }

    public Boolean createTrajPattern(TrajPattern pattern, String device_id) {
    	if (pattern == null) {
    		Log.e("Touch01", "'pattern' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}

    	switch (pattern.getManifest()) {
    	case TrajPattern._RAW:
    	case TrajPattern._QUANTIZED:
    	case TrajPattern._AGGREGATED:
    		break;
		default:
    		Log.e("Touch01", "'manifest' field has wrong value!");
			return false;
    	}
    	
    	String getURL = _serverURL + _trajPatternPort + _createTrajPattern
    			+ _device_id + device_id + "&"
    	    	+ _name + pattern.getName() + "&"
    			+ _time + pattern.getTime() + "&"
    			+ _manifest + pattern.getManifest() + "&" 
    			+ _pattern + pattern.getPattern();
    	/*String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}*/
    	performGetNonblock(getURL);
    	return true;
    }
    
    public Boolean deleteTrajPattern(String name, String device_id) {
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}
    	
    	String getURL = _serverURL + _trajPatternPort + _deleteTrajPattern
    			+ _device_id + device_id + "&"
    	    	+ _name + name;
    	String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}
    	//performGetNonblock(getURL);
    	return true;
    }
    
    public List<TrajPattern> lookupTrajPattern(String name, int manifest) {
    	List<TrajPattern> tpList = null;
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return null;
    	}
    	switch (manifest) {
    	case TrajPattern._RAW:
    	case TrajPattern._QUANTIZED:
    	case TrajPattern._AGGREGATED:
    		break;
		default:
    		Log.e("Touch01", "'manifest' field has wrong value!");
			return null;
    	}
    	
    	String getURL = _serverURL + _trajPatternPort + _lookupTrajPattern
    			+ _name + name + "&" + _manifest + manifest;
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		tpList = lookupTrajPattern(name, manifest);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return null;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return null;
    	} else {
        	tpList = new ArrayList<TrajPattern>();
        	StringTokenizer tsToken = new StringTokenizer(result, " ");
        	TrajPattern pattern;
        	while (tsToken.hasMoreElements()) {
        		pattern = new TrajPattern(name);
        		pattern.setFromStringSimple((String) tsToken.nextElement());
        		tpList.add(pattern);
        	}
    	}
    	return tpList;
    }
    
    public Boolean updateTrajPattern(String name, String oldPattern, String newPattern, int manifest, String device_id) {
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return false;
    	}
    	if (oldPattern == null || oldPattern.length() == 0) {
    		Log.e("Touch01", "'oldPattern' field is empty!");
    		return false;
    	}
    	if (newPattern == null || newPattern.length() == 0) {
    		Log.e("Touch01", "'newPattern' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}
    	
    	switch (manifest) {
    	case TrajPattern._RAW:
    	case TrajPattern._QUANTIZED:
    	case TrajPattern._AGGREGATED:
    		break;
		default:
    		Log.e("Touch01", "'manifest' field has wrong value!");
			return false;
    	}
    	
    	int time = (int) (System.currentTimeMillis() / 1000);
    	String getURL = _serverURL + _trajPatternPort + _updateTrajPattern
    		+ _device_id + device_id + "&"
        	+ _name + name + "&" + _time + time
    		+ "&" + _manifest + manifest + "&" + _oldPattern + oldPattern + "&" + _newPattern + newPattern;
    	/*String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}*/
    	performGetNonblock(getURL);
    	return true;
    }
    
    public Boolean createBattHistory(BattleHistory history, String device_id) {
    	if (history == null) {
    		Log.e("Touch01", "'history' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}
    	
    	switch (history.getManifest()) {
    	case BattleHistory._WON:
    	case BattleHistory._LOST:
    	case BattleHistory._RESET:
    	case BattleHistory._SUCCESS:
    	case BattleHistory._FAIL:
    		break;
		default:
    		Log.e("Touch01", "'manifest' field has wrong value!");
			return false;
    	}
    	String getURL = _serverURL + _battHistoryPort + _createBattHistory
    			+ _device_id + device_id + "&"
    	    	+ _pname + history.getPlayerName() + "&"
    			+ _oname + history.getOpponentName() + "&"
    			+ _time + history.getTime() + "&"
    			+ _ppoint + history.getPlayerPoint() + "&"
    			+ _opoint + history.getOpponentPoint() + "&"
    			+ _rpoint + history.getRewardPoint() + "&"
    			+ _manifest + history.getManifest();
    	String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}
    	//performGetNonblock(getURL);
    	return true;
    }
    
    public Boolean deleteBattHistory(String name, String device_id) {
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return false;
    	}
    	if (device_id == null) {
    		Log.e("Touch01", "'device_id' field is empty!");
    		return false;
    	}
    	
    	String getURL = _serverURL + _battHistoryPort + _deleteBattHistory
    			+ _device_id + device_id + "&"
    	    	+ _name + name;  
    	String result = performGet(getURL);
    	if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return false;
    	}
    	if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return false;
    	}
    	//performGetNonblock(getURL);
    	return true;
    }
    
    public List<BattleHistory> lookupBattHistory(String name) {
    	List<BattleHistory> bhList = null;
    	if (name == null || name.length() == 0) {
    		Log.e("Touch01", "'name' field is empty!");
    		return null;
    	}
    	
    	String getURL = _serverURL + _battHistoryPort + _lookupBattHistory + _name + name; 
    	String result = performGet(getURL);
    	if (result == null) {
    		Log.e("Touch01", "Server communication has a problem now.");
    		bhList = lookupBattHistory(name);
    	} else if (result.contains("[ERROR]")) {
    		Log.e("Touch01", result);
    		return null;
    	} else if (result.contains("[WARNING]")) {
    		Log.d("Touch01", result);
    		return null;
    	} else {
        	bhList = new ArrayList<BattleHistory>();
        	StringTokenizer tsToken = new StringTokenizer(result, " ");
        	BattleHistory history;
        	while (tsToken.hasMoreElements()) {
        		history = new BattleHistory();
        		history.setFromStringSimple((String) tsToken.nextElement());
        		bhList.add(history);
        	}
    	}
    	return bhList;
    }
    
}