package com.example.touch01;

import java.util.List;

public class AsyncResponse {
	public interface AsyncCheckServerStatusResponse {
	    void processCheckServerStatusFinish(String status);
	}

	public interface AsyncCountUserResponse {
	    void processCountUserFinish(Integer output);
	}
	
	public interface AsyncUserProfileResponse {
	    void processUserProfileFinish(UserProfile output);
	}
	
	public interface AsyncUserProfileListResponse {
	    void processUserProfileListFinish(List<UserProfile> output);
	}
	
	public interface AsyncBattleHistoryListResponse {
	    void processBattleHistoryListFinish(List<BattleHistory> output);
	}
	
	public interface AsyncRawTrajPatternResponse {
	    void processRawTrajPatternFinish(List<TrajPattern> output);
	}
	
	public interface AsyncQuanTrajPatternResponse {
	    void processQuanTrajPatternFinish(List<TrajPattern> output);
	}
	
	public interface AsyncAggTrajPatternResponse {
	    void processAggTrajPatternFinish(TrajPattern output);
	}
	
	public interface AsyncCellPatternResponse {
	    void processCellPatternFinish(CellPattern output);
	}
	
}
