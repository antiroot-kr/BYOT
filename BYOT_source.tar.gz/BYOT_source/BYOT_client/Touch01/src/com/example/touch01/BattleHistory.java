package com.example.touch01;

import java.util.StringTokenizer;

public class BattleHistory {
	private int dbid;
	private int time;
	private String pname;
	private String oname;
	private int p_point;
	private int o_point;
	private int r_point;
	private int manifest;
	
	public static final int _WON = 1;
	public static final int _LOST = 2;
	public static final int _RESET = 3;
	public static final int _SUCCESS = 4;
	public static final int _FAIL = 5;
	
	public int getDBID(){
		return this.dbid;
	}
	
	public int getTime(){
		return this.time;
	}
	
	public String getPlayerName(){
		return this.pname;
	}
	
	public String getOpponentName(){
		return this.oname;
	}
	
	public int getPlayerPoint(){
		return this.p_point;
	}
	
	public int getOpponentPoint(){
		return this.o_point;
	}
	
	public int getRewardPoint(){
		return this.r_point;
	}
	
	public int getManifest(){
		return this.manifest;
	}
	
	public BattleHistory(){
	}
		
	public BattleHistory(int dbid, int time, String pname, String oname, int p_point, int o_point, int r_point, int manifest){
		this.dbid = dbid;
		this.time = time;
		this.pname = pname;
		this.oname = oname;
		this.p_point = p_point;
		this.o_point = o_point;
		this.r_point = r_point;
		this.manifest = manifest;
	}
	
	public void setDBID(int dbid){
		this.dbid = dbid;
	}

	public void setTime(int time){
		this.time = time;
	}
	
	public void setPlayerName(String pname){
		this.pname = pname;
	}
	
	public void setOpponentName(String oname){
		this.oname = oname;
	}
	
	public void setPlayerPoint(int p_point){
		this.p_point = p_point;
	}
	
	public void setOpponentPoint(int o_point){
		this.o_point = o_point;
	}
	
	public void setRewardPoint(int r_point){
		this.r_point = r_point;
	}
	
	public void setManifest(int manifest){
		this.manifest = manifest;
	}
	
    public String toString() {
    	String str = "";
    	str += "dbid=" + dbid + ", time=" + time + ", pname=" + pname + ", oname=" + oname + ", p_point=" + p_point
    		+ ", o_point=" + o_point + ", r_point=" + r_point
    		+ ", manifest=" + manifest;
    	return str;
    }
    
    public String toStringSimple() {
    	String str = "";
    	str += dbid + "_" + time + "_" + pname + "_" + oname + "_"
    		+ p_point + "_" + o_point + "_" + r_point + "_" + manifest;
    	return str;
    }

    public boolean setFromStringSimple(String str) {
    	if (str == null || str.isEmpty()) {
    		return false;
    	}
    	StringTokenizer token = new StringTokenizer(str, "_");
    	int i = 0;
    	while (token.hasMoreElements()) {
    		switch (i) {
    		case 0:
    			this.dbid = Integer.parseInt((String) token.nextElement());
    			break;
    		case 1:
    			this.time = Integer.parseInt((String) token.nextElement());
    			break;
    		case 2:
    			this.pname = (String) token.nextElement();
    			break;
    		case 3:
    			this.oname = (String) token.nextElement();
    			break;
    		case 4:
    			this.p_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 5:
    			this.o_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 6:
    			this.r_point = Integer.parseInt((String) token.nextElement());
    			break;
    		case 7:
    			this.manifest = Integer.parseInt((String) token.nextElement());
    			break;
    		}
    		++i;
    	}
    	return true;
    }
}
