package com.example.touch01;

import java.util.ArrayList;

import android.os.Bundle;
import android.os.Handler;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Point;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewGroup.LayoutParams;
import android.widget.Toast;

@SuppressLint("NewApi")
public class CalibrationTipActivity extends Activity {    
    private SharedPreferences mPrefs;
    private static final String _ClassName = CalibrationTipActivity.class.getName();
	public static final String _Calibration = _ClassName + ".calibration";
	public static final String _FromMenu = _ClassName + ".from_menu";
	public static final String _Pressure = _ClassName + ".pressure";
	public static final String _Size = _ClassName + ".size";
	public static final String _UserProfile = _ClassName + ".user_profile";
	
	private static final int duration = 2000; // 2 seconds to get signal
	
	private CalibrationView view;
	private Boolean fromMenu;
	private int presTip;
	private int sizeTip;
	ArrayList<Integer> presList;
	ArrayList<Integer> sizeList;
	
	private Toast toast;
	int inTouchProgress;
	int inIdleAnimate;
	private boolean disableRunnables = false;
	private Handler inTouchProgressHandler;
	private Handler inIdleAnimateHandler;
	private Runnable inTouchProgressRun;
	private Runnable inIdleAnimateRun;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        fromMenu = getIntent().getBooleanExtra(_FromMenu, false);

		setContentView(R.layout.calibration_tip);
		mPrefs = getSharedPreferences(CalibrationTipActivity.class.getName(), 0);
				
		presList = new ArrayList<Integer>();
		sizeList = new ArrayList<Integer>();
				
		view = (CalibrationView) findViewById (R.id.calibration_view);
		view.setBitmapID(R.drawable.little_tip_768_868_5);
		view.setLittleTipMode(true);

		inTouchProgress = -1;
		inIdleAnimate = 0;
		disableRunnables = false;
        view.setInTouchProgress(inTouchProgress);
        view.setInIdleAnimate(inIdleAnimate);
        view.invalidate();

        this.inIdleAnimateHandler = new Handler();
        this.inIdleAnimateRun = new Runnable(){
        	@Override
        	public void run(){
        		if (disableRunnables) {
        			return;
        		}
        		Log.d("Touch01", "Periodic task: inIdleAnimate");
        		if (inTouchProgress == -1) {
        			inIdleAnimate++;
        			// TODO: invalidate and draw here!
        			if (inIdleAnimate >= 8) {
        				inIdleAnimate = 0;
        			}
		        	view.setInIdleAnimate(inIdleAnimate);
        			view.invalidate();
        			inIdleAnimateHandler.postDelayed(this, duration/4);
        		} else {
        			inIdleAnimate = 0;
        		}
        	}
        };
        inIdleAnimateHandler.postDelayed(inIdleAnimateRun, duration/4);
        
        this.inTouchProgressHandler = new Handler();
        inTouchProgressRun = new Runnable(){
        	@Override
        	public void run(){
        		if (disableRunnables) {
        			return;
        		}
        		Log.d("Touch01", "Periodic task: inTouchProgress");
        		if (inTouchProgress != -1 && inTouchProgress < 13) {
        			// TODO: invalidate and draw here!
        			inTouchProgress++;
		        	view.setInTouchProgress(inTouchProgress);
        			view.invalidate();
        			inTouchProgressHandler.postDelayed(this, duration/13);
        		}
        	}
        };

		LayoutParams params = view.getLayoutParams();
		
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
		
		params.width = width;
		params.height = width * 868 / 768;
		view.setLayoutParams(params);
		
		view.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				float p;
				float s;
				int tempLow, tempHigh;
		        switch (event.getAction()) {
		        case MotionEvent.ACTION_DOWN:
		        	presList.clear();
		        	sizeList.clear();
		            p = event.getPressure(0);
		            s = event.getSize(0);
		            presList.add((int)(p*100));
		            sizeList.add((int)(s*100));
		            Log.d("Touch01", "p= " + (int)(p*100) + ", s=" + (int)(s*100));

		            
		            if (toast != null) {
		            	toast.cancel();
		            }

		            inTouchProgress = 0;
	        		inIdleAnimate = 0;
		            view.setInTouchProgress(inTouchProgress);
	        		view.setInIdleAnimate(inIdleAnimate);
		            view.invalidate();
		            inTouchProgressHandler.postDelayed(inTouchProgressRun, duration/13);
		            inIdleAnimateHandler.removeCallbacks(inIdleAnimateRun);
		            return true;
		        case MotionEvent.ACTION_UP:
		        	//Log.d("Touch01", "UP TEST");
		        	if (inTouchProgress == 13) {
			        	inTouchProgress = -1;
			        	disableRunnables = true;
			    		if (toast != null) {
			    			toast.cancel();
			    		}
		        	} else {
			        	inTouchProgress = -1;
			        	view.setInTouchProgress(inTouchProgress);
			        	view.invalidate();
						toast = Toast.makeText(getBaseContext(), "Please try at least 2 seconds!", Toast.LENGTH_SHORT);
						toast.show();
						
						inIdleAnimate = 0;
			            view.setInIdleAnimate(inIdleAnimate);
			            view.invalidate();
			            inIdleAnimateHandler.postDelayed(inIdleAnimateRun, duration/4);
			            inTouchProgressHandler.removeCallbacks(inTouchProgressRun);
		        		return true;
		        	}

		        	tempHigh = 0;
		        	tempLow = 100;
		        	for (int i=0; i<presList.size(); ++i) {
		        		if (presList.get(i) > tempHigh) {
		        			tempHigh = presList.get(i);
		        		}
		        		if (presList.get(i) < tempLow) {
		        			tempLow = presList.get(i);
		        		}
		        	}
		        	presTip = (tempHigh + tempLow) / 4;
		        	//presTip = tempLow / 4;
		        	
		        	tempHigh = 0;
		        	tempLow = 100;
		        	for (int i=0; i<sizeList.size(); ++i) {
		        		if (sizeList.get(i) > tempHigh) {
		        			tempHigh = sizeList.get(i);
		        		}
		        		if (sizeList.get(i) < tempLow) {
		        			tempLow = sizeList.get(i);
		        		}
		        	}
		        	sizeTip = (tempHigh + tempLow) / 4;
		        	//sizeTip = tempLow / 4;
		        	
		        	mPrefs.edit().putInt(CalibrationTipActivity._Pressure, presTip).commit();
		        	mPrefs.edit().putInt(CalibrationTipActivity._Size, sizeTip).commit();
		        	mPrefs.edit().putBoolean(CalibrationTipActivity._Calibration, true).commit();

		        	if (fromMenu) {
		        		CalibrationTipActivity.this.finish();
		        	} else {
						Intent nextIntent;
			            nextIntent = new Intent(CalibrationTipActivity.this, MenuActivity.class);
			            CalibrationTipActivity.this.startActivity(nextIntent);
			            CalibrationTipActivity.this.finish();
		        	}
		            return true;
		        case MotionEvent.ACTION_MOVE:
		            p = event.getPressure(0);
		            s = event.getSize(0);
		            presList.add((int)(p*100));
		            sizeList.add((int)(s*100));
		            Log.d("Touch01", "p= " + (int)(p*100) + ", s=" + (int)(s*100));

		            return true;
		        case MotionEvent.ACTION_CANCEL:
		        	//TODO: DO WE NEED THIS? 
		            return true;
		        }
				return false;
			}
		});
	}
	
	@Override
	public void onBackPressed() {
		this.disableRunnables = true;
		if (toast != null) {
			toast.cancel();
		}
		super.onBackPressed();
	}

}
