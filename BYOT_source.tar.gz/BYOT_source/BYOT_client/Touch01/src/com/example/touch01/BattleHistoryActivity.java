package com.example.touch01;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;

@SuppressLint("NewApi")
public class BattleHistoryActivity extends Activity 
implements AsyncResponse.AsyncBattleHistoryListResponse {
	private DBHelper dbHelper;
	private SQLiteDatabase db;
	
    private static final String _ClassName = BattleHistoryActivity.class.getName();
	public static final String _BattHistoryList = _ClassName + ".batt_history_list";
	
    private SharedPreferences mPrefs;
	private List<BattleHistory> _bhList;
	private String _nickname;
	private Context _context;
	private String _device_id;
    
    private class AsyncBattleHistoryListLookupTask extends AsyncTask<String, Void, List<BattleHistory>> {
    	public AsyncResponse.AsyncBattleHistoryListResponse delegate = null;

		@Override
        protected List<BattleHistory> doInBackground(String... names) {
			if (dbHelper == null) {
				return null;
			}
			List<BattleHistory> _bhList = dbHelper.lookupBattHistory(names[0]);
    		if (_bhList == null) {
    			Log.d("Touch01", "There is no battle history.");
    			_bhList = new ArrayList<BattleHistory>();
    			_bhList.clear();
    		}
    		return _bhList;
        }
        protected void onPostExecute(List<BattleHistory> result) {
        	delegate.processBattleHistoryListFinish(result);
        	this.cancel(true);
        }
    }
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
		setContentView(R.layout.battle_history);
		
		this.dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();
		this.dbHelper.setWritableDatabase(db);
		
		_context = this.getApplicationContext();
		
		final TelephonyManager tm =
				(TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);
		_device_id = tm.getDeviceId();
		
		// we then lookup battle history from the DB
				mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
				_nickname = mPrefs.getString(LoginActivity._Nickname, null);
				
		String str;
		str = getIntent().getStringExtra(_BattHistoryList);
		if (str != null && str.isEmpty() == false) {
	        StringTokenizer tsToken;
            BattleHistory history;
        	_bhList = new ArrayList<BattleHistory>();
        	tsToken = new StringTokenizer(str, " ");
        	while (tsToken.hasMoreElements()) {
        		history = new BattleHistory();
        		history.setFromStringSimple((String) tsToken.nextElement());
        		_bhList.add(history);
        	}
    		BattleHistoryAdapter bhAdapter = new BattleHistoryAdapter(this, R.layout.battle_history_list, _bhList);
    		bhAdapter.setName(_nickname);
    		ListView listView = (ListView) findViewById(R.id.listViewBattleHistory);
    		listView.setAdapter(bhAdapter);
		} else {
			_bhList = null;
			AsyncBattleHistoryListLookupTask bhListLookupTask = new AsyncBattleHistoryListLookupTask();
			bhListLookupTask.delegate = this;
			bhListLookupTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, _nickname);
		}
	}

	@Override
	public void processBattleHistoryListFinish(List<BattleHistory> output) {
		if (output == null) {
			this._bhList = new ArrayList<BattleHistory>();
		} else {
			this._bhList = output;
		}
		
		BattleHistoryAdapter bhAdapter = new BattleHistoryAdapter(this, R.layout.battle_history_list, _bhList);
		bhAdapter.setName(_nickname);
		ListView listView = (ListView) findViewById(R.id.listViewBattleHistory);
		listView.setAdapter(bhAdapter);
		Log.d("Touch01", "AsyncBattleHistoryListLookupTask is finished.");
	}
	
	@Override
	public void onBackPressed(){
	    if (dbHelper != null) {
	    	dbHelper.clearWritableDatabase();
	        dbHelper.close();
	        dbHelper = null;
	    }
	    if (db != null) {
	        db.close();
	        db = null;
	    }
	    super.onBackPressed();
	}
}
