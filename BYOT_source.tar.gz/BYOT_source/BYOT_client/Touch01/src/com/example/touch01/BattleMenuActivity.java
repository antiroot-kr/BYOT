package com.example.touch01;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import group.pals.android.lib.ui.lockpattern.LockPatternActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class BattleMenuActivity extends Activity 
implements AsyncResponse.AsyncUserProfileResponse,
AsyncResponse.AsyncBattleHistoryListResponse {
	private DBHelper dbHelper;
	private SQLiteDatabase db;
	
    private static final String _ClassName = BattleMenuActivity.class.getName();
	public static final String _BattHistoryList = _ClassName + ".batt_history_list";
	public static final String _UserProfileList = _ClassName + ".user_profile_list";
	public static final String _UserProfile = _ClassName + ".user_profile";
	public static final String _NumUsers = _ClassName + ".num_users";
	
	private Button my_profile_button;
	private Button medium_level_button;
	private Button high_level_button;
	private Button low_level_button;
	private Button battle_history_button;
	private Boolean my_profile_button_enabled = false;
	private Boolean medium_level_button_enabled = false;
	private Boolean high_level_button_enabled = false;
	private Boolean low_level_button_enabled = false;
	private Boolean battle_history_button_enabled = false;

	public static final int _ReqUnlockMediumPattern = 3;
	public static final int _ReqUnlockHighPattern = 4;
	public static final int _ReqUnlockLowPattern = 5;
	public static int mNumTraining;
	public static final float _randomRange = 0.2f;
	public static final float _higherRange = 0.4f;
	public static final float _lowerRange = 0.4f;
	
	/*private final int btnColor1 = 0xff550000;
	private final int btnColor2 = 0xff403000;
	private final int btnColor3 = 0xff304000;
	private final int btnColor4 = 0xff005500;
	private final int btnColor5 = 0xff003040;
	private final int btnColor6 = 0xff000055;
	private final int btnColor7 = 0xff300040;*/
	
	private final int btnColorInactive = 0xff000000;
	private final int txtColorInactive = 0xff505050;
	private final int txtColorActive = 0xffffffff;	
	private final int btnColorMyProfile = 0xff001525;
	private final int btnColorMediumLevel = 0xff003040;
	private final int btnColorBattleHistory = 0xff334455;
	private final int btnColorHighLevel = 0xff385060;
	private final int btnColorLowLevel = 0xff497080;
	
	/*public String _createdPattern;
	public String _createdTruePattern;
	public String _createdTouchSignal;
	public String _createdTouchSignals;
	public String _createdGridSignal;
	public String _createdGridSignals;*/
	
    private SharedPreferences mPrefs;
    
    private String _nickname;
    private UserProfile _userProfile;
    private List<UserProfile> _upList;
    private List<BattleHistory> _bhList;
    
	private CellPattern cPattern;
	private TrajPattern tAggPattern;
    private UserProfile _otherProfile;
    private int _numUsers;
    private Context _context;
	
    private int _thumbPres;
    private int _thumbSize;
    private int _tipPres;
    private int _tipSize;
    private String _device_id;
    
    private final int leastPeopleRange = 5;
    
    private class AsyncUserProfileLookupTask extends AsyncTask<String, Void, UserProfile> {
    	public AsyncResponse.AsyncUserProfileResponse delegate = null;

		@Override
        protected UserProfile doInBackground(String... names) {
        	UserProfile _userProfile = dbHelper.lookupUser(names[0]);
    		if (_userProfile == null) {
    			Log.e("Touch01", "Error on lookupUser()");
    			_userProfile = new UserProfile(names[0]);
    		}
    		int rank = dbHelper.lookupUserRank(names[0]);
			if (rank == 0) {
				Log.e("Touch01", "Error on reading user's ranking!");
				rank = 1;
			}
			_userProfile.setRank(rank);
    		return _userProfile;
        }

        protected void onPostExecute(UserProfile result) {
        	delegate.processUserProfileFinish(result);
        	this.cancel(true);
        }
    }
    
    private class AsyncBattleHistoryListLookupTask extends AsyncTask<String, Void, List<BattleHistory>> {
    	public AsyncResponse.AsyncBattleHistoryListResponse delegate = null;

		@Override
        protected List<BattleHistory> doInBackground(String... names) {
			List<BattleHistory> _bhList = dbHelper.lookupBattHistory(names[0]);
    		if (_bhList == null) {
    			Log.d("Touch01", "There is no battle history.");
    			_bhList = new ArrayList<BattleHistory>();
    			_bhList.clear();
    		}
    		return _bhList;
        }
        protected void onPostExecute(List<BattleHistory> result) {
        	delegate.processBattleHistoryListFinish(result);
        	this.cancel(true);
        }
    }
    
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.battle_menu);
		
		this.dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();
		this.dbHelper.setWritableDatabase(db);
		
		_context = this.getApplicationContext();
		
		mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
		_nickname = mPrefs.getString(LoginActivity._Nickname, null);
		
		mPrefs = getSharedPreferences(CalibrationBaseActivity.class.getName(), 0);
		_thumbPres = mPrefs.getInt(CalibrationBaseActivity._Pressure, 90);
		_thumbSize = mPrefs.getInt(CalibrationBaseActivity._Size, 90);
		
		mPrefs = getSharedPreferences(CalibrationTipActivity.class.getName(), 0);
		_tipPres = mPrefs.getInt(CalibrationTipActivity._Pressure, 90);
		_tipSize = mPrefs.getInt(CalibrationTipActivity._Size, 90);

		final TelephonyManager tm =
				(TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);
		_device_id = tm.getDeviceId();

		my_profile_button = (Button) findViewById(R.id.my_profile_button);
		//my_profile_button.setBackgroundColor(btnColorMyProfile);
		my_profile_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (my_profile_button_enabled == false) {
					return;
				}
				Intent nextIntent = new Intent(BattleMenuActivity.this, ProfileActivity.class);
				if (_userProfile != null) {
					nextIntent.putExtra(ProfileActivity._UserProfile, _userProfile.toStringSimple());
				}
				startActivity(nextIntent);
			}
		});
		my_profile_button.setActivated(false);
		my_profile_button.setBackgroundColor(btnColorInactive);
		my_profile_button.setTextColor(txtColorInactive);
		
		medium_level_button = (Button) findViewById(R.id.medium_level_button);
		//medium_level_button.setBackgroundColor(btnColorMediumLevel);
		medium_level_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (medium_level_button_enabled == false) {
					return;
				}
				Intent intent = new Intent(LockPatternActivity._ActionUnlockOtherPattern, null, 
						BattleMenuActivity.this, LockPatternActivity.class);
				intent.putExtra(LockPatternActivity._MaxRetry, 1000);
				intent.putExtra(LockPatternActivity._BgColor, btnColorMediumLevel);
				
				// here we lookup some user in the medium-range randomly...
				int min = (int) (_userProfile.getRank() * (1.0f - _randomRange));
				int max = (int) (_userProfile.getRank() * (1.0f + _randomRange));
				if (max < leastPeopleRange) {
					max = leastPeopleRange;
				}
				if (max > _numUsers) {
					max = _numUsers;
				}
				if (min > max - leastPeopleRange) {
					min = max - leastPeopleRange;
				}
				if (min < 1) {
					min = 1;
				}
				
				// TODO: Utilize _upList (given by prior activity)
				Random r = new Random();
				int rnum;
				while (true) {
					rnum = r.nextInt(max - min + 1) + min - 1;
					List<UserProfile> upList = dbHelper.lookupUsersByRank(rnum, 1);
					if (upList == null || upList.isEmpty()) {
						Log.e("Touch01", "Error on lookupUsersByRank()");
						return;
					}
					_otherProfile = upList.get(0);
					if (_otherProfile == null) {
						Log.e("Touch01", "Error on _otherProfile!");
						return;
					}
					if (_otherProfile.getName().equals(_nickname) == false) {
						break;
					}
				}
				
				// TODO: Need some progress bar here
				// then, we lookup the CellPattern and TrajPattern(Aggregated) of the target
				cPattern = dbHelper.lookupCellPattern(_otherProfile.getName());
				if (cPattern == null) {
					Log.e("Touch01", "Error on lookupCellPattern(" + _otherProfile.getName() + ")");
					return;
				}
				
				List<TrajPattern> tPattern = dbHelper.lookupTrajPattern(_otherProfile.getName(), TrajPattern._AGGREGATED);
				if (tPattern == null || tPattern.isEmpty()) {
					Log.e("Touch01", "Error on lookupTrajPattern(Aggregated)");
					return;
				}
				tAggPattern = tPattern.get(0);
				if (tAggPattern == null) {
					Log.e("Touch01", "Error on tAggPattern!");
					return;
				}
				
				// finally, we send all the inputs to LockPatternActivity
				intent.putExtra(LockPatternActivity._TruePattern, cPattern.getPattern());
				intent.putExtra(LockPatternActivity._QuantizedTrajectory, tAggPattern.getPattern());
				
				intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
				intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
				intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
				intent.putExtra(LockPatternActivity._TipSize, _tipSize);
				
				intent.putExtra(LockPatternActivity._ID, _otherProfile.getName());
				intent.putExtra(LockPatternActivity._TotalScore, _otherProfile.getTotalPoint());
				intent.putExtra(LockPatternActivity._AttackScore, _otherProfile.getAttackPoint());
				intent.putExtra(LockPatternActivity._DefenseScore, _otherProfile.getDefensePoint());
				intent.putExtra(LockPatternActivity._UsabilityScore, _otherProfile.getUsabilityPoint());

				startActivityForResult(intent, _ReqUnlockMediumPattern);
			}
		});
		medium_level_button.setActivated(false);
		medium_level_button.setBackgroundColor(btnColorInactive);
		medium_level_button.setTextColor(txtColorInactive);
		
		battle_history_button = (Button) findViewById(R.id.battle_history_button);
		//battle_history_button.setBackgroundColor(btnColorBattleHistory);
		battle_history_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (battle_history_button_enabled == false) {
					return;
				}
				Intent nextIntent = new Intent(BattleMenuActivity.this, BattleHistoryActivity.class);
				if (_bhList != null) {
					String str = "";
					Iterator<BattleHistory> it = _bhList.iterator();
					while (it.hasNext()) {
						str += it.next().toStringSimple() + " ";
					}
					nextIntent.putExtra(BattleHistoryActivity._BattHistoryList, str);
				}
				startActivity(nextIntent);
			}
		});
		battle_history_button.setActivated(false);
		battle_history_button.setBackgroundColor(btnColorInactive);
		battle_history_button.setTextColor(txtColorInactive);
		
		high_level_button = (Button) findViewById(R.id.high_level_button);
		//high_level_button.setBackgroundColor(btnColorHighLevel);
		high_level_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (high_level_button_enabled == false) {
					return;
				}
				Intent intent = new Intent(LockPatternActivity._ActionUnlockOtherPattern, null, 
						BattleMenuActivity.this, LockPatternActivity.class);
				intent.putExtra(LockPatternActivity._MaxRetry, 1000);
				intent.putExtra(LockPatternActivity._BgColor, btnColorHighLevel);
				
				// here we lookup some user in the medium-range randomly...
				int min = (int) (_userProfile.getRank() * (1.0f - _randomRange - _higherRange));
				int max = (int) (_userProfile.getRank() * (1.0f + _randomRange - _higherRange));
				if (max < leastPeopleRange) {
					max = leastPeopleRange;
				}
				if (max > _numUsers) {
					max = _numUsers;
				}
				if (min > max - leastPeopleRange) {
					min = max - leastPeopleRange;
				}
				if (min < 1) {
					min = 1;
				}
				
				// TODO: Utilize _upList (given by prior activity)
				Random r = new Random();
				int rnum;
				while (true) {
					rnum = r.nextInt(max - min + 1) + min - 1;
					List<UserProfile> upList = dbHelper.lookupUsersByRank(rnum, 1);
					if (upList == null || upList.isEmpty()) {
						Log.e("Touch01", "Error on lookupUsersByRank()");
						return;
					}
					_otherProfile = upList.get(0);
					if (_otherProfile == null) {
						Log.e("Touch01", "Error on _otherProfile!");
						return;
					}
					if (_otherProfile.getName().equals(_nickname) == false) {
						break;
					}
				}
				
				// TODO: Need some progress bar here
				// then, we lookup the CellPattern and TrajPattern(Aggregated) of the target
				cPattern = dbHelper.lookupCellPattern(_otherProfile.getName());
				if (cPattern == null) {
					Log.e("Touch01", "Error on lookupCellPattern(" + _otherProfile.getName() + ")");
					return;
				}
				
				List<TrajPattern> tPattern = dbHelper.lookupTrajPattern(_otherProfile.getName(), TrajPattern._AGGREGATED);
				if (tPattern == null || tPattern.isEmpty()) {
					Log.e("Touch01", "Error on lookupTrajPattern(Aggregated)");
					return;
				}
				tAggPattern = tPattern.get(0);
				if (tAggPattern == null) {
					Log.e("Touch01", "Error on tAggPattern!");
					return;
				}
				
				// finally, we send all the inputs to LockPatternActivity
				intent.putExtra(LockPatternActivity._TruePattern, cPattern.getPattern());
				intent.putExtra(LockPatternActivity._QuantizedTrajectory, tAggPattern.getPattern());

				intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
				intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
				intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
				intent.putExtra(LockPatternActivity._TipSize, _tipSize);
				
				intent.putExtra(LockPatternActivity._ID, _otherProfile.getName());
				intent.putExtra(LockPatternActivity._TotalScore, _otherProfile.getTotalPoint());
				intent.putExtra(LockPatternActivity._AttackScore, _otherProfile.getAttackPoint());
				intent.putExtra(LockPatternActivity._DefenseScore, _otherProfile.getDefensePoint());
				intent.putExtra(LockPatternActivity._UsabilityScore, _otherProfile.getUsabilityPoint());

				startActivityForResult(intent, _ReqUnlockMediumPattern);
			}
		});
		high_level_button.setActivated(false);
		high_level_button.setBackgroundColor(btnColorInactive);
		high_level_button.setTextColor(txtColorInactive);
		
		low_level_button = (Button) findViewById(R.id.low_level_button);
		//low_level_button.setBackgroundColor(btnColorLowLevel);
		low_level_button.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if (low_level_button_enabled == false) {
					return;
				}
				Intent intent = new Intent(LockPatternActivity._ActionUnlockOtherPattern, null, 
						BattleMenuActivity.this, LockPatternActivity.class);
				intent.putExtra(LockPatternActivity._MaxRetry, 1000);
				intent.putExtra(LockPatternActivity._BgColor, btnColorLowLevel);
				
				// here we lookup some user in the medium-range randomly...
				int min = (int) (_userProfile.getRank() * (1.0f - _randomRange + _lowerRange));
				int max = _numUsers;
				if (min > max - leastPeopleRange) {
					min = max - leastPeopleRange;
				}
				if (min < 1) {
					min = 1;
				}
				// TODO: Utilize _upList (given by prior activity)
				Random r = new Random();
				int rnum;
				while (true) {
					rnum = r.nextInt(max - min + 1) + min - 1;
					List<UserProfile> upList = dbHelper.lookupUsersByRank(rnum, 1);
					if (upList == null || upList.isEmpty()) {
						Log.e("Touch01", "Error on lookupUsersByRank()");
						return;
					}
					_otherProfile = upList.get(0);
					if (_otherProfile == null) {
						Log.e("Touch01", "Error on _otherProfile!");
						return;
					}
					if (_otherProfile.getName().equals(_nickname) == false) {
						break;
					}
				}
				
				// TODO: Need some progress bar here
				// then, we lookup the CellPattern and TrajPattern(Aggregated) of the target
				cPattern = dbHelper.lookupCellPattern(_otherProfile.getName());
				if (cPattern == null) {
					Log.e("Touch01", "Error on lookupCellPattern(" + _otherProfile.getName() + ")");
					return;
				}
				Log.d("Touch01", "TEST 00");
				
				List<TrajPattern> tPattern = dbHelper.lookupTrajPattern(_otherProfile.getName(), TrajPattern._AGGREGATED);
				if (tPattern == null || tPattern.isEmpty()) {
					Log.e("Touch01", "Error on lookupTrajPattern(Aggregated)");
					return;
				}
				Log.d("Touch01", "TEST 10");
				
				tAggPattern = tPattern.get(0);
				if (tAggPattern == null) {
					Log.e("Touch01", "Error on tAggPattern!");
					return;
				}
				Log.d("Touch01", "TEST 20");
				
				
				// finally, we send all the inputs to LockPatternActivity
				intent.putExtra(LockPatternActivity._TruePattern, cPattern.getPattern());
				intent.putExtra(LockPatternActivity._QuantizedTrajectory, tAggPattern.getPattern());
				
				intent.putExtra(LockPatternActivity._ThumbPressure, _thumbPres);
				intent.putExtra(LockPatternActivity._ThumbSize, _thumbSize);
				intent.putExtra(LockPatternActivity._TipPressure, _tipPres);
				intent.putExtra(LockPatternActivity._TipSize, _tipSize);
				
				intent.putExtra(LockPatternActivity._ID, _otherProfile.getName());
				intent.putExtra(LockPatternActivity._TotalScore, _otherProfile.getTotalPoint());
				intent.putExtra(LockPatternActivity._AttackScore, _otherProfile.getAttackPoint());
				intent.putExtra(LockPatternActivity._DefenseScore, _otherProfile.getDefensePoint());
				intent.putExtra(LockPatternActivity._UsabilityScore, _otherProfile.getUsabilityPoint());

				startActivityForResult(intent, _ReqUnlockMediumPattern);
			}
		});
		low_level_button.setActivated(false);
		low_level_button.setBackgroundColor(btnColorInactive);
		low_level_button.setTextColor(txtColorInactive);
		
    	String str;
    	str = getIntent().getStringExtra(_UserProfile);
		if (str != null && str.isEmpty() == false) {
        	_userProfile = new UserProfile();
        	_userProfile.setFromStringSimple(str);
		} else {
			// we then lookup user profile from SharedPreferences and the DB
			// TODO: this can be done in an "async way"

			_userProfile = dbHelper.lookupUser(_nickname);
			if (_userProfile == null) {
				Log.e("Touch01", "Error on lookupUser()");
				_userProfile = new UserProfile(_nickname);
			}
			int rank = dbHelper.lookupUserRank(_nickname);
			if (rank == 0) {
				Log.e("Touch01", "Error on reading user's ranking!");
				rank = 1;
			}
			_userProfile.setRank(rank);
		}
		activateButtons();
		
		str = getIntent().getStringExtra(_UserProfileList);
		if (str != null && str.isEmpty() == false) {
	        StringTokenizer tsToken;
            UserProfile profile;
        	_upList = new ArrayList<UserProfile>();
        	tsToken = new StringTokenizer(str, " ");
        	while (tsToken.hasMoreElements()) {
        		profile = new UserProfile();
        		profile.setFromStringSimple((String) tsToken.nextElement());
        		_upList.add(profile);
        	}
        	activateButtons();
		} else {
			// we then lookup users by rank from the DB
			// TODO: this can be done in an "async way"
			_upList = dbHelper.lookupUsersByRank(0, 100);
			if (_upList == null) {
				Log.e("Touch01", "Error on lookupUsersByRank()");
				_upList = new ArrayList<UserProfile>();
				_upList.clear();
			} else {
				activateButtons();
			}
		}
		
		str = getIntent().getStringExtra(_BattHistoryList);
		if (str != null) {
	        StringTokenizer tsToken;
            BattleHistory history;
        	_bhList = new ArrayList<BattleHistory>();
        	tsToken = new StringTokenizer(str, " ");
        	while (tsToken.hasMoreElements()) {
        		history = new BattleHistory();
        		history.setFromStringSimple((String) tsToken.nextElement());
        		_bhList.add(history);
        		activateButtons();
        	}
		} else {
			// we then lookup battle history from the DB
			// TODO: this can be done in an "async way"
			mPrefs = getSharedPreferences(LoginActivity.class.getName(), 0);
			_nickname = mPrefs.getString(LoginActivity._Nickname, null);

			_bhList = dbHelper.lookupBattHistory(_nickname);
    		if (_bhList == null) {
    			Log.d("Touch01", "There is no battle history.");
    			_bhList = new ArrayList<BattleHistory>();
    			_bhList.clear();
    		} else {
    			activateButtons();
    		}
		}

    	_numUsers = getIntent().getIntExtra(_NumUsers, 0);
		if (_numUsers == 0) {
			_numUsers = dbHelper.countUsers();
			if (_numUsers == 0) {
				Log.e("Touch01", "Error on reading the number of users!");
				_numUsers = 1;
			} else {
				activateButtons();
			}
		} else {
			activateButtons();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	        Intent data) {
		Toast toast;
	    switch (requestCode) {
	    case _ReqUnlockMediumPattern:
	    case _ReqUnlockHighPattern:
	    case _ReqUnlockLowPattern:
	        // NOTE that there are 3 possible result codes!!!
	        int retryCount = data.getIntExtra(LockPatternActivity._ExtraRetryCount, 0);
	        int aPoint;
	        int dPoint;
	        int tPPoint;
	        int tOPoint;
	        int rPoint;
	        int i;
	        BattleHistory history;
	        AsyncBattleHistoryListLookupTask bhListLookupTask;
	        AsyncUserProfileLookupTask upLookupTask;
	        
	        switch (resultCode) {
	        case RESULT_OK:
	            // The user passed
	            Log.d("Touch01", "Unlocked Pattern!");
				toast = Toast.makeText(BattleMenuActivity.this, 
						"Unlocked Pattern!", Toast.LENGTH_SHORT);
				toast.show();
				
		        for (i=0; i< retryCount; ++i) {
		        	// PROFILE UPDATE (FAILED UNLOCKS)
	        		aPoint = _userProfile.getAttackPoint();
	        		dPoint = _otherProfile.getDefensePoint();
	        		tPPoint = _userProfile.getTotalPoint();
	        		tOPoint = _otherProfile.getTotalPoint();
	        		rPoint = battleEloCalculation(aPoint, dPoint, false);
		        	aPoint += rPoint;
		        	dPoint -= rPoint;
		        	tPPoint += rPoint;
		        	tOPoint -= rPoint;
	        		_userProfile.setAttackPoint(aPoint);
	        		_userProfile.setTotalPoint(tPPoint);
	        		_userProfile.incTrueFailureSelf();
	        		_userProfile.incTrialSelf();
	        		_otherProfile.setDefensePoint(dPoint);
	        		_otherProfile.setTotalPoint(tOPoint);
	        		_otherProfile.incTrueFailureOther();
	        		_otherProfile.incTrialOther();
	        		
	        		history = new BattleHistory(0, 
	        				(int) (System.currentTimeMillis() / 1000) - retryCount + i,
	        				_nickname,
	        				_otherProfile.getName(),
	        				tPPoint,
	        				tOPoint,
	        				rPoint,
	        				BattleHistory._LOST);
	        		_bhList.add(history);
	        		dbHelper.createBattHistory(history, _device_id, false);
		        }
	        	
        		// PROFILE UPDATE (SUCCESSFUL UNLOCK) 
        		aPoint = _userProfile.getAttackPoint();
        		dPoint = _otherProfile.getDefensePoint();
        		tPPoint = _userProfile.getTotalPoint();
        		tOPoint = _otherProfile.getTotalPoint();
        		rPoint = battleEloCalculation(aPoint, dPoint, true);
	        	aPoint += rPoint;
	        	dPoint -= rPoint;
	        	tPPoint += rPoint;
	        	tOPoint -= rPoint;
        		_userProfile.setAttackPoint(aPoint);
        		_userProfile.setTotalPoint(tPPoint);
        		_userProfile.incFalseSuccessSelf();
        		_userProfile.incTrialSelf();
        		_otherProfile.setDefensePoint(dPoint);
        		_otherProfile.setTotalPoint(tOPoint);
        		_otherProfile.incFalseSuccessOther();
        		_otherProfile.incTrialOther();
        		//dbHelper.updateUser(_userProfile, _device_id);
        		
        		history = new BattleHistory(0, 
        				(int) (System.currentTimeMillis() / 1000),
        				_nickname,
        				_otherProfile.getName(),
        				tPPoint,
        				tOPoint,
        				rPoint,
        				BattleHistory._WON);
        		_bhList.add(history);
        		dbHelper.createBattHistory(history, _device_id, false);

        		_bhList.clear();
        		_bhList = null;
        		_userProfile = null;
        		
        		activateButtons();
        		bhListLookupTask = new AsyncBattleHistoryListLookupTask();
        		bhListLookupTask.delegate = this;
        		bhListLookupTask.execute(_nickname);
    			upLookupTask = new AsyncUserProfileLookupTask();
    			upLookupTask.delegate = this;
    			upLookupTask.execute(_nickname);
	            break;
	        case RESULT_CANCELED:
	        case LockPatternActivity._ResultFailed:
	            // The user cancelled the task, or, 
	            // The user failed to enter the pattern
		        for (i=0; i< retryCount; ++i) {
		        	// PROFILE UPDATE (FAILED UNLOCKS)
	        		aPoint = _userProfile.getAttackPoint();
	        		dPoint = _otherProfile.getDefensePoint();
	        		tPPoint = _userProfile.getTotalPoint();
	        		tOPoint = _otherProfile.getTotalPoint();
	        		rPoint = battleEloCalculation(aPoint, dPoint, false);
		        	aPoint += rPoint;
		        	dPoint -= rPoint;
		        	tPPoint += rPoint;
		        	tOPoint -= rPoint;
	        		_userProfile.setAttackPoint(aPoint);
	        		_userProfile.setTotalPoint(tPPoint);
	        		_userProfile.incTrueFailureSelf();
	        		_userProfile.incTrialSelf();
	        		_otherProfile.setDefensePoint(dPoint);
	        		_otherProfile.setTotalPoint(tOPoint);
	        		_otherProfile.incTrueFailureOther();
	        		_otherProfile.incTrialOther();
	        		
	        		history = new BattleHistory(0, 
	        				(int) (System.currentTimeMillis() / 1000) - retryCount + i,
	        				_nickname,
	        				_otherProfile.getName(),
	        				tPPoint,
	        				tOPoint,
	        				rPoint,
	        				BattleHistory._LOST);
	        		_bhList.add(history);
	        		dbHelper.createBattHistory(history, _device_id, false);
		        }
		        
		        if (retryCount > 0) {
	        		//dbHelper.updateUser(_userProfile, _device_id);
	        		
	        		_bhList.clear();
	        		_bhList = null;
	        		_userProfile = null;
	        		activateButtons();
	        		bhListLookupTask = new AsyncBattleHistoryListLookupTask();
	        		bhListLookupTask.delegate = this;
	        		bhListLookupTask.execute(_nickname);
	    			upLookupTask = new AsyncUserProfileLookupTask();
	    			upLookupTask.delegate = this;
	    			upLookupTask.execute(_nickname);
		        }
	        	break;
	        }
	        // In any case, there's always a key _ExtraRetryCount, which holds
	        Log.d("Touch01", "RETRY COUNT: " + retryCount);
	        break;
	    }
	}
	
	@SuppressLint("NewApi")
	private void activateButtons(){
		my_profile_button_enabled = false;
		medium_level_button_enabled = false;
		high_level_button_enabled = false;
		low_level_button_enabled = false;
		battle_history_button_enabled = false;
		
		if (_numUsers > 0) {
			if (_userProfile != null) {
				my_profile_button_enabled = true;
				if (_upList != null && _upList.isEmpty() == false) {
					medium_level_button_enabled = true;
					high_level_button_enabled = true;
					low_level_button_enabled = true;
				}
				if (_bhList != null && _bhList.isEmpty() == false) {
					battle_history_button_enabled = true;
				}
			}
		}
		
		if (my_profile_button_enabled == true) {
			my_profile_button.setActivated(true);
			my_profile_button.setBackgroundColor(btnColorMyProfile);
			my_profile_button.setTextColor(txtColorActive);
		} else {
			my_profile_button.setActivated(false);
			my_profile_button.setBackgroundColor(btnColorInactive);
			my_profile_button.setTextColor(txtColorInactive);
		}
		if (medium_level_button_enabled == true) {
			medium_level_button.setActivated(true);
			medium_level_button.setBackgroundColor(btnColorMediumLevel);
			medium_level_button.setTextColor(txtColorActive);
		} else {
			medium_level_button.setActivated(false);
			medium_level_button.setBackgroundColor(btnColorInactive);
			medium_level_button.setTextColor(txtColorInactive);
		}
		if (high_level_button_enabled == true) {
			high_level_button.setActivated(true);
			high_level_button.setBackgroundColor(btnColorHighLevel);
			high_level_button.setTextColor(txtColorActive);
		} else {
			high_level_button.setActivated(false);
			high_level_button.setBackgroundColor(btnColorInactive);
			high_level_button.setTextColor(txtColorInactive);
		}
		if (low_level_button_enabled == true) {
			low_level_button.setActivated(true);
			low_level_button.setBackgroundColor(btnColorLowLevel);
			low_level_button.setTextColor(txtColorActive);
		} else {
			low_level_button.setActivated(false);
			low_level_button.setBackgroundColor(btnColorInactive);
			low_level_button.setTextColor(txtColorInactive);
		}
		if (battle_history_button_enabled == true) {
			battle_history_button.setActivated(true);
			battle_history_button.setBackgroundColor(btnColorBattleHistory);
			battle_history_button.setTextColor(txtColorActive);
		} else {
			battle_history_button.setActivated(false);
			battle_history_button.setBackgroundColor(btnColorInactive);
			battle_history_button.setTextColor(txtColorInactive);
		}
	}
	
	@Override
	public void onBackPressed(){
	    if (dbHelper != null) {
	    	dbHelper.clearWritableDatabase();
	        dbHelper.close();
	        dbHelper = null;
	    }
	    if (db != null) {
	        db.close();
	        db = null;
	    }
	    super.onBackPressed();
	}
	
	@Override
	public void processUserProfileFinish(UserProfile output) {
		if (output == null) {
			this._userProfile = null;
		} else {
			this._userProfile = output;
		}
		activateButtons();
		Log.d("Touch01", "AsyncUserProfileLookupTask is finished.");
	}
	
	@Override
	public void processBattleHistoryListFinish(List<BattleHistory> output) {
		if (output == null) {
			this._bhList = new ArrayList<BattleHistory>();
		} else {
			this._bhList = output;
		}
		activateButtons();
		Log.d("Touch01", "AsyncBattleHistoryListLookupTask is finished.");
	}
	
	private int battleEloCalculation(int aPoint, int dPoint, Boolean won) {
		float e = (float) (1.0f / ( 1.0f + Math.pow(10, (double)(dPoint - aPoint)/400)));
		int elo = (int)(100.0f * ((won ? 1.0f : 0.0f) - e));
		return elo;
	}
}
